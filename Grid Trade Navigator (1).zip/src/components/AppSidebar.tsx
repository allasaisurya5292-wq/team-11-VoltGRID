import { Link } from "@tanstack/react-router";
import { LayoutDashboard, Bus, BatteryCharging, CalendarClock, Settings, Activity, Database, Zap, Wrench, ShieldCheck, FileBarChart } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/lib/auth";

const defaultSections = [
  {
    label: "Overview",
    items: [{ to: "/dashboard", label: "Dashboard", icon: LayoutDashboard }],
  },
  {
    label: "Fleet",
    items: [
      { to: "/fleet-manager", label: "Fleet manager", icon: Bus },
      { to: "/battery-analytics", label: "Battery analytics", icon: BatteryCharging },
      { to: "/predictive-maintenance", label: "Predictive maintenance", icon: Wrench },
      { to: "/battery-prevention", label: "Battery prevention", icon: ShieldCheck },
    ],
  },
  {
    label: "Operations",
    items: [
      { to: "/scheduler", label: "Scheduler", icon: CalendarClock },
      { to: "/reports", label: "Reports", icon: FileBarChart },
    ],
  },
  {
    label: "System",
    items: [{ to: "/settings", label: "Settings", icon: Settings }],
  },
] as const;

const adminSections = [
  {
    label: "Overview",
    items: [{ to: "/dashboard", label: "Dashboard", icon: LayoutDashboard }],
  },
  {
    label: "Operations",
    items: [
      { to: "/stability", label: "Stability", icon: Activity },
      { to: "/storage", label: "Storage", icon: Database },
      { to: "/energy-monitor", label: "Energy monitor", icon: Zap },
    ],
  },

  {
    label: "System",
    items: [{ to: "/settings", label: "Settings", icon: Settings }],
  },
] as const;

export function AppSidebar() {
  const { role } = useAuth();
  const sections = role === "maenova_admin" ? adminSections : defaultSections;

  return (
    <aside className="w-60 shrink-0 border-r border-sidebar-border bg-sidebar text-sidebar-foreground hidden md:block sticky top-0 self-start h-screen overflow-y-auto p-4">
      <nav className="space-y-6">
        {sections.map((s) => (
          <div key={s.label}>
            <div className="px-2 mb-2 text-[11px] font-semibold tracking-wider text-sidebar-foreground/60 uppercase">
              {s.label}
            </div>
            <ul className="space-y-1">
              {s.items.map((item) => {
                const Icon = item.icon;
                return (
                  <li key={item.to}>
                    <Link
                      to={item.to}
                      activeOptions={{ exact: true }}
                      className={cn(
                        "flex items-center gap-2 rounded-md px-2 py-2 text-sm text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition-colors",
                      )}
                      activeProps={{
                        className:
                          "flex items-center gap-2 rounded-md px-2 py-2 text-sm bg-sidebar-primary text-sidebar-primary-foreground font-medium",
                      }}
                    >
                      <Icon className="h-4 w-4" />
                      {item.label}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>
    </aside>
  );
}
