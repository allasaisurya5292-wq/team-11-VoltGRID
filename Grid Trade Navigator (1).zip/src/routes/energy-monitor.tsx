import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { AppSidebar } from "@/components/AppSidebar";
import { PageShell } from "@/components/PageShell";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Zap, TrendingUp, TrendingDown, Activity } from "lucide-react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from "recharts";
import { supabase } from "@/integrations/supabase/client";
import { useServerFn } from "@tanstack/react-start";
import { getLiveGrid } from "@/lib/api/grid.functions";
import { persistDispatch } from "@/lib/api/dispatch.functions";

export const Route = createFileRoute("/energy-monitor")({
  head: () => ({ meta: [{ title: "Energy monitor — VOLT_GRID" }] }),
  component: EnergyMonitorPage,
});

type Vehicle = {
  id: string;
  name: string;
  plate_number: string;
  battery_kwh: number;
  soc: number;
  category: string;
  company: string;
};

const MIN_SOC = 20;
const MAX_SOC = 80;
const MIN_TX_MW = 1; // 1 MW minimum dispatch
const WINDOW = 60; // 60 points (~1 min @ 1s tick)

type Tick = { t: string; ts: number; available: number; demand: number; surplus: number };

function EnergyMonitorPage() {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [baseline, setBaseline] = useState<Record<string, number>>({});
  const [series, setSeries] = useState<Tick[]>([]);
  const [deltas, setDeltas] = useState<Record<string, { kwh: number; soc: number }>>({});
  const [grid, setGrid] = useState<{ load_mw: number; forecast_mw: number; lmp_usd_mwh: number; interval_utc: string; error?: string } | null>(null);

  const fetchGrid = useServerFn(getLiveGrid);
  const persist = useServerFn(persistDispatch);
  const dirtyRef = useRef<Map<string, number>>(new Map());

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("ev_vehicles")
        .select("id,name,plate_number,battery_kwh,soc,category,company");
      if (data) {
        setVehicles(data as Vehicle[]);
        setBaseline(Object.fromEntries((data as Vehicle[]).map((v) => [v.id, v.soc])));
      }
    })();
  }, []);

  // Poll real CAISO grid every 30s (server caches it).
  useEffect(() => {
    let cancelled = false;
    const pull = async () => {
      try {
        const g = await fetchGrid();
        if (!cancelled) setGrid(g as any);
      } catch (e) {
        console.error("grid fetch failed", e);
      }
    };
    pull();
    const id = setInterval(pull, 30_000);
    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, [fetchGrid]);

  // Persist dirty SoC values every 10s.
  useEffect(() => {
    const id = setInterval(() => {
      if (dirtyRef.current.size === 0) return;
      const updates = Array.from(dirtyRef.current.entries()).map(([id, soc]) => ({ id, soc: +soc.toFixed(2) }));
      dirtyRef.current.clear();
      persist({ data: { updates } }).catch((e) => console.warn("persist failed", e));
    }, 10_000);
    return () => clearInterval(id);
  }, [persist]);

  // Dispatch tick — derives surplus/deficit from live grid + small jitter so
  // the chart breathes between API polls. Updates fleet SoC accordingly.
  useEffect(() => {
    if (!grid) return;
    const tick = () => {
      const now = new Date();
      // Use CAISO actual load as demand and forecast as available capacity proxy.
      // Add small noise (~±0.5%) so the chart is alive between 30s polls.
      const jitter = (base: number) => base * (1 + (Math.random() - 0.5) * 0.01);
      const available = +jitter(grid.forecast_mw || grid.load_mw * 1.02).toFixed(1);
      const demand = +jitter(grid.load_mw).toFixed(1);
      const surplus = +(available - demand).toFixed(1);
      setSeries((prev) => {
        const next = [
          ...prev,
          {
            t: now.toLocaleTimeString([], { hour12: false }),
            ts: now.getTime(),
            available,
            demand,
            surplus,
          },
        ];
        return next.slice(-WINDOW);
      });

      setVehicles((prev) => {
        if (prev.length === 0) return prev;
        // Scale slice by |surplus| as before (1s tick → small kWh slice).
        const sliceKwh = Math.abs(surplus) * 0.5;
        if (sliceKwh <= 0) {
          setDeltas({});
          return prev;
        }

        const resetToBaseline = () => {
          setDeltas({});
          return prev.map((v) => ({ ...v, soc: baseline[v.id] ?? v.soc }));
        };

        const nextDeltas: Record<string, { kwh: number; soc: number }> = {};

        if (surplus < 0) {
          const eligible = prev.filter((v) => v.soc > MIN_SOC);
          const totalAvail = eligible.reduce(
            (s, v) => s + ((v.soc - MIN_SOC) / 100) * v.battery_kwh,
            0,
          );
          if (totalAvail <= 0) return resetToBaseline();
          const take = Math.min(sliceKwh, totalAvail);
          const next = prev.map((v) => {
            if (v.soc <= MIN_SOC) return v;
            const avail = ((v.soc - MIN_SOC) / 100) * v.battery_kwh;
            const share = (avail / totalAvail) * take;
            const newSoc = Math.max(MIN_SOC, v.soc - (share / v.battery_kwh) * 100);
            const rounded = +newSoc.toFixed(2);
            nextDeltas[v.id] = { kwh: -+share.toFixed(2), soc: +(rounded - v.soc).toFixed(2) };
            dirtyRef.current.set(v.id, rounded);
            return { ...v, soc: rounded };
          });
          setDeltas(nextDeltas);
          return next;
        } else {
          const eligible = prev.filter((v) => v.soc < MAX_SOC);
          const totalRoom = eligible.reduce(
            (s, v) => s + ((MAX_SOC - v.soc) / 100) * v.battery_kwh,
            0,
          );
          if (totalRoom <= 0) return resetToBaseline();
          const give = Math.min(sliceKwh, totalRoom);
          const next = prev.map((v) => {
            if (v.soc >= MAX_SOC) return v;
            const room = ((MAX_SOC - v.soc) / 100) * v.battery_kwh;
            const share = (room / totalRoom) * give;
            const newSoc = Math.min(MAX_SOC, v.soc + (share / v.battery_kwh) * 100);
            const rounded = +newSoc.toFixed(2);
            nextDeltas[v.id] = { kwh: +share.toFixed(2), soc: +(rounded - v.soc).toFixed(2) };
            dirtyRef.current.set(v.id, rounded);
            return { ...v, soc: rounded };
          });
          setDeltas(nextDeltas);
          return next;
        }
      });
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [grid, baseline]);


  const current = series[series.length - 1];

  // Dispatch plan — recompute on each tick / fleet change
  const plan = useMemo(() => {
    if (!current || vehicles.length === 0) return null;
    const surplusMw = current.surplus;
    const neededKwh = Math.abs(surplusMw) * 1000; // 1 MW for 1 hour = 1000 kWh proxy
    const minBlockKwh = MIN_TX_MW * 1000;

    if (surplusMw < 0) {
      // Need energy: pull from vehicles with SoC > MIN_SOC, down to MIN_SOC
      const candidates = vehicles
        .filter((v) => v.soc > MIN_SOC)
        .map((v) => ({
          ...v,
          contributableKwh: ((v.soc - MIN_SOC) / 100) * v.battery_kwh,
        }))
        .sort((a, b) => b.contributableKwh - a.contributableKwh);
      const picked: typeof candidates = [];
      let acc = 0;
      for (const c of candidates) {
        picked.push(c);
        acc += c.contributableKwh;
        if (acc >= neededKwh) break;
      }
      return {
        direction: "discharge" as const,
        neededKwh,
        servedKwh: Math.min(acc, neededKwh),
        totalCapacityKwh: acc,
        vehicles: picked,
        feasible: acc >= minBlockKwh,
        unmetKwh: Math.max(0, neededKwh - acc),
      };
    } else {
      // Surplus: charge vehicles under MAX_SOC, up to MAX_SOC
      const candidates = vehicles
        .filter((v) => v.soc < MAX_SOC)
        .map((v) => ({
          ...v,
          absorbableKwh: ((MAX_SOC - v.soc) / 100) * v.battery_kwh,
        }))
        .sort((a, b) => b.absorbableKwh - a.absorbableKwh);
      const picked: typeof candidates = [];
      let acc = 0;
      for (const c of candidates) {
        picked.push(c);
        acc += c.absorbableKwh;
        if (acc >= neededKwh) break;
      }
      return {
        direction: "charge" as const,
        neededKwh,
        servedKwh: Math.min(acc, neededKwh),
        totalCapacityKwh: acc,
        vehicles: picked,
        feasible: acc >= minBlockKwh && neededKwh >= minBlockKwh,
        unmetKwh: Math.max(0, neededKwh - acc),
      };
    }
  }, [current, vehicles]);

  return (
    <div className="min-h-screen flex bg-secondary/30">
      <AppSidebar />
      <PageShell
        title="Energy monitor"
        description={
          grid
            ? `Live CAISO grid · load ${grid.load_mw.toLocaleString()} MW · LMP $${grid.lmp_usd_mwh.toFixed(2)}/MWh · ${new Date(grid.interval_utc).toLocaleTimeString()}`
            : "Connecting to live CAISO grid feed…"
        }
      >

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Metric
            icon={<TrendingUp className="h-4 w-4" />}
            label="Energy available"
            value={current ? `${current.available.toLocaleString()} MW` : "—"}
            hint="Generation + reserves"
            accent="success"
          />
          <Metric
            icon={<TrendingDown className="h-4 w-4" />}
            label="Energy demand"
            value={current ? `${current.demand.toLocaleString()} MW` : "—"}
            hint="System load"
            accent="destructive"
          />
          <Metric
            icon={<Activity className="h-4 w-4" />}
            label="Surplus"
            value={current ? `${current.surplus > 0 ? "+" : ""}${current.surplus} MW` : "—"}
            hint={current && current.surplus < 0 ? "Deficit — pull from fleet" : "Excess — charge fleet"}
            accent={current && current.surplus < 0 ? "destructive" : "success"}
          />
          <Metric
            icon={<Zap className="h-4 w-4" />}
            label="Dispatch direction"
            value={plan ? (plan.direction === "discharge" ? "V2G discharge" : "Fleet charging") : "—"}
            hint={`Min ${MIN_TX_MW} MW per tx`}
            accent="primary"
          />
        </div>

        <Card className="mt-6 p-5">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="font-semibold">Realtime energy flow</h2>
              <p className="text-xs text-muted-foreground">
                Available vs demand (MW), updated every second
              </p>
            </div>
            {current && (
              <Badge
                variant="outline"
                className={
                  current.surplus < 0
                    ? "border-destructive/40 text-destructive"
                    : "border-emerald-500/40 text-emerald-600 dark:text-emerald-400"
                }
              >
                {current.surplus < 0 ? "Deficit" : "Surplus"}
              </Badge>
            )}
          </div>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={series} margin={{ top: 10, right: 16, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis
                  dataKey="t"
                  tick={{ fontSize: 10, fill: "var(--color-muted-foreground)" }}
                  minTickGap={40}
                />
                <YAxis tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }} />
                <Tooltip
                  contentStyle={{
                    background: "var(--color-card)",
                    border: "1px solid var(--color-border)",
                    borderRadius: 8,
                  }}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="available"
                  name="Energy available"
                  stroke="hsl(142 71% 45%)"
                  strokeWidth={2}
                  dot={false}
                  isAnimationActive={false}
                />
                <Line
                  type="monotone"
                  dataKey="demand"
                  name="Energy demand"
                  stroke="hsl(0 84% 60%)"
                  strokeWidth={2}
                  dot={false}
                  isAnimationActive={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="mt-6 overflow-hidden">
          <div className="px-4 py-3 border-b border-border flex items-center justify-between">
            <div>
              <h2 className="font-semibold text-sm">
                Dispatch plan — {plan?.direction === "discharge" ? "Pull from fleet (V2G)" : "Charge fleet"}
              </h2>
              <p className="text-xs text-muted-foreground">
                {plan
                  ? `Target ${(plan.neededKwh / 1000).toFixed(2)} MWh · serving ${(plan.servedKwh / 1000).toFixed(2)} MWh from ${plan.vehicles.length} vehicles`
                  : "Waiting for telemetry…"}
              </p>
            </div>
            {plan && (
              <Badge
                className={
                  plan.feasible
                    ? "bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border-emerald-500/40"
                    : "bg-amber-500/15 text-amber-600 dark:text-amber-400 border-amber-500/40"
                }
                variant="outline"
              >
                {plan.feasible ? "Feasible ≥ 1 MW" : "Below 1 MW threshold"}
              </Badge>
            )}
          </div>
          <div className="max-h-[420px] overflow-y-auto overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted text-foreground text-xs font-bold uppercase tracking-wider sticky top-0 z-10">
                <tr>
                  <th className="text-left px-4 py-2">Vehicle</th>
                  <th className="text-left px-4 py-2">Category</th>
                  <th className="text-left px-4 py-2">Company</th>
                  <th className="text-right px-4 py-2">Battery (kWh)</th>
                  <th className="text-right px-4 py-2">SoC</th>
                  <th className="text-right px-4 py-2">
                    {plan?.direction === "discharge" ? "Contrib. (kWh)" : "Absorb (kWh)"}
                  </th>
                  <th className="text-right px-4 py-2">Live Δ kWh / tick</th>
                  <th className="text-right px-4 py-2">Live Δ SoC</th>
                </tr>
              </thead>
              <tbody>
                {plan?.vehicles.map((v) => {
                  const kwh =
                    plan.direction === "discharge"
                      ? (v as any).contributableKwh
                      : (v as any).absorbableKwh;
                  const d = deltas[v.id];
                  const isCharge = d && d.kwh > 0;
                  const isDischarge = d && d.kwh < 0;
                  return (
                    <tr key={v.id} className="border-t border-border">
                      <td className="px-4 py-2 font-medium">
                        {v.name}{" "}
                        <span className="text-muted-foreground text-xs">{v.plate_number}</span>
                      </td>
                      <td className="px-4 py-2">
                        <Badge variant="outline">{v.category}</Badge>
                      </td>
                      <td className="px-4 py-2">{v.company}</td>
                      <td className="px-4 py-2 text-right">{v.battery_kwh}</td>
                      <td className="px-4 py-2 text-right">{v.soc}%</td>
                      <td className="px-4 py-2 text-right font-medium">{kwh.toFixed(1)}</td>
                      <td
                        className={`px-4 py-2 text-right font-mono text-xs ${
                          isCharge
                            ? "text-emerald-600 dark:text-emerald-400"
                            : isDischarge
                              ? "text-destructive"
                              : "text-muted-foreground"
                        }`}
                      >
                        {d ? `${d.kwh > 0 ? "+" : ""}${d.kwh.toFixed(2)}` : "—"}
                      </td>
                      <td
                        className={`px-4 py-2 text-right font-mono text-xs ${
                          isCharge
                            ? "text-emerald-600 dark:text-emerald-400"
                            : isDischarge
                              ? "text-destructive"
                              : "text-muted-foreground"
                        }`}
                      >
                        {d ? `${d.soc > 0 ? "+" : ""}${d.soc.toFixed(2)}%` : "—"}
                      </td>
                    </tr>
                  );
                })}
                {plan && plan.vehicles.length === 0 && (
                  <tr>
                    <td colSpan={8} className="px-4 py-6 text-center text-muted-foreground">
                      No eligible vehicles for current direction.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>
      </PageShell>
    </div>
  );
}

function Metric({
  icon,
  label,
  value,
  hint,
  accent,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  hint: string;
  accent: "primary" | "success" | "warning" | "destructive" | "muted";
}) {
  const accentClass =
    accent === "primary"
      ? "bg-primary/10 text-primary"
      : accent === "success"
        ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
        : accent === "warning"
          ? "bg-amber-500/10 text-amber-600 dark:text-amber-400"
          : accent === "destructive"
            ? "bg-destructive/10 text-destructive"
            : "bg-muted text-muted-foreground";
  return (
    <Card className="p-4">
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <span className={`rounded-md p-1.5 ${accentClass}`}>{icon}</span>
        {label}
      </div>
      <div className="mt-2 text-2xl font-semibold">{value}</div>
      <div className="text-xs text-muted-foreground mt-0.5">{hint}</div>
    </Card>
  );
}
