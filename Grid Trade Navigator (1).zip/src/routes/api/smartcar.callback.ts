import { createFileRoute } from "@tanstack/react-router";
import {
  exchangeCode,
  syncVehiclesForUser,
  verifyState,
} from "@/lib/api/smartcar.server";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export const Route = createFileRoute("/api/smartcar/callback")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const code = url.searchParams.get("code");
        const state = url.searchParams.get("state");
        const error = url.searchParams.get("error");
        const redirectBase = `${url.protocol}//${url.host}`;

        const back = (params: Record<string, string>) => {
          const r = new URL("/fleet-manager", redirectBase);
          for (const [k, v] of Object.entries(params)) r.searchParams.set(k, v);
          return Response.redirect(r.toString(), 302);
        };

        if (error) return back({ smartcar: "error", reason: error });
        if (!code || !state) return back({ smartcar: "error", reason: "missing_code" });

        const userId = verifyState(state);
        if (!userId) return back({ smartcar: "error", reason: "bad_state" });

        try {
          const redirectUri = `${redirectBase}/api/smartcar/callback`;
          const tok = await exchangeCode(code, redirectUri);
          const expiresAt = new Date(Date.now() + tok.expires_in * 1000).toISOString();

          await supabaseAdmin.from("smartcar_tokens").upsert(
            {
              user_id: userId,
              access_token: tok.access_token,
              refresh_token: tok.refresh_token,
              expires_at: expiresAt,
              updated_at: new Date().toISOString(),
            },
            { onConflict: "user_id" },
          );

          const synced = await syncVehiclesForUser(userId);
          return back({ smartcar: "connected", count: String(synced.count) });
        } catch (e: any) {
          console.error("[smartcar.callback]", e);
          return back({ smartcar: "error", reason: (e?.message ?? "exchange_failed").slice(0, 80) });
        }
      },
    },
  },
});
