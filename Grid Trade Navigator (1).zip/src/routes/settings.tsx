import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { AppSidebar } from "@/components/AppSidebar";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useAuth, roleLabel } from "@/lib/auth";
import { useTheme } from "@/lib/theme";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Link } from "@tanstack/react-router";
import { Sun, Moon, User, Bell, Palette, LogOut, Save, Home } from "lucide-react";

export const Route = createFileRoute("/settings")({
  head: () => ({ meta: [{ title: "Settings — VOLT_GRID" }] }),
  component: SettingsPage,
});

function SettingsPage() {
  const { user, role, loading, signOut } = useAuth();
  const { theme, setTheme } = useTheme();
  const navigate = useNavigate();

  const [displayName, setDisplayName] = useState("");
  const [company, setCompany] = useState("");
  const [savingProfile, setSavingProfile] = useState(false);
  const [loadingProfile, setLoadingProfile] = useState(true);

  const [thresholdLow, setThresholdLow] = useState(30);
  const [thresholdHigh, setThresholdHigh] = useState(150);
  const [alertsEnabled, setAlertsEnabled] = useState(true);
  const [savingAlerts, setSavingAlerts] = useState(false);

  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth" });
  }, [loading, user, navigate]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data: profile } = await supabase
        .from("profiles")
        .select("display_name, company")
        .eq("id", user.id)
        .maybeSingle();
      if (profile) {
        setDisplayName(profile.display_name ?? "");
        setCompany(profile.company ?? "");
      }
      const { data: alert } = await supabase
        .from("price_alerts")
        .select("threshold_low, threshold_high, enabled")
        .eq("user_id", user.id)
        .maybeSingle();
      if (alert) {
        setThresholdLow(Number(alert.threshold_low));
        setThresholdHigh(Number(alert.threshold_high));
        setAlertsEnabled(alert.enabled);
      }
      setLoadingProfile(false);
    })();
  }, [user]);

  async function saveProfile() {
    if (!user) return;
    setSavingProfile(true);
    const { error } = await supabase
      .from("profiles")
      .update({ display_name: displayName, company })
      .eq("id", user.id);
    setSavingProfile(false);
    if (error) toast.error(error.message);
    else toast.success("Profile updated");
  }

  async function saveAlerts() {
    if (!user) return;
    setSavingAlerts(true);
    const { error } = await supabase
      .from("price_alerts")
      .update({
        threshold_low: thresholdLow,
        threshold_high: thresholdHigh,
        enabled: alertsEnabled,
      })
      .eq("user_id", user.id);
    setSavingAlerts(false);
    if (error) toast.error(error.message);
    else toast.success("Alerts updated");
  }

  if (loading || !user) {
    return (
      <div className="flex min-h-screen items-center justify-center text-muted-foreground">
        Loading…
      </div>
    );
  }

  return (
    <div className="min-h-screen flex bg-secondary/30">
      <AppSidebar />
      <main className="flex-1 min-w-0">
        <header className="border-b border-border bg-background">
          <div className="flex h-16 items-center justify-between px-6">
            <div>
              <h1 className="text-lg font-semibold">Settings</h1>
              <p className="text-xs text-muted-foreground">
                Manage your account, appearance and alert preferences
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" asChild>
                <Link to="/dashboard">
                  <Home className="h-4 w-4 mr-1" /> Home
                </Link>
              </Button>
              <Button variant="ghost" size="sm" onClick={signOut}>
                <LogOut className="h-4 w-4 mr-1" /> Sign out
              </Button>
            </div>
          </div>
        </header>

        <div className="px-6 py-8 max-w-4xl mx-auto space-y-6">
          {/* Profile */}
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="rounded-md bg-primary/10 text-primary p-2">
                <User className="h-4 w-4" />
              </div>
              <div className="flex-1">
                <h2 className="font-semibold">Profile</h2>
                <p className="text-xs text-muted-foreground">
                  How your name appears across VOLT_GRID
                </p>
              </div>
              <Badge variant="secondary">{role ? roleLabel[role] : "—"}</Badge>
            </div>
            <Separator className="mb-4" />
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" value={user.email ?? ""} disabled />
              </div>
              <div className="space-y-2">
                <Label htmlFor="display_name">Display name</Label>
                <Input
                  id="display_name"
                  value={displayName}
                  placeholder="Your name"
                  onChange={(e) => setDisplayName(e.target.value)}
                  disabled={loadingProfile}
                />
              </div>
              <div className="space-y-2 sm:col-span-2">
                <Label htmlFor="company">Company</Label>
                <Input
                  id="company"
                  value={company}
                  placeholder="Acme Mobility"
                  onChange={(e) => setCompany(e.target.value)}
                  disabled={loadingProfile}
                />
              </div>
            </div>
            <div className="mt-4 flex justify-end">
              <Button onClick={saveProfile} disabled={savingProfile || loadingProfile}>
                <Save className="h-4 w-4 mr-1" />
                {savingProfile ? "Saving…" : "Save profile"}
              </Button>
            </div>
          </Card>

          {/* Appearance */}
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="rounded-md bg-primary/10 text-primary p-2">
                <Palette className="h-4 w-4" />
              </div>
              <div>
                <h2 className="font-semibold">Appearance</h2>
                <p className="text-xs text-muted-foreground">
                  Switch between light and dark themes
                </p>
              </div>
            </div>
            <Separator className="mb-4" />
            <div className="grid gap-3 sm:grid-cols-2">
              <ThemeOption
                active={theme === "light"}
                onClick={() => setTheme("light")}
                icon={<Sun className="h-4 w-4" />}
                title="Light"
                description="Bright, high-contrast UI for daytime use."
              />
              <ThemeOption
                active={theme === "dark"}
                onClick={() => setTheme("dark")}
                icon={<Moon className="h-4 w-4" />}
                title="Dark"
                description="Easy on the eyes for low-light environments."
              />
            </div>
            <div className="mt-4 flex items-center justify-between rounded-md border border-border p-3">
              <div>
                <p className="text-sm font-medium">Dark mode</p>
                <p className="text-xs text-muted-foreground">
                  Toggle the active theme instantly.
                </p>
              </div>
              <Switch
                checked={theme === "dark"}
                onCheckedChange={(v) => setTheme(v ? "dark" : "light")}
              />
            </div>
          </Card>

          {/* Alerts */}
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="rounded-md bg-primary/10 text-primary p-2">
                <Bell className="h-4 w-4" />
              </div>
              <div>
                <h2 className="font-semibold">Price alerts</h2>
                <p className="text-xs text-muted-foreground">
                  Get notified when wholesale prices cross your thresholds
                </p>
              </div>
            </div>
            <Separator className="mb-4" />
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="low">Low threshold (€/MWh)</Label>
                <Input
                  id="low"
                  type="number"
                  value={thresholdLow}
                  onChange={(e) => setThresholdLow(Number(e.target.value))}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="high">High threshold (€/MWh)</Label>
                <Input
                  id="high"
                  type="number"
                  value={thresholdHigh}
                  onChange={(e) => setThresholdHigh(Number(e.target.value))}
                />
              </div>
            </div>
            <div className="mt-4 flex items-center justify-between rounded-md border border-border p-3">
              <div>
                <p className="text-sm font-medium">Enable alerts</p>
                <p className="text-xs text-muted-foreground">Receive notifications in-app.</p>
              </div>
              <Switch checked={alertsEnabled} onCheckedChange={setAlertsEnabled} />
            </div>
            <div className="mt-4 flex justify-end">
              <Button onClick={saveAlerts} disabled={savingAlerts}>
                <Save className="h-4 w-4 mr-1" />
                {savingAlerts ? "Saving…" : "Save alerts"}
              </Button>
            </div>
          </Card>
        </div>
      </main>
    </div>
  );
}

function ThemeOption({
  active,
  onClick,
  icon,
  title,
  description,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`text-left rounded-lg border p-4 transition-all hover:border-primary/60 ${
        active ? "border-primary ring-2 ring-primary/20 bg-primary/5" : "border-border"
      }`}
    >
      <div className="flex items-center gap-2 mb-1">
        <span className="rounded-md bg-muted p-1.5">{icon}</span>
        <span className="font-medium">{title}</span>
        {active && <Badge variant="secondary" className="ml-auto">Active</Badge>}
      </div>
      <p className="text-xs text-muted-foreground">{description}</p>
    </button>
  );
}
