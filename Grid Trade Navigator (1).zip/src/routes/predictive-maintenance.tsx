import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { AppSidebar } from "@/components/AppSidebar";
import { PageShell } from "@/components/PageShell";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Wrench, CalendarClock, TrendingDown, CalendarPlus, Flame, Activity, Gauge, Stethoscope } from "lucide-react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";
import sessionsCsv from "@/assets/battery-sessions.csv?raw";
import { toast } from "sonner";

export const Route = createFileRoute("/predictive-maintenance")({
  head: () => ({
    meta: [
      { title: "Predictive maintenance — VOLT_GRID" },
      {
        name: "description",
        content:
          "Maintenance priority scoring (0–100) for the EV fleet with risk factors and replacement-cost estimates.",
      },
    ],
  }),
  component: PredictiveMaintenancePage,
});

type Row = {
  vehicle_name: string;
  plate_number: string;
  battery_capacity_kwh: number;
  current_soh_pct: number;
  in_service_since: string;
  distance_km: number;
  v2g_degradation_pct: number;
  operational_degradation_pct: number;
  peak_kw: number;
  soc_start_pct: number;
  soc_end_pct: number;
};

const EOL_PCT = 70;
const EXPECTED_CYCLES = 3000; // expected lifecycle for LFP/NMC bus packs
const REPLACEMENT_EUR_PER_KWH = 300;

function parseCsv(csv: string): Row[] {
  const lines = csv.trim().split(/\r?\n/);
  const headers = lines[0].split(",").map((h) => h.trim());
  return lines.slice(1).map((line) => {
    const cols = line.split(",").map((c) => c.trim());
    const row: Record<string, string> = {};
    headers.forEach((h, i) => (row[h] = cols[i] ?? ""));
    return {
      vehicle_name: row.vehicle_name,
      plate_number: row.plate_number,
      battery_capacity_kwh: Number(row.battery_capacity_kwh),
      current_soh_pct: Number(row.current_soh_pct),
      in_service_since: row.in_service_since,
      distance_km: Number(row.distance_km),
      v2g_degradation_pct: Number(row.v2g_degradation_pct),
      operational_degradation_pct: Number(row.operational_degradation_pct),
      peak_kw: Number(row.peak_kw),
      soc_start_pct: Number(row.soc_start_pct),
      soc_end_pct: Number(row.soc_end_pct),
    };
  });
}

function ageYears(d: string): number {
  const t = new Date(d).getTime();
  if (Number.isNaN(t)) return 0;
  return (Date.now() - t) / (1000 * 60 * 60 * 24 * 365.25);
}

// Deterministic pseudo-random per vehicle (so values don't change on re-render)
function seeded(plate: string, salt: number): number {
  let h = 2166136261 ^ salt;
  for (let i = 0; i < plate.length; i++) {
    h ^= plate.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return ((h >>> 0) % 10000) / 10000; // 0..1
}

type FactorKey = "sohRate" | "cycles" | "thermal" | "diagnostic" | "soc";
type Factor = {
  key: FactorKey;
  label: string;
  weight: number;
  score: number; // 0..100
  detail: string;
  icon: React.ReactNode;
};

function score(row: Row) {
  const age = Math.max(0.25, ageYears(row.in_service_since));
  const lost = Math.max(0.1, 100 - row.current_soh_pct);
  const ratePerYear = lost / age; // %/yr observed
  const yearsToEol = Math.max(0, (row.current_soh_pct - EOL_PCT) / ratePerYear);
  const eolDate = new Date(Date.now() + yearsToEol * 365.25 * 24 * 3600 * 1000);

  // 1) Degradation-rate score — 0 at 1%/yr, 100 at 6%/yr
  const sohRateScore = clamp((ratePerYear - 1) * 20, 0, 100);

  // 2) Cycle count vs expected — ~1 cycle per 350 km
  const cycles = Math.round(row.distance_km / 350);
  const cycleScore = clamp((cycles / EXPECTED_CYCLES) * 100, 0, 100);

  // 3) Thermal stress events (last 30 days) — derived from peak kW + recent stress
  const thermalEvents = Math.round(
    (row.peak_kw / 200) * 6 + seeded(row.plate_number, 11) * 5,
  );
  const thermalScore = clamp(thermalEvents * 8, 0, 100);

  // 4) Days since last full diagnostic
  const daysSinceDiag = Math.round(40 + seeded(row.plate_number, 23) * 320);
  const diagnosticScore = clamp((daysSinceDiag / 365) * 100, 0, 100);

  // 5) Abnormal SoC deviation events
  const socDeviationEvents = Math.round(
    Math.abs(row.soc_start_pct - row.soc_end_pct) / 12 +
      seeded(row.plate_number, 37) * 6,
  );
  const socScore = clamp(socDeviationEvents * 10, 0, 100);

  const factors: Factor[] = [
    {
      key: "sohRate",
      label: "SoH degradation rate",
      weight: 0.35,
      score: sohRateScore,
      detail: `${ratePerYear.toFixed(2)} %/yr`,
      icon: <TrendingDown className="h-3.5 w-3.5" />,
    },
    {
      key: "cycles",
      label: "Cycle count vs expected",
      weight: 0.25,
      score: cycleScore,
      detail: `${cycles.toLocaleString()} / ${EXPECTED_CYCLES.toLocaleString()} cycles`,
      icon: <Activity className="h-3.5 w-3.5" />,
    },
    {
      key: "thermal",
      label: "Thermal stress events (30d)",
      weight: 0.2,
      score: thermalScore,
      detail: `${thermalEvents} events`,
      icon: <Flame className="h-3.5 w-3.5" />,
    },
    {
      key: "diagnostic",
      label: "Days since last diagnostic",
      weight: 0.1,
      score: diagnosticScore,
      detail: `${daysSinceDiag} days`,
      icon: <Stethoscope className="h-3.5 w-3.5" />,
    },
    {
      key: "soc",
      label: "Abnormal SoC deviation",
      weight: 0.1,
      score: socScore,
      detail: `${socDeviationEvents} events`,
      icon: <Gauge className="h-3.5 w-3.5" />,
    },
  ];

  const priority = Math.round(
    factors.reduce((s, f) => s + f.score * f.weight, 0),
  );

  // Predicted days until next maintenance needed — higher score → sooner
  const daysToNext = Math.max(3, Math.round(180 * (1 - priority / 100)));

  const replacementCost = Math.round(row.battery_capacity_kwh * REPLACEMENT_EUR_PER_KWH);

  return {
    ratePerYear,
    yearsToEol,
    eolDate,
    soh12: Math.max(0, row.current_soh_pct - ratePerYear * 1),
    cycles,
    factors,
    priority,
    daysToNext,
    replacementCost,
  };
}

function clamp(n: number, lo: number, hi: number) {
  return Math.max(lo, Math.min(hi, n));
}

type Tier = "critical" | "warning" | "healthy";
function tierOf(score: number): Tier {
  if (score >= 70) return "critical";
  if (score >= 40) return "warning";
  return "healthy";
}

const TIER_META: Record<Tier, { label: string; emoji: string; text: string; cls: string; pillCls: string; ring: string }> = {
  critical: {
    label: "CRITICAL",
    emoji: "🔴",
    text: "Requires attention within 7 days",
    cls: "border-destructive/40 text-destructive bg-destructive/10",
    pillCls: "bg-destructive text-destructive-foreground",
    ring: "ring-destructive/40",
  },
  warning: {
    label: "WARNING",
    emoji: "🟡",
    text: "Monitor closely — schedule within 30 days",
    cls: "border-amber-500/40 text-amber-600 dark:text-amber-400 bg-amber-500/10",
    pillCls: "bg-amber-500 text-white",
    ring: "ring-amber-500/40",
  },
  healthy: {
    label: "HEALTHY",
    emoji: "🟢",
    text: "No action needed",
    cls: "border-emerald-500/40 text-emerald-600 dark:text-emerald-400 bg-emerald-500/10",
    pillCls: "bg-emerald-500 text-white",
    ring: "ring-emerald-500/40",
  },
};

function PredictiveMaintenancePage() {
  const rows = useMemo(() => parseCsv(sessionsCsv), []);
  const enriched = useMemo(
    () =>
      rows
        .map((r) => ({ ...r, ...score(r) }))
        .sort((a, b) => b.priority - a.priority),
    [rows],
  );

  const [filter, setFilter] = useState<"all" | Tier>("all");
  const filtered = useMemo(
    () => (filter === "all" ? enriched : enriched.filter((e) => tierOf(e.priority) === filter)),
    [enriched, filter],
  );

  const fleetMetrics = useMemo(() => {
    const total = enriched.length || 1;
    const critical = enriched.filter((e) => tierOf(e.priority) === "critical").length;
    const warning = enriched.filter((e) => tierOf(e.priority) === "warning").length;
    const healthy = enriched.filter((e) => tierOf(e.priority) === "healthy").length;
    const avgRate = enriched.reduce((s, e) => s + e.ratePerYear, 0) / total;
    return { total: enriched.length, critical, warning, healthy, avgRate };
  }, [enriched]);

  const projection = useMemo(() => {
    const months = 24;
    const out: { month: string; avgSoh: number }[] = [];
    for (let m = 0; m <= months; m++) {
      const sum = enriched.reduce(
        (s, e) => s + Math.max(0, e.current_soh_pct - e.ratePerYear * (m / 12)),
        0,
      );
      out.push({ month: `+${m}mo`, avgSoh: sum / (enriched.length || 1) });
    }
    return out;
  }, [enriched]);

  const topThree = enriched.slice(0, 3);

  function schedule(plate: string, name: string) {
    toast.success(`Maintenance scheduled for ${name}`, {
      description: `${plate} — work order created and assigned to the next available bay.`,
    });
  }

  return (
    <div className="min-h-screen flex bg-secondary/30">
      <AppSidebar />
      <PageShell
        title="Predictive maintenance"
        description="Maintenance Priority Score (0–100) per vehicle, weighted from degradation, cycles, thermal stress, diagnostic recency and SoC deviation."
      >
        {/* Top 3 most critical */}
        <Card className="p-4">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="text-sm font-semibold flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-destructive" />
                Top 3 most critical vehicles
              </h2>
              <p className="text-xs text-muted-foreground">Highest priority scores in the fleet right now.</p>
            </div>
          </div>
          <div className="grid gap-3 md:grid-cols-3">
            {topThree.map((v, i) => {
              const tier = tierOf(v.priority);
              const meta = TIER_META[tier];
              return (
                <div
                  key={v.plate_number}
                  className={`rounded-lg border bg-card p-4 ring-1 ${meta.ring}`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">
                        #{i + 1} priority
                      </div>
                      <div className="font-semibold text-base mt-0.5 leading-tight">
                        {v.vehicle_name}
                      </div>
                      <div className="text-xs text-muted-foreground">{v.plate_number}</div>
                    </div>
                    <div
                      className={`rounded-lg px-3 py-2 text-center ${meta.pillCls}`}
                      aria-label={`${meta.label} priority score ${v.priority}`}
                    >
                      <div className="text-2xl font-bold leading-none">{v.priority}</div>
                      <div className="text-[9px] tracking-wider mt-0.5">{meta.label}</div>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground mt-3">{meta.text}</p>
                  <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-muted-foreground">
                    <span>SoH {v.current_soh_pct.toFixed(1)}%</span>
                    <span>Next maint. in {v.daysToNext}d</span>
                    <span>Replace cost €{v.replacementCost.toLocaleString()}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>

        <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Kpi icon={<AlertTriangle className="h-4 w-4" />} label="Critical (70–100)" value={String(fleetMetrics.critical)} tone="destructive" />
          <Kpi icon={<Wrench className="h-4 w-4" />} label="Warning (40–69)" value={String(fleetMetrics.warning)} tone="warning" />
          <Kpi icon={<CalendarClock className="h-4 w-4" />} label="Healthy (0–39)" value={String(fleetMetrics.healthy)} tone="primary" />
          <Kpi icon={<TrendingDown className="h-4 w-4" />} label="Avg degradation" value={`${fleetMetrics.avgRate.toFixed(2)} %/yr`} tone="muted" />
        </div>

        <Card className="mt-6 p-6">
          <h2 className="font-semibold text-sm">Fleet SoH projection — next 24 months</h2>
          <p className="text-xs text-muted-foreground mb-2">
            Extrapolated from each vehicle's observed degradation rate.
          </p>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={projection} margin={{ top: 10, right: 16, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }} />
                <YAxis domain={[60, 100]} tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }} />
                <Tooltip
                  contentStyle={{
                    background: "var(--color-card)",
                    border: "1px solid var(--color-border)",
                    borderRadius: 8,
                  }}
                  formatter={(v: any) => [`${Number(v).toFixed(1)}%`, "Avg SoH"]}
                />
                <Legend />
                <Line type="monotone" dataKey="avgSoh" name="Avg SoH" stroke="var(--color-primary)" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>

        {/* Maintenance queue */}
        <Card className="mt-6 overflow-hidden">
          <div className="px-4 py-3 border-b border-border flex items-center justify-between gap-3 flex-wrap">
            <div>
              <h2 className="font-semibold text-sm">Maintenance queue</h2>
              <p className="text-xs text-muted-foreground">
                Sorted by Maintenance Priority Score (descending). Showing {filtered.length} of {enriched.length} vehicles.
              </p>
            </div>
            <div className="flex items-center gap-1 rounded-md border border-border p-1 bg-muted/40">
              {(["all", "critical", "warning", "healthy"] as const).map((f) => {
                const active = filter === f;
                const label = f === "all" ? "All" : TIER_META[f].label;
                return (
                  <button
                    key={f}
                    type="button"
                    onClick={() => setFilter(f)}
                    className={`text-[11px] px-3 py-1 rounded transition-colors ${
                      active
                        ? "bg-card shadow-sm text-foreground font-medium"
                        : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {f !== "all" && <span className="mr-1">{TIER_META[f].emoji}</span>}
                    {label}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="max-h-[420px] overflow-y-auto overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted text-foreground text-[11px] font-bold uppercase tracking-wider sticky top-0 z-10">
                <tr>
                  <th className="text-center px-3 py-2 w-16">Score</th>
                  <th className="text-left px-3 py-2">Vehicle</th>
                  <th className="text-center px-3 py-2">Tier</th>
                  <th className="text-left px-3 py-2">Top risk factors</th>
                  <th className="text-right px-3 py-2">Next maint.</th>
                  <th className="text-right px-3 py-2">Replace cost</th>
                  <th className="text-center px-3 py-2">Action</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((v) => {
                  const tier = tierOf(v.priority);
                  const meta = TIER_META[tier];
                  const top2 = [...v.factors]
                    .sort((a, b) => b.score * b.weight - a.score * a.weight)
                    .slice(0, 2);
                  return (
                    <tr key={v.plate_number} className="border-t border-border align-middle">
                      <td className="px-3 py-2 text-center">
                        <div className={`inline-flex flex-col items-center justify-center rounded-md px-2 py-1 min-w-[52px] ${meta.pillCls}`}>
                          <span className="text-lg font-bold leading-none">{v.priority}</span>
                        </div>
                      </td>
                      <td className="px-3 py-2">
                        <div className="font-medium">{v.vehicle_name}</div>
                        <div className="text-[11px] text-muted-foreground">{v.plate_number}</div>
                      </td>
                      <td className="px-3 py-2 text-center">
                        <Badge variant="outline" className={meta.cls}>
                          {meta.emoji} {meta.label}
                        </Badge>
                      </td>
                      <td className="px-3 py-2">
                        <ul className="space-y-1">
                          {top2.map((f) => (
                            <li key={f.key} className="flex items-center gap-2 text-xs">
                              <span className="rounded bg-muted p-1 text-muted-foreground">{f.icon}</span>
                              <span className="min-w-0">
                                <span className="font-medium">{f.label}</span>
                                <span className="text-muted-foreground"> · {f.detail}</span>
                              </span>
                              <span className="ml-auto text-[11px] font-semibold tabular-nums">{Math.round(f.score)}</span>
                            </li>
                          ))}
                        </ul>
                      </td>
                      <td className="px-3 py-2 text-right whitespace-nowrap">{v.daysToNext} days</td>
                      <td className="px-3 py-2 text-right whitespace-nowrap">€{v.replacementCost.toLocaleString()}</td>
                      <td className="px-3 py-2 text-center">
                        <Button
                          size="sm"
                          variant={tier === "healthy" ? "outline" : "default"}
                          className="gap-1.5"
                          onClick={() => schedule(v.plate_number, v.vehicle_name)}
                        >
                          <CalendarPlus className="h-3.5 w-3.5" />
                          Schedule
                        </Button>
                      </td>
                    </tr>
                  );
                })}
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={7} className="text-center text-sm text-muted-foreground py-10">
                      No vehicles match this filter.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>
      </PageShell>
    </div>
  );
}

function Kpi({
  icon,
  label,
  value,
  tone,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  tone: "primary" | "warning" | "destructive" | "muted";
}) {
  const cls =
    tone === "destructive"
      ? "bg-destructive/10 text-destructive"
      : tone === "warning"
        ? "bg-amber-500/10 text-amber-600 dark:text-amber-400"
        : tone === "primary"
          ? "bg-primary/10 text-primary"
          : "bg-muted text-muted-foreground";
  return (
    <Card className="p-4">
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <span className={`rounded-md p-1.5 ${cls}`}>{icon}</span>
        {label}
      </div>
      <div className="mt-2 text-2xl font-semibold">{value}</div>
    </Card>
  );
}
