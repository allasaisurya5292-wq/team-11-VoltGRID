import { createFileRoute } from "@tanstack/react-router";
import { useMemo } from "react";
import { AppSidebar } from "@/components/AppSidebar";
import { PageShell } from "@/components/PageShell";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ShieldCheck, Thermometer, Gauge, BatteryCharging, CheckCircle2 } from "lucide-react";
import sessionsCsv from "@/assets/battery-sessions.csv?raw";

export const Route = createFileRoute("/battery-prevention")({
  head: () => ({
    meta: [
      { title: "Battery prevention systems — VOLT_GRID" },
      {
        name: "description",
        content:
          "Battery preservation policies and per-vehicle recommendations to slow degradation.",
      },
    ],
  }),
  component: BatteryPreventionPage,
});

type Row = {
  vehicle_name: string;
  plate_number: string;
  current_soh_pct: number;
  in_service_since: string;
  v2g_degradation_pct: number;
  operational_degradation_pct: number;
  peak_kw: number;
  battery_capacity_kwh: number;
};

function parseCsv(csv: string): Row[] {
  const lines = csv.trim().split(/\r?\n/);
  const headers = lines[0].split(",").map((h) => h.trim());
  return lines.slice(1).map((line) => {
    const cols = line.split(",").map((c) => c.trim());
    const row: Record<string, string> = {};
    headers.forEach((h, i) => (row[h] = cols[i] ?? ""));
    return {
      vehicle_name: row.vehicle_name,
      plate_number: row.plate_number,
      current_soh_pct: Number(row.current_soh_pct),
      in_service_since: row.in_service_since,
      v2g_degradation_pct: Number(row.v2g_degradation_pct),
      operational_degradation_pct: Number(row.operational_degradation_pct),
      peak_kw: Number(row.peak_kw),
      battery_capacity_kwh: Number(row.battery_capacity_kwh),
    };
  });
}

function recommendations(r: Row): string[] {
  const recs: string[] = [];
  const cRate = r.peak_kw / (r.battery_capacity_kwh || 1);
  if (r.current_soh_pct < 80) {
    recs.push("Cap V2G discharge depth at 20% DoD per session");
    recs.push("Schedule cell-level diagnostic in next service window");
  } else if (r.current_soh_pct < 90) {
    recs.push("Limit fast-charge to ≤1C and prefer overnight slow-charge");
  } else {
    recs.push("Maintain SoC window 20–80% for daily ops");
  }
  if (cRate > 0.04) recs.push("Reduce peak power draw — current C-rate is high");
  if (r.v2g_degradation_pct > 4) recs.push("Throttle V2G dispatch frequency to 1×/day max");
  if (r.operational_degradation_pct > 5) recs.push("Add weekly thermal management check");
  return recs;
}

function BatteryPreventionPage() {
  const rows = useMemo(() => parseCsv(sessionsCsv), []);

  const policies = [
    {
      icon: <Gauge className="h-4 w-4" />,
      title: "SoC window",
      value: "20% – 80%",
      hint: "Avoid full-charge and deep-discharge cycles for daily ops",
    },
    {
      icon: <BatteryCharging className="h-4 w-4" />,
      title: "Max charge C-rate",
      value: "≤ 1C",
      hint: "Reserve >1C fast-charging for emergency dispatch",
    },
    {
      icon: <Thermometer className="h-4 w-4" />,
      title: "Pack temperature",
      value: "15 – 35 °C",
      hint: "Active cooling above 35 °C; preheat below 5 °C",
    },
    {
      icon: <ShieldCheck className="h-4 w-4" />,
      title: "V2G dispatch cap",
      value: "20% DoD / day",
      hint: "Stay under 1.8 %/yr cumulative degradation budget",
    },
  ];

  const compliance = useMemo(() => {
    const total = rows.length || 1;
    const sohOk = rows.filter((r) => r.current_soh_pct >= 80).length;
    const v2gOk = rows.filter((r) => r.v2g_degradation_pct <= 4).length;
    const opOk = rows.filter((r) => r.operational_degradation_pct <= 5).length;
    return {
      sohPct: Math.round((sohOk / total) * 100),
      v2gPct: Math.round((v2gOk / total) * 100),
      opPct: Math.round((opOk / total) * 100),
    };
  }, [rows]);

  return (
    <div className="min-h-screen flex bg-secondary/30">
      <AppSidebar />
      <PageShell
        title="Battery prevention systems"
        description="Operating policies and per-vehicle actions that slow battery wear."
      >
        <Card className="p-6">
          <h2 className="font-semibold">Fleet preservation policies</h2>
          <p className="text-xs text-muted-foreground mb-4">
            Apply across all vehicles unless overridden by a per-vehicle action below.
          </p>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {policies.map((p) => (
              <div key={p.title} className="rounded-md border border-border p-3">
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <span className="rounded-md p-1.5 bg-primary/10 text-primary">{p.icon}</span>
                  {p.title}
                </div>
                <div className="mt-2 text-xl font-semibold">{p.value}</div>
                <div className="text-xs text-muted-foreground mt-0.5">{p.hint}</div>
              </div>
            ))}
          </div>
        </Card>

        <div className="mt-6 grid gap-4 sm:grid-cols-3">
          <ComplianceCard label="SoH ≥ 80%" pct={compliance.sohPct} />
          <ComplianceCard label="V2G degradation ≤ 4%" pct={compliance.v2gPct} />
          <ComplianceCard label="Operational degradation ≤ 5%" pct={compliance.opPct} />
        </div>

        <Card className="mt-6 overflow-hidden">
          <div className="px-4 py-3 border-b border-border">
            <h2 className="font-semibold text-sm">Per-vehicle prevention actions</h2>
            <p className="text-xs text-muted-foreground">
              Recommended interventions derived from current SoH, C-rate and degradation share.
            </p>
          </div>
          <div className="max-h-[520px] overflow-y-auto overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted text-foreground text-xs font-bold uppercase tracking-wider sticky top-0 z-10">
                <tr>
                  <th className="text-left px-4 py-2">Vehicle</th>
                  <th className="text-right px-4 py-2">SoH</th>
                  <th className="text-right px-4 py-2">C-rate</th>
                  <th className="text-left px-4 py-2">Recommended actions</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => {
                  const cRate = r.peak_kw / (r.battery_capacity_kwh || 1);
                  const recs = recommendations(r);
                  return (
                    <tr key={r.plate_number} className="border-t border-border align-top">
                      <td className="px-4 py-3">
                        <div className="font-medium">{r.vehicle_name}</div>
                        <div className="text-xs text-muted-foreground">{r.plate_number}</div>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <Badge
                          variant="outline"
                          className={
                            r.current_soh_pct >= 90
                              ? "border-emerald-500/40 text-emerald-600 dark:text-emerald-400"
                              : r.current_soh_pct >= 80
                                ? "border-amber-500/40 text-amber-600 dark:text-amber-400"
                                : "border-destructive/40 text-destructive"
                          }
                        >
                          {r.current_soh_pct.toFixed(1)}%
                        </Badge>
                      </td>
                      <td className="px-4 py-3 text-right">{cRate.toFixed(3)}C</td>
                      <td className="px-4 py-3">
                        <ul className="space-y-1">
                          {recs.map((rec, i) => (
                            <li key={i} className="flex items-start gap-2 text-xs">
                              <CheckCircle2 className="h-3.5 w-3.5 mt-0.5 text-primary shrink-0" />
                              <span>{rec}</span>
                            </li>
                          ))}
                        </ul>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      </PageShell>
    </div>
  );
}

function ComplianceCard({ label, pct }: { label: string; pct: number }) {
  const tone =
    pct >= 80 ? "text-emerald-600 dark:text-emerald-400" : pct >= 60 ? "text-amber-600 dark:text-amber-400" : "text-destructive";
  return (
    <Card className="p-4">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className={`mt-1 text-2xl font-semibold ${tone}`}>{pct}%</div>
      <div className="mt-2 h-1.5 w-full rounded-full bg-muted overflow-hidden">
        <div
          className="h-full bg-primary"
          style={{ width: `${pct}%` }}
        />
      </div>
      <div className="text-xs text-muted-foreground mt-1">of fleet within policy</div>
    </Card>
  );
}
