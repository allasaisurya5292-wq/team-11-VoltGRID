import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { AppSidebar } from "@/components/AppSidebar";
import { PageShell } from "@/components/PageShell";
import { EvOwnerPanel } from "./dashboard";
import { generateDayCurve, currentPrice } from "@/lib/market";

export const Route = createFileRoute("/fleet-manager")({
  head: () => ({ meta: [{ title: "Fleet manager — VOLT_GRID" }] }),
  component: FleetManagerPage,
});

function FleetManagerPage() {
  const [tick, setTick] = useState(0);
  useEffect(() => {
    const i = setInterval(() => setTick((t) => t + 1), 30000);
    return () => clearInterval(i);
  }, []);
  const curve = useMemo(() => generateDayCurve(tick * 0.1), [tick]);
  const price = currentPrice(curve).price;

  return (
    <div className="min-h-screen flex bg-secondary/30">
      <AppSidebar />
      <PageShell title="Fleet manager" description="Manage your EV fleet, vehicles and grid sales.">
        <EvOwnerPanel price={price} onTrade={() => {}} />
      </PageShell>
    </div>
  );
}
