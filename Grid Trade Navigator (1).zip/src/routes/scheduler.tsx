import { createFileRoute } from "@tanstack/react-router";
import { useMemo } from "react";
import { AppSidebar } from "@/components/AppSidebar";
import { PageShell } from "@/components/PageShell";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { BatteryCharging, Zap, Clock, Bus } from "lucide-react";
import fleetCsv from "@/assets/ev-fleet.csv?raw";

export const Route = createFileRoute("/scheduler")({
  head: () => ({ meta: [{ title: "Scheduler — VOLT_GRID" }] }),
  component: SchedulerPage,
});

type FleetRow = {
  name: string;
  plate_number: string;
  battery_kwh: number;
  soc: number;
  status: string;
};

type Plan = {
  vehicle: FleetRow;
  action: "charge" | "dispatch" | "standby";
  window: string;
  energyKwh: number;
  reason: string;
};

function parseFleetCsv(csv: string): FleetRow[] {
  const lines = csv.trim().split(/\r?\n/);
  const headers = lines[0].split(",").map((h) => h.trim());
  return lines.slice(1).map((line) => {
    const cols = line.split(",").map((c) => c.trim());
    const row: Record<string, string> = {};
    headers.forEach((h, i) => (row[h] = cols[i] ?? ""));
    return {
      name: row.name,
      plate_number: row.plate_number,
      battery_kwh: Number(row.battery_kwh),
      soc: Number(row.soc),
      status: row.status || "idle",
    };
  });
}

// Deterministic window slot based on plate index
function slot(i: number, kind: "charge" | "dispatch") {
  if (kind === "charge") {
    // Off-peak overnight charging windows
    const start = 22 + (i % 4); // 22:00 - 01:00
    const end = (start + 4) % 24;
    return `${String(start % 24).padStart(2, "0")}:00 – ${String(end).padStart(2, "0")}:00`;
  }
  // V2G dispatch in evening peak
  const start = 17 + (i % 3); // 17:00 - 19:00
  const end = start + 2;
  return `${String(start).padStart(2, "0")}:00 – ${String(end).padStart(2, "0")}:00`;
}

function buildPlans(rows: FleetRow[]): Plan[] {
  return rows.map((v, i) => {
    // Charge: low SoC, currently charging, or discharged
    if (v.soc < 50 || v.status === "charging" || v.status === "discharged") {
      const targetSoc = 90;
      const energy = (v.battery_kwh * Math.max(0, targetSoc - v.soc)) / 100;
      return {
        vehicle: v,
        action: "charge",
        window: slot(i, "charge"),
        energyKwh: Math.round(energy),
        reason: `SoC ${v.soc}% → ${targetSoc}% off-peak refill`,
      };
    }
    // Dispatch (V2G): high SoC and idle
    if (v.soc >= 70 && v.status === "idle") {
      const reserve = 40;
      const energy = (v.battery_kwh * (v.soc - reserve)) / 100;
      return {
        vehicle: v,
        action: "dispatch",
        window: slot(i, "dispatch"),
        energyKwh: Math.round(energy),
        reason: `Sell ${v.soc - reserve}% back to grid at peak price`,
      };
    }
    return {
      vehicle: v,
      action: "standby",
      window: "—",
      energyKwh: 0,
      reason: v.status === "driving" ? "In service — locked" : "Mid-range SoC, hold",
    };
  });
}

function SchedulerPage() {
  const rows = useMemo(() => parseFleetCsv(fleetCsv), []);
  const plans = useMemo(() => buildPlans(rows), [rows]);

  const totals = useMemo(() => {
    const charge = plans.filter((p) => p.action === "charge");
    const dispatch = plans.filter((p) => p.action === "dispatch");
    const standby = plans.filter((p) => p.action === "standby");
    return {
      charge,
      dispatch,
      standby,
      chargeKwh: charge.reduce((a, p) => a + p.energyKwh, 0),
      dispatchKwh: dispatch.reduce((a, p) => a + p.energyKwh, 0),
    };
  }, [plans]);

  return (
    <div className="min-h-screen flex bg-secondary/30">
      <AppSidebar />
      <PageShell title="Scheduler" description="Plan charging windows and V2G dispatch schedules.">
        <div className="grid gap-4 md:grid-cols-3">
          <StatCard
            icon={<BatteryCharging className="h-4 w-4" />}
            label="Scheduled to charge"
            value={`${totals.charge.length} vehicles`}
            hint={`${totals.chargeKwh.toLocaleString()} kWh planned`}
            accent="primary"
          />
          <StatCard
            icon={<Zap className="h-4 w-4" />}
            label="V2G dispatch"
            value={`${totals.dispatch.length} vehicles`}
            hint={`${totals.dispatchKwh.toLocaleString()} kWh to grid`}
            accent="success"
          />
          <StatCard
            icon={<Clock className="h-4 w-4" />}
            label="Standby"
            value={`${totals.standby.length} vehicles`}
            hint="No action this window"
            accent="muted"
          />
        </div>

        <Card className="mt-6 overflow-hidden">
          <div className="px-4 py-3 border-b border-border flex items-center justify-between">
            <div>
              <h2 className="font-semibold text-sm">Fleet schedule</h2>
              <p className="text-xs text-muted-foreground">
                Generated from {rows.length} vehicles in ev-fleet.csv
              </p>
            </div>
          </div>
          <div className="max-h-[420px] overflow-y-auto overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted text-foreground text-xs font-bold uppercase tracking-wider sticky top-0 z-10">

                <tr>
                  <th className="text-left px-4 py-2">Vehicle</th>
                  <th className="text-left px-4 py-2">SoC</th>
                  <th className="text-left px-4 py-2">Action</th>
                  <th className="text-left px-4 py-2">Window</th>
                  <th className="text-right px-4 py-2">Energy</th>
                  <th className="text-left px-4 py-2">Reason</th>
                </tr>
              </thead>
              <tbody>
                {plans.map((p) => (
                  <tr key={p.vehicle.plate_number} className="border-t border-border">
                    <td className="px-4 py-2">
                      <div className="flex items-center gap-2">
                        <Bus className="h-4 w-4 text-muted-foreground" />
                        <div>
                          <div className="font-medium">{p.vehicle.name}</div>
                          <div className="text-xs text-muted-foreground">
                            {p.vehicle.plate_number} · {p.vehicle.battery_kwh} kWh
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-2 min-w-[140px]">
                      <div className="flex items-center gap-2">
                        <Progress value={p.vehicle.soc} className="h-2 w-20" />
                        <span className="text-xs">{p.vehicle.soc}%</span>
                      </div>
                    </td>
                    <td className="px-4 py-2">
                      <ActionBadge action={p.action} />
                    </td>
                    <td className="px-4 py-2 font-mono text-xs">{p.window}</td>
                    <td className="px-4 py-2 text-right">
                      {p.energyKwh > 0 ? `${p.energyKwh} kWh` : "—"}
                    </td>
                    <td className="px-4 py-2 text-xs text-muted-foreground">{p.reason}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </PageShell>
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
  hint,
  accent,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  hint: string;
  accent: "primary" | "success" | "muted";
}) {
  const accentClass =
    accent === "primary"
      ? "bg-primary/10 text-primary"
      : accent === "success"
        ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
        : "bg-muted text-muted-foreground";
  return (
    <Card className="p-4">
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <span className={`rounded-md p-1.5 ${accentClass}`}>{icon}</span>
        {label}
      </div>
      <div className="mt-2 text-2xl font-semibold">{value}</div>
      <div className="text-xs text-muted-foreground mt-0.5">{hint}</div>
    </Card>
  );
}

function ActionBadge({ action }: { action: Plan["action"] }) {
  if (action === "charge")
    return (
      <Badge variant="secondary" className="bg-primary/10 text-primary border-transparent">
        Charge
      </Badge>
    );
  if (action === "dispatch")
    return (
      <Badge variant="secondary" className="bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-transparent">
        V2G Dispatch
      </Badge>
    );
  return <Badge variant="outline">Standby</Badge>;
}
