import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useAuth, roleLabel } from "@/lib/auth";
import {
  generateDayCurve,
  currentPrice,
  getRecommendation,
  canGridOperatorSell,
  generateRange,
  type Granularity,
  GRID_MIN_MW,
  GRID_MIN_CAPACITY_PCT,
} from "@/lib/market";
import { supabase } from "@/integrations/supabase/client";
import fleetCsv from "@/assets/ev-fleet.csv?raw";
import batterySessionsCsv from "@/assets/battery-sessions.csv?raw";
import { useServerFn } from "@tanstack/react-start";
import { startSmartcarAuth, syncSmartcar, smartcarStatus } from "@/lib/api/smartcar.functions";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import {
  LineChart, Line, XAxis, YAxis, ResponsiveContainer, Area, AreaChart, Tooltip, ReferenceLine,
  PieChart, Pie, Cell, Legend,
} from "recharts";
import {
  Zap,
  TrendingUp,
  TrendingDown,
  Battery,
  Bell,
  LogOut,
  ArrowUpRight,
  ArrowDownRight,
  Activity,
  Search,
  Car,
  RefreshCw,
  CalendarIcon,
  Settings as SettingsIcon,
} from "lucide-react";
import { AppSidebar } from "@/components/AppSidebar";



export const Route = createFileRoute("/dashboard")({
  head: () => ({ meta: [{ title: "Dashboard — VOLT_GRID" }] }),
  component: Dashboard,
});

interface Trade {
  id: string;
  side: "buy" | "sell";
  mw: number;
  price_eur_mwh: number;
  total_eur: number;
  pnl_eur: number;
  asset_type: string;
  created_at: string;
}

function Dashboard() {
  const { user, role, loading, signOut } = useAuth();
  const navigate = useNavigate();
  const [trades, setTrades] = useState<Trade[]>([]);
  const [tick, setTick] = useState(0);

  // Re-tick every second so the live wholesale price reflects the exact
  // current time of day with sub-hour precision.
  useEffect(() => {
    const i = setInterval(() => setTick((t) => t + 1), 1000);
    return () => clearInterval(i);
  }, []);

  // Curve is deterministic per calendar day (so today's shape is stable),
  // while `now` updates every second via the tick above.
  const curve = useMemo(() => generateDayCurve(0), []);
  const now = currentPrice(curve);
  void tick;

  const rec = getRecommendation(curve);
  const min = Math.min(...curve.map((p) => p.price));
  const max = Math.max(...curve.map((p) => p.price));

  // Trend chart controls
  const [granularity, setGranularity] = useState<Granularity>("weekly");
  const defaultRange = useMemo(() => {
    const to = new Date();
    const from = new Date();
    if (granularity === "weekly") from.setDate(to.getDate() - 6);
    else if (granularity === "monthly") from.setDate(to.getDate() - 29);
    else from.setFullYear(to.getFullYear() - 1);
    return { from, to };
  }, [granularity]);
  const [trendRange, setTrendRange] = useState<{ from?: Date; to?: Date }>(defaultRange);
  useEffect(() => {
    setTrendRange(defaultRange);
  }, [defaultRange]);
  const trendData = useMemo(() => {
    if (!trendRange.from || !trendRange.to) return [];
    return generateRange(trendRange.from, trendRange.to, granularity);
  }, [trendRange, granularity]);
  const trendStats = useMemo(() => {
    if (!trendData.length) return { avg: 0, min: 0, max: 0 };
    const prices = trendData.map((d) => d.price);
    return {
      avg: Math.round(prices.reduce((s, p) => s + p, 0) / prices.length),
      min: Math.min(...prices),
      max: Math.max(...prices),
    };
  }, [trendData]);


  useEffect(() => {
    if (!loading && !user) navigate({ to: "/auth" });
  }, [loading, user, navigate]);

  useEffect(() => {
    if (user) refreshTrades();
  }, [user]);

  async function refreshTrades() {
    const { data } = await supabase.from("trades").select("*").order("created_at", { ascending: false }).limit(50);
    if (data) setTrades(data as Trade[]);
  }

  if (loading || !user) {
    return <div className="flex min-h-screen items-center justify-center text-muted-foreground">Loading…</div>;
  }

  return (
    <div className="min-h-screen flex bg-secondary/30">
      <AppSidebar />
      <div className="flex-1 min-w-0">
      <header className="border-b border-border bg-background">
        <div className="flex h-16 items-center justify-between px-6">
          <Link to="/" className="flex items-center gap-2 font-semibold">
            <span className="inline-flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
              <Zap className="h-4 w-4" />
            </span>
            VOLT_GRID
          </Link>
          <div className="flex items-center gap-4">
            <Badge variant="secondary">{role ? roleLabel[role] : "—"}</Badge>
            <span className="text-sm text-muted-foreground hidden sm:inline">{user.email}</span>
            <Button variant="ghost" size="icon" asChild aria-label="Settings">
              <Link to="/settings">
                <SettingsIcon className="h-4 w-4" />
              </Link>
            </Button>
            <Button variant="ghost" size="sm" onClick={signOut}>
              <LogOut className="h-4 w-4 mr-1" />
              Sign out
            </Button>
          </div>
        </div>
      </header>


      <main className="px-6 py-8 space-y-6">
        {/* Market overview */}
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-semibold">Overview</h1>
          <Button asChild size="sm" className="gap-2">
            <Link to="/prediction">
              <Activity className="h-4 w-4" />
              Prediction algorithm
            </Link>
          </Button>
        </div>
        <section className="grid gap-4 md:grid-cols-3">
          <MetricCard
            label={`Current price · ${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}`}
            value={`€${now.price.toFixed(2)}`}
            unit="/MWh"
            icon={Activity}
            accent="primary"
          />
          <MetricCard label="24h low" value={`€${min}`} unit="/MWh" icon={TrendingDown} accent="success" />
          <MetricCard label="24h high" value={`€${max}`} unit="/MWh" icon={TrendingUp} accent="warning" />
        </section>


        <section className={cn("grid gap-6", role !== "maenova_admin" && "lg:grid-cols-3")}>
          <Card className={cn("p-6", role !== "maenova_admin" && "lg:col-span-2")}>
            <div className="flex flex-wrap items-start justify-between gap-3 mb-4">
              <div>
                <h2 className="font-semibold">Wholesale price (€/MWh)</h2>
                <p className="text-xs text-muted-foreground">
                  {trendRange.from && trendRange.to
                    ? `${format(trendRange.from, "LLL d, yyyy")} – ${format(trendRange.to, "LLL d, yyyy")}`
                    : "Pick a date range"}
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <Tabs value={granularity} onValueChange={(v) => setGranularity(v as Granularity)}>
                  <TabsList>
                    <TabsTrigger value="weekly">Weekly</TabsTrigger>
                    <TabsTrigger value="monthly">Monthly</TabsTrigger>
                    <TabsTrigger value="yearly">Yearly</TabsTrigger>
                  </TabsList>
                </Tabs>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      size="sm"
                      className={cn("justify-start text-left font-normal", !trendRange.from && "text-muted-foreground")}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {trendRange.from && trendRange.to
                        ? `${format(trendRange.from, "LLL d")} – ${format(trendRange.to, "LLL d")}`
                        : "Date range"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="end">
                    <Calendar
                      mode="range"
                      selected={trendRange as any}
                      onSelect={(r: any) => setTrendRange(r ?? {})}
                      numberOfMonths={2}
                      initialFocus
                      className={cn("p-3 pointer-events-auto")}
                    />
                  </PopoverContent>
                </Popover>
                <Badge variant={rec.action === "BUY" ? "default" : rec.action === "SELL" ? "destructive" : "secondary"}>
                  {rec.action}
                </Badge>
              </div>
            </div>

            <div className="grid gap-3 md:grid-cols-3 mb-4">
              <Stat label="Average" value={`€${trendStats.avg}`} />
              <Stat label="Low" value={`€${trendStats.min}`} />
              <Stat label="High" value={`€${trendStats.max}`} />
            </div>

            <div className="h-64">
              {trendData.length === 0 ? (
                <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
                  Select a date range to view prices.
                </div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={trendData}>
                    <defs>
                      <linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="var(--color-accent)" stopOpacity={0.4} />
                        <stop offset="100%" stopColor="var(--color-accent)" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <XAxis
                      dataKey="label"
                      tick={{ fontSize: 11 }}
                      stroke="var(--color-muted-foreground)"
                      interval="preserveStartEnd"
                      minTickGap={24}
                    />
                    <YAxis tick={{ fontSize: 11 }} stroke="var(--color-muted-foreground)" />
                    <Tooltip
                      contentStyle={{
                        background: "var(--color-card)",
                        border: "1px solid var(--color-border)",
                        borderRadius: 8,
                      }}
                      formatter={(v: any) => [`€${v}/MWh`, "Price"]}
                    />
                    <ReferenceLine y={trendStats.avg} stroke="var(--color-muted-foreground)" strokeDasharray="3 3" label={{ value: `Avg €${trendStats.avg}`, position: "insideTopLeft", fill: "var(--color-muted-foreground)", fontSize: 10 }} />
                    <ReferenceLine
                      x={trendData[Math.min(trendData.length - 1, Math.max(0, Math.round(((new Date().getHours() * 60 + new Date().getMinutes()) / (24 * 60)) * (trendData.length - 1))))]?.label}
                      stroke="#ef4444"
                      strokeWidth={2}
                      ifOverflow="extendDomain"
                      label={{ value: `Now €${now.price.toFixed(2)} · ${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`, position: "top", fill: "#ef4444", fontSize: 11, fontWeight: 600 }}
                    />

                    <Area type="monotone" dataKey="price" stroke="var(--color-accent)" strokeWidth={2} fill="url(#g1)" isAnimationActive={false} />

                  </AreaChart>
                </ResponsiveContainer>
              )}
            </div>

            {role !== "maenova_admin" && <AutoTradeCard price={now.price} onTrade={refreshTrades} />}
          </Card>

          {role !== "maenova_admin" && (
            <div className="space-y-6">
              <AlertsCard />
              <ProfitStrategyCard trades={trades} />
            </div>
          )}





        </section>





        {/* Role-specific panels */}

        {role === "maenova_admin" && <AdminPanel />}



        {role !== "maenova_admin" && (
          <Card className="p-6">
            <h2 className="font-semibold mb-4">Trade history</h2>
            {trades.length === 0 ? (
              <p className="text-sm text-muted-foreground">No trades yet. Execute your first trade above.</p>
            ) : (
              <div className="overflow-auto rounded-lg border border-border max-h-[360px]">
                <table className="w-full text-sm">
                  <thead className="bg-muted text-left text-xs font-bold uppercase text-foreground sticky top-0 z-10">

                    <tr>
                      <th className="px-3 py-2">Time</th>
                      <th className="px-3 py-2">Side</th>
                      <th className="px-3 py-2">Asset</th>
                      <th className="px-3 py-2 text-right">MW</th>
                      <th className="px-3 py-2 text-right">Price</th>
                      <th className="px-3 py-2 text-right">Total</th>
                      <th className="px-3 py-2 text-right">P&L</th>
                    </tr>
                  </thead>
                  <tbody>
                    {trades.map((t) => (
                      <tr key={t.id} className="border-t border-border hover:bg-muted/30">
                        <td className="px-3 py-2 whitespace-nowrap">{new Date(t.created_at).toLocaleString()}</td>
                        <td className="px-3 py-2">
                          <Badge variant={t.side === "buy" ? "secondary" : "default"}>{t.side.toUpperCase()}</Badge>
                        </td>
                        <td className="px-3 py-2 text-muted-foreground">{t.asset_type}</td>
                        <td className="px-3 py-2 text-right">{t.mw}</td>
                        <td className="px-3 py-2 text-right">€{Number(t.price_eur_mwh).toFixed(0)}</td>
                        <td className="px-3 py-2 text-right">€{Number(t.total_eur).toFixed(0)}</td>
                        <td className={`px-3 py-2 text-right font-medium ${Number(t.pnl_eur) >= 0 ? "text-success" : "text-destructive"}`}>
                          {Number(t.pnl_eur) >= 0 ? "+" : ""}€{Number(t.pnl_eur).toFixed(0)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        )}
      </main>
      </div>
    </div>
  );
}

function MetricCard({
  label,
  value,
  unit,
  icon: Icon,
  accent,
}: {
  label: string;
  value: string;
  unit: string;
  icon: any;
  accent: string;
}) {
  const color =
    accent === "success"
      ? "text-success"
      : accent === "warning"
        ? "text-warning"
        : accent === "accent"
          ? "text-accent"
          : "text-primary";
  return (
    <Card className="p-5">
      <div className="flex items-center justify-between">
        <span className="text-xs uppercase tracking-wide text-muted-foreground">{label}</span>
        <Icon className={`h-4 w-4 ${color}`} />
      </div>
      <div className="mt-2 flex items-baseline gap-1">
        <span className="text-2xl font-semibold">{value}</span>
        <span className="text-xs text-muted-foreground">{unit}</span>
      </div>
    </Card>
  );
}

function GridOperatorPanel({ price, onTrade }: { price: number; onTrade: () => void }) {
  const [mw, setMw] = useState(1);
  const [capacity, setCapacity] = useState(50);
  const [side, setSide] = useState<"buy" | "sell">("buy");
  const check = canGridOperatorSell(mw, capacity);
  const total = mw * price;

  async function execute() {
    if (side === "sell" && !check.ok) return toast.error(check.reason);
    if (mw <= GRID_MIN_MW) return toast.error(`More than ${GRID_MIN_MW} MW required`);

    // simulated P&L: buy=negative (cost), sell=positive (assume €60 cost basis)
    const pnl = side === "sell" ? mw * (price - 60) : mw * (60 - price);
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;
    const { error } = await supabase.from("trades").insert({
      user_id: user.id,
      side,
      mw,
      price_eur_mwh: price,
      total_eur: total,
      pnl_eur: pnl,
      asset_type: "grid",
    });
    if (error) return toast.error(error.message);
    toast.success(`${side.toUpperCase()} ${mw} MW @ €${price}/MWh executed`);
    onTrade();
  }

  return (
    <Card className="p-6">
      <h2 className="font-semibold mb-1">Grid trading desk</h2>
      <p className="text-xs text-muted-foreground mb-4">
        VOLT_GRID rules: min {GRID_MIN_MW} MW · ≥{GRID_MIN_CAPACITY_PCT}% reserve capacity to sell
      </p>
      <div className="grid gap-4 md:grid-cols-4">
        <div>
          <Label>Side</Label>
          <div className="mt-1 flex rounded-md border border-border p-1">
            <button
              onClick={() => setSide("buy")}
              className={`flex-1 py-1.5 rounded text-sm font-medium ${side === "buy" ? "bg-primary text-primary-foreground" : ""}`}
            >
              Buy
            </button>
            <button
              onClick={() => setSide("sell")}
              className={`flex-1 py-1.5 rounded text-sm font-medium ${side === "sell" ? "bg-primary text-primary-foreground" : ""}`}
            >
              Sell
            </button>
          </div>
        </div>
        <div>
          <Label>Volume (MW)</Label>
          <Input type="number" min={GRID_MIN_MW} step={0.1} value={mw} onChange={(e) => setMw(+e.target.value)} />
        </div>
        <div>
          <Label>Reserve capacity (%)</Label>
          <Input type="number" min={0} max={100} value={capacity} onChange={(e) => setCapacity(+e.target.value)} />
        </div>
        <div>
          <Label>Estimated total</Label>
          <div className="mt-1 px-3 py-2 rounded-md bg-muted text-sm font-medium">€{total.toFixed(0)}</div>
        </div>
      </div>
      {side === "sell" && (
        <div
          className={`mt-4 rounded-md p-3 text-sm ${check.ok ? "bg-success/10 text-success" : "bg-destructive/10 text-destructive"}`}
        >
          {check.reason}
        </div>
      )}
      <Button className="mt-4" onClick={execute} disabled={side === "sell" && !check.ok}>
        Execute {side.toUpperCase()} {mw} MW
      </Button>
    </Card>
  );
}

interface Vehicle {
  id: string;
  name: string;
  plate_number: string;
  battery_kwh: number;
  soc: number;
  status: string;
  created_at: string;
}

function parseCsv(text: string): Record<string, string>[] {
  const lines = text.split(/\r?\n/).filter((l) => l.trim().length > 0);
  if (lines.length < 2) return [];
  const splitLine = (line: string) => {
    const out: string[] = [];
    let cur = "";
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const c = line[i];
      if (c === '"') {
        if (inQuotes && line[i + 1] === '"') {
          cur += '"';
          i++;
        } else inQuotes = !inQuotes;
      } else if (c === "," && !inQuotes) {
        out.push(cur);
        cur = "";
      } else cur += c;
    }
    out.push(cur);
    return out.map((s) => s.trim());
  };
  const headers = splitLine(lines[0]).map((h) => h.toLowerCase().replace(/\s+/g, "_"));
  return lines.slice(1).map((line) => {
    const cells = splitLine(line);
    const row: Record<string, string> = {};
    headers.forEach((h, i) => (row[h] = cells[i] ?? ""));
    return row;
  });
}

function pick(row: Record<string, string>, keys: string[]): string | undefined {
  for (const k of keys) if (row[k] !== undefined && row[k] !== "") return row[k];
  return undefined;
}

function FleetHealthCard() {
  const data = useMemo(() => {
    const rows = parseCsv(batterySessionsCsv);

    const now = Date.now();
    let sohSum = 0;
    let ageSum = 0;
    let v2gSum = 0;
    let opSum = 0;

    rows.forEach((r) => {
      sohSum += Number(r.current_soh_pct) || 0;
      const t = new Date(r.in_service_since).getTime();
      if (!Number.isNaN(t)) ageSum += (now - t) / (1000 * 60 * 60 * 24 * 365.25);
      v2gSum += Number(r.v2g_degradation_pct) || 0;
      opSum += Number(r.operational_degradation_pct) || 0;
    });

    const n = rows.length || 1;
    return {
      count: rows.length,
      avgSoh: sohSum / n,
      avgAge: ageSum / n,
      v2gTotal: v2gSum,
      opTotal: opSum,
    };
  }, []);

  const pieData = [
    { name: "V2G degradation", value: data.v2gTotal },
    { name: "Operational degradation", value: data.opTotal },
  ];
  const colors = ["var(--color-primary)", "var(--color-destructive)"];
  const totalDeg = data.v2gTotal + data.opTotal;

  return (
    <Card className="p-6">
      <div className="mb-4">
        <h2 className="font-semibold">Fleet battery analytics</h2>
        <p className="text-xs text-muted-foreground">Health and degradation breakdown across the fleet</p>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <div className="grid gap-3 sm:grid-cols-3 md:grid-cols-1 content-start">
          <MetricCard label="Fleet size" value={String(data.count)} unit="buses" icon={Car} accent="primary" />
          <MetricCard label="Average SoH" value={`${data.avgSoh.toFixed(1)}%`} unit="health" icon={Battery} accent="success" />
          <MetricCard label="Average fleet age" value={`${data.avgAge.toFixed(1)}`} unit="years" icon={Activity} accent="accent" />
        </div>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={pieData}
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                outerRadius={90}
                innerRadius={50}
                label={(e: any) => `${((e.value / (totalDeg || 1)) * 100).toFixed(0)}%`}
              >
                {pieData.map((_, i) => (
                  <Cell key={i} fill={colors[i]} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{ background: "var(--color-card)", border: "1px solid var(--color-border)", borderRadius: 8 }}
                formatter={(v: any, n: any) => [`${Number(v).toFixed(1)}%`, n]}
              />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    </Card>
  );
}

export function EvOwnerPanel({ price, onTrade }: { price: number; onTrade: () => void }) {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [importing, setImporting] = useState(false);
  const [scConnected, setScConnected] = useState(false);
  const [scBusy, setScBusy] = useState(false);
  const startAuthFn = useServerFn(startSmartcarAuth);
  const syncFn = useServerFn(syncSmartcar);
  const statusFn = useServerFn(smartcarStatus);

  useEffect(() => {
    statusFn({}).then((s) => setScConnected(!!s?.connected)).catch(() => {});
    const url = new URL(window.location.href);
    const sc = url.searchParams.get("smartcar");
    if (sc === "connected") {
      toast.success(`Smartcar connected · ${url.searchParams.get("count") ?? 0} vehicles synced`);
      setScConnected(true);
    } else if (sc === "error") {
      toast.error(`Smartcar: ${url.searchParams.get("reason") ?? "failed"}`);
    }
    if (sc) {
      url.searchParams.delete("smartcar");
      url.searchParams.delete("count");
      url.searchParams.delete("reason");
      window.history.replaceState({}, "", url.toString());
    }
  }, []);

  async function connectSmartcar() {
    setScBusy(true);
    try {
      const { authUrl } = await startAuthFn({});
      // Smartcar Connect blocks iframes (X-Frame-Options). Break out of the
      // Lovable preview iframe, or fall back to opening a new tab.
      const top = window.top ?? window;
      try {
        top.location.href = authUrl;
      } catch {
        window.open(authUrl, "_blank", "noopener,noreferrer");
      }
    } catch (e: any) {
      toast.error(e.message || "Failed to start Smartcar");
      setScBusy(false);
    }
  }

  async function syncSmartcarNow() {
    setScBusy(true);
    try {
      const r = await syncFn({});
      toast.success(`Synced ${r.count} vehicle${r.count === 1 ? "" : "s"} from Smartcar`);
      await load();
    } catch (e: any) {
      toast.error(e.message || "Sync failed");
    } finally {
      setScBusy(false);
    }
  }

  async function load() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;
    const { data } = await supabase
      .from("ev_vehicles")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });
    if (data) setVehicles(data as Vehicle[]);
    return { user, data: data as Vehicle[] | null };
  }

  function parseFleetCsv(csv: string) {
    const lines = csv.trim().split(/\r?\n/);
    const headers = lines[0].split(",").map((h) => h.trim());
    return lines.slice(1).map((line) => {
      const cols = line.split(",").map((c) => c.trim());
      const row: Record<string, string> = {};
      headers.forEach((h, i) => (row[h] = cols[i] ?? ""));
      return {
        name: row.name,
        plate_number: row.plate_number,
        battery_kwh: Number(row.battery_kwh),
        soc: Number(row.soc),
        status: row.status || "idle",
      };
    });
  }

  async function importFromCsv() {
    setImporting(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      const rows = parseFleetCsv(fleetCsv);
      if (!rows.length) {
        toast.error("CSV is empty");
        return;
      }
      const plates = rows.map((r) => r.plate_number);
      const { data: existing } = await supabase
        .from("ev_vehicles")
        .select("id,plate_number")
        .eq("user_id", user.id)
        .in("plate_number", plates);
      const existingMap = new Map((existing || []).map((e: any) => [e.plate_number, e.id]));
      const toInsert = rows
        .filter((r) => !existingMap.has(r.plate_number))
        .map((r) => ({ ...r, user_id: user.id }));
      const toUpdate = rows.filter((r) => existingMap.has(r.plate_number));
      if (toInsert.length) {
        const { error } = await supabase.from("ev_vehicles").insert(toInsert);
        if (error) throw error;
      }
      for (const u of toUpdate) {
        await supabase
          .from("ev_vehicles")
          .update({ name: u.name, battery_kwh: u.battery_kwh, soc: u.soc, status: u.status })
          .eq("id", existingMap.get(u.plate_number));
      }
      toast.success(`Imported ${rows.length} vehicles from CSV`);
      await load();
    } catch (e: any) {
      toast.error(e.message || "Import failed");
    } finally {
      setImporting(false);
    }
  }

  useEffect(() => {
    load();
    const channel = supabase
      .channel("ev_vehicles_changes")
      .on("postgres_changes", { event: "*", schema: "public", table: "ev_vehicles" }, () => load())
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);




  async function sellFromVehicle(v: Vehicle) {
    if (v.status === "sold") return toast.error(`${v.name}: already sold — sync fleet to reactivate`);
    if (v.soc < 20) return toast.error(`${v.name}: keep ≥20% charge for driving`);
    const sellablePct = v.soc - 20;
    const sellKwh = (Number(v.battery_kwh) * sellablePct) / 100;
    const mw = sellKwh / 1000;
    if (mw <= GRID_MIN_MW) return toast.error(`${v.name}: needs > ${GRID_MIN_MW} MW available (${mw.toFixed(3)} MW)`);
    const total = mw * price;
    const pnl = mw * (price - 40);
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;
    const { error } = await supabase.from("trades").insert({
      user_id: user.id,
      side: "sell",
      mw,
      price_eur_mwh: price,
      total_eur: total,
      pnl_eur: pnl,
      asset_type: "ev_battery",
    });
    if (error) return toast.error(error.message);
    await supabase.from("ev_vehicles").update({ soc: 20, status: "sold" }).eq("id", v.id);
    toast.success(`${v.name}: sold ${sellKwh.toFixed(1)} kWh · +€${pnl.toFixed(2)} · frozen until next sync`);
    onTrade();
  }

  const filtered = useMemo(() => {
    return vehicles.filter((v) => {
      const q = search.toLowerCase();
      const matchesSearch = !q || v.name.toLowerCase().includes(q) || v.plate_number.toLowerCase().includes(q);
      const matchesStatus = statusFilter === "all" || v.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [vehicles, search, statusFilter]);

  const fleetMetrics = useMemo(() => {
    const totalKwh = vehicles.reduce((s, v) => s + Number(v.battery_kwh), 0);
    const availableKwh = vehicles.reduce(
      (s, v) => s + (Number(v.battery_kwh) * Math.max(0, v.soc - 20)) / 100,
      0,
    );
    const projectedRevenue = (availableKwh / 1000) * price;
    const avgSoc = vehicles.length ? vehicles.reduce((s, v) => s + Number(v.soc), 0) / vehicles.length : 0;
    return { count: vehicles.length, totalKwh, availableKwh, projectedRevenue, avgSoc };
  }, [vehicles, price]);

  return (
    <>
      <section className="grid gap-4 md:grid-cols-3">
        <div className="md:col-span-1">
          <FleetStatusPie vehicles={vehicles} />
        </div>
        <section className="md:col-span-2 grid gap-4 sm:grid-cols-3">
          <MetricCard label="Vehicles in fleet" value={String(fleetMetrics.count)} unit="EVs" icon={Car} accent="primary" />
          <MetricCard label="Avg state of charge" value={`${fleetMetrics.avgSoc.toFixed(0)}%`} unit="" icon={Battery} accent="success" />
          <MetricCard label="Sellable energy" value={fleetMetrics.availableKwh.toFixed(1)} unit="kWh" icon={Zap} accent="accent" />
        </section>
      </section>

      <Card className="p-6">

        <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
          <div>
            <h2 className="font-semibold">My EV fleet</h2>
            <p className="text-xs text-muted-foreground">
              Import the demo fleet bundled with the app.
            </p>
          </div>
          <div className="flex gap-2">
            <Button onClick={importFromCsv} disabled={importing} variant="outline">
              <RefreshCw className="h-4 w-4 mr-1" />
              {importing ? "Importing…" : "Import fleet"}
            </Button>
            {scConnected ? (
              <Button onClick={syncSmartcarNow} disabled={scBusy}>
                <RefreshCw className="h-4 w-4 mr-1" />
                {scBusy ? "Syncing…" : "Sync from Smartcar"}
              </Button>
            ) : (
              <Button onClick={connectSmartcar} disabled={scBusy}>
                <Car className="h-4 w-4 mr-1" />
                {scBusy ? "Connecting…" : "Connect car (Smartcar)"}
              </Button>
            )}
          </div>
        </div>




        <div className="flex flex-wrap gap-3 mb-4">
          <div className="relative flex-1 min-w-[220px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search by name or plate…" className="pl-9" />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[180px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              <SelectItem value="idle">Idle</SelectItem>
              <SelectItem value="charging">Charging</SelectItem>
              <SelectItem value="driving">Driving</SelectItem>
              <SelectItem value="discharged">Discharged</SelectItem>
              <SelectItem value="sold">Sold (frozen)</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {filtered.length === 0 ? (
          <div className="text-center py-10 text-sm text-muted-foreground">
            {vehicles.length === 0
              ? "No vehicles yet. Click \"Import fleet\" to load the bundled demo fleet."
              : "No vehicles match your filters."}

          </div>
        ) : (
          <div className="overflow-auto rounded-lg border border-border max-h-[420px]">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 text-left text-xs uppercase text-muted-foreground sticky top-0 z-10">
                <tr>
                  <th className="px-3 py-2">Vehicle</th>
                  <th className="px-3 py-2">Plate</th>
                  <th className="px-3 py-2 text-right">Battery</th>
                  <th className="px-3 py-2">SoC</th>
                  <th className="px-3 py-2">Status</th>
                  <th className="px-3 py-2 text-right">Sellable</th>
                  <th className="px-3 py-2 text-right">Revenue</th>
                </tr>

              </thead>
              <tbody>
                {filtered.map((v) => {
                  const sellable = (Number(v.battery_kwh) * Math.max(0, v.soc - 20)) / 100;
                  const revenue = (sellable / 1000) * price;
                  const isSold = v.status === "sold";
                  return (
                    <tr key={v.id} className={`border-t border-border hover:bg-muted/30 ${isSold ? "opacity-60" : ""}`}>
                      <td className="px-3 py-2 font-medium">
                        <div className="flex items-center gap-2">
                          <Car className="h-4 w-4 text-primary" />
                          {v.name}
                        </div>
                      </td>
                      <td className="px-3 py-2 text-muted-foreground">{v.plate_number}</td>
                      <td className="px-3 py-2 text-right">{v.battery_kwh} kWh</td>
                      <td className="px-3 py-2 w-[160px]">
                        <div className="flex items-center gap-2">
                          <div className="h-2 flex-1 rounded-full bg-muted overflow-hidden">
                            <div className="h-full bg-success" style={{ width: `${v.soc}%` }} />
                          </div>
                          <span className="text-xs font-medium w-9 text-right">{v.soc}%</span>
                        </div>
                      </td>
                      <td className="px-3 py-2">
                        <Badge variant={isSold ? "outline" : "secondary"}>
                          {isSold ? "sold · frozen" : v.status}
                        </Badge>
                      </td>
                      <td className="px-3 py-2 text-right">{sellable.toFixed(1)} kWh</td>
                      <td className="px-3 py-2 text-right text-success font-medium">€{revenue.toFixed(2)}</td>
                    </tr>

                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>





    </>
  );
}



function AdminPanel() {
  const [stats, setStats] = useState<{ users: number; trades: number; volume: number; pnl: number } | null>(null);
  useEffect(() => {
    (async () => {
      const { data: trades } = await supabase.from("trades").select("mw,pnl_eur,user_id");
      if (trades) {
        const users = new Set(trades.map((t: any) => t.user_id)).size;
        const volume = trades.reduce((s: number, t: any) => s + Number(t.mw), 0);
        const pnl = trades.reduce((s: number, t: any) => s + Number(t.pnl_eur), 0);
        setStats({ users, trades: trades.length, volume, pnl });
      }
    })();
  }, []);
  return (
    <Card className="p-6">
      <h2 className="font-semibold mb-4">VOLT_GRID platform overview</h2>
      <div className="grid gap-4 md:grid-cols-3">
        <Stat label="Active customers" value={stats?.users ?? 0} />
        <Stat label="Total trades" value={stats?.trades ?? 0} />
        <Stat label="MW transacted" value={(stats?.volume ?? 0).toFixed(1)} />
      </div>
    </Card>
  );
}

function Stat({ label, value }: { label: string; value: any }) {
  return (
    <div className="rounded-lg border border-border p-4">
      <div className="text-xs uppercase text-muted-foreground">{label}</div>
      <div className="mt-1 text-2xl font-semibold">{value}</div>
    </div>
  );
}

function AlertsCard() {
  const [enabled, setEnabled] = useState(true);
  const [high, setHigh] = useState(150);
  const [low, setLow] = useState(40);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    (async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) return;
      const { data } = await supabase.from("price_alerts").select("*").eq("user_id", user.id).maybeSingle();
      if (data) {
        setEnabled(data.enabled);
        setHigh(Number(data.threshold_high));
        setLow(Number(data.threshold_low));
      }
      setLoaded(true);
    })();
  }, []);

  async function save() {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;
    const { error } = await supabase
      .from("price_alerts")
      .upsert(
        { user_id: user.id, enabled, threshold_high: high, threshold_low: low },
        { onConflict: "user_id" },
      );
    if (error) return toast.error(error.message);
    toast.success("Alert preferences saved");
  }

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Bell className="h-5 w-5 text-accent" />
          <h2 className="font-semibold">Price alerts</h2>
        </div>
        <Switch checked={enabled} onCheckedChange={setEnabled} disabled={!loaded} />
      </div>
      <p className="text-sm text-muted-foreground mb-4">
        Get notified when wholesale prices cross your thresholds — perfect for timing EV battery sells.
      </p>
      <div className="grid gap-4 md:grid-cols-2">
        <div>
          <Label>Notify when price ≥ (€/MWh)</Label>
          <Input type="number" value={high} onChange={(e) => setHigh(+e.target.value)} />
        </div>
        <div>
          <Label>Notify when price ≤ (€/MWh)</Label>
          <Input type="number" value={low} onChange={(e) => setLow(+e.target.value)} />
        </div>
      </div>
      <Button className="mt-4" onClick={save}>
        Save preferences
      </Button>
    </Card>
  );
}

function AutoSellCard({ price, onTrade }: { price: number; onTrade: () => void }) {
  const [enabled, setEnabled] = useState<boolean>(() => localStorage.getItem("autoSellEnabled") === "1");
  const [threshold, setThreshold] = useState<number>(() => Number(localStorage.getItem("autoSellThreshold") || 120));
  const [busy, setBusy] = useState(false);
  const [lastRun, setLastRun] = useState<string | null>(null);

  useEffect(() => { localStorage.setItem("autoSellEnabled", enabled ? "1" : "0"); }, [enabled]);
  useEffect(() => { localStorage.setItem("autoSellThreshold", String(threshold)); }, [threshold]);

  async function sellEligible(reason: "auto" | "manual") {
    if (busy) return;
    setBusy(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      const { data: vehicles } = await supabase
        .from("ev_vehicles")
        .select("*")
        .eq("user_id", user.id)
        .neq("status", "sold");
      if (!vehicles?.length) {
        if (reason === "manual") toast.error("No eligible vehicles to sell");
        return;
      }
      let sold = 0;
      let revenue = 0;
      for (const v of vehicles as Vehicle[]) {
        if (v.soc < 20) continue;
        const sellKwh = (Number(v.battery_kwh) * (v.soc - 20)) / 100;
        const mw = sellKwh / 1000;
        if (mw <= GRID_MIN_MW) continue;
        const total = mw * price;
        const pnl = mw * (price - 40);
        const { error } = await supabase.from("trades").insert({
          user_id: user.id, side: "sell", mw, price_eur_mwh: price,
          total_eur: total, pnl_eur: pnl, asset_type: "ev_battery",
        });
        if (error) continue;
        await supabase.from("ev_vehicles").update({ soc: 20, status: "sold" }).eq("id", v.id);
        sold++;
        revenue += total;
      }
      if (sold > 0) {
        toast.success(`${reason === "auto" ? "Auto-sold" : "Sold"} ${sold} vehicle${sold > 1 ? "s" : ""} · €${revenue.toFixed(0)}`);
        setLastRun(new Date().toLocaleTimeString());
        onTrade();
      } else if (reason === "manual") {
        toast.error("No vehicles meet sell criteria (≥40% SoC, >1 MW available)");
      }
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => {
    if (!enabled || price < threshold) return;
    sellEligible("auto");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled, threshold, price]);

  const armed = enabled && price < threshold;
  const triggered = enabled && price >= threshold;

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-1">
        <h2 className="font-semibold">Auto-sell</h2>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">{enabled ? "ON" : "OFF"}</span>
          <Switch checked={enabled} onCheckedChange={setEnabled} />
        </div>
      </div>
      <p className="text-xs text-muted-foreground mb-4">
        Automatically sell eligible vehicles when wholesale price hits your threshold.
      </p>

      <div className={`rounded-lg p-4 mb-4 ${triggered ? "bg-success/10" : "bg-muted"}`}>
        <div className="flex items-baseline justify-between">
          <span className="text-xs uppercase text-muted-foreground">Current</span>
          <span className="text-2xl font-semibold">€{price}<span className="text-xs text-muted-foreground">/MWh</span></span>
        </div>
        <div className="flex items-baseline justify-between mt-1">
          <span className="text-xs uppercase text-muted-foreground">Threshold</span>
          <span className="text-sm font-medium">€{threshold}/MWh</span>
        </div>
        <div className="mt-2 text-xs">
          {!enabled && <span className="text-muted-foreground">Auto-sell disabled</span>}
          {armed && <span className="text-muted-foreground">Armed · waiting for €{threshold}/MWh</span>}
          {triggered && <span className="text-success font-medium">Threshold reached · auto-selling</span>}
        </div>
      </div>

      <div className="space-y-3">
        <div>
          <Label>Sell threshold (€/MWh)</Label>
          <Input
            type="number"
            min={1}
            value={threshold}
            onChange={(e) => setThreshold(Math.max(1, +e.target.value || 1))}
          />
        </div>
        <Button className="w-full" variant="outline" onClick={() => sellEligible("manual")} disabled={busy}>
          {busy ? "Selling…" : "Sell now (manual)"}
        </Button>
        {lastRun && <p className="text-xs text-muted-foreground text-center">Last run · {lastRun}</p>}
      </div>
    </Card>
  );
}

function AutoTradeCard({ price, onTrade }: { price: number; onTrade: () => void }) {
  const [enabled, setEnabled] = useState<boolean>(() => localStorage.getItem("autoTradeEnabled") === "1");
  const [buyThreshold, setBuyThreshold] = useState<number>(() => Number(localStorage.getItem("autoBuyThreshold") || 40));
  const [sellThreshold, setSellThreshold] = useState<number>(() => Number(localStorage.getItem("autoSellThreshold2") || 120));
  const [busy, setBusy] = useState(false);
  const [log, setLog] = useState<{ time: string; msg: string; side: "buy" | "sell" }[]>([]);

  useEffect(() => { localStorage.setItem("autoTradeEnabled", enabled ? "1" : "0"); }, [enabled]);
  useEffect(() => { localStorage.setItem("autoBuyThreshold", String(buyThreshold)); }, [buyThreshold]);
  useEffect(() => { localStorage.setItem("autoSellThreshold2", String(sellThreshold)); }, [sellThreshold]);

  const pushLog = (msg: string, side: "buy" | "sell") =>
    setLog((l) => [{ time: new Date().toLocaleTimeString(), msg, side }, ...l].slice(0, 5));

  async function runBuy(reason: "auto" | "manual") {
    if (busy) return;
    setBusy(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      const { data: vehicles } = await supabase
        .from("ev_vehicles").select("*").eq("user_id", user.id).neq("status", "sold");
      if (!vehicles?.length) { if (reason === "manual") toast.error("No vehicles available to charge"); return; }
      let bought = 0, spent = 0, totalMw = 0;
      for (const v of vehicles as Vehicle[]) {
        if (v.soc >= 80) continue;
        const buyKwh = (Number(v.battery_kwh) * (80 - v.soc)) / 100;
        const mw = buyKwh / 1000;
        if (mw < GRID_MIN_MW) continue;
        const total = mw * price;
        const { error } = await supabase.from("trades").insert({
          user_id: user.id, side: "buy", mw, price_eur_mwh: price,
          total_eur: total, pnl_eur: -total, asset_type: "ev_battery",
        });
        if (error) continue;
        await supabase.from("ev_vehicles").update({ soc: 80, status: "charging" }).eq("id", v.id);
        bought++; spent += total; totalMw += mw;
      }
      if (bought > 0) {
        toast.success(`${reason === "auto" ? "Auto-bought" : "Bought"} for ${bought} vehicle${bought > 1 ? "s" : ""} · €${spent.toFixed(0)}`);
        pushLog(`Bought ${totalMw.toFixed(2)} MWh @ €${price}/MWh`, "buy");
        onTrade();
      } else if (reason === "manual") {
        toast.error("No vehicles need charging (SoC ≥95% or below 1 MW)");
      }
    } finally { setBusy(false); }
  }

  async function runSell(reason: "auto" | "manual") {
    if (busy) return;
    setBusy(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;
      const { data: vehicles } = await supabase
        .from("ev_vehicles").select("*").eq("user_id", user.id).neq("status", "sold");
      if (!vehicles?.length) { if (reason === "manual") toast.error("No vehicles to sell from"); return; }
      let sold = 0, revenue = 0, totalMw = 0;
      for (const v of vehicles as Vehicle[]) {
        if (v.soc < 20) continue;
        const sellKwh = (Number(v.battery_kwh) * (v.soc - 20)) / 100;
        const mw = sellKwh / 1000;
        if (mw < GRID_MIN_MW) continue;
        const total = mw * price;
        const pnl = mw * (price - 40);
        const { error } = await supabase.from("trades").insert({
          user_id: user.id, side: "sell", mw, price_eur_mwh: price,
          total_eur: total, pnl_eur: pnl, asset_type: "ev_battery",
        });
        if (error) continue;
        await supabase.from("ev_vehicles").update({ soc: 20, status: "idle" }).eq("id", v.id);
        sold++; revenue += total; totalMw += mw;
      }
      if (sold > 0) {
        toast.success(`${reason === "auto" ? "Auto-sold" : "Sold"} ${sold} vehicle${sold > 1 ? "s" : ""} · €${revenue.toFixed(0)}`);
        pushLog(`Sold ${totalMw.toFixed(2)} MWh @ €${price}/MWh`, "sell");
        onTrade();
      } else if (reason === "manual") {
        toast.error("No vehicles meet sell criteria (≥40% SoC, ≥1 MW)");
      }
    } finally { setBusy(false); }
  }

  // Auto trigger
  useEffect(() => {
    if (!enabled) return;
    if (price <= buyThreshold) runBuy("auto");
    else if (price >= sellThreshold) runSell("auto");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled, price, buyThreshold, sellThreshold]);

  const status =
    !enabled ? { label: "Disabled", tone: "text-muted-foreground" } :
    price <= buyThreshold ? { label: `Auto-buying · price ≤ €${buyThreshold}`, tone: "text-success" } :
    price >= sellThreshold ? { label: `Auto-selling · price ≥ €${sellThreshold}`, tone: "text-success" } :
    { label: `Idle · waiting (buy ≤ €${buyThreshold} · sell ≥ €${sellThreshold})`, tone: "text-muted-foreground" };

  return (
    <div className="mt-6 rounded-lg border border-border bg-secondary/30 p-4">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h3 className="font-semibold text-sm flex items-center gap-2">
            <Zap className="h-4 w-4 text-accent" /> Auto trading
          </h3>
          <p className="text-xs text-muted-foreground">
            Automatically buy when price drops, sell when price spikes.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">{enabled ? "ON" : "OFF"}</span>
          <Switch checked={enabled} onCheckedChange={setEnabled} />
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-2 mb-3">
        <div>
          <Label className="text-xs">Buy threshold (€/MWh)</Label>
          <Input
            type="number" min={1} value={buyThreshold}
            onChange={(e) => setBuyThreshold(Math.max(1, +e.target.value || 1))}
          />
          <p className="text-[10px] text-muted-foreground mt-1">Buys when current ≤ this price.</p>
        </div>
        <div>
          <Label className="text-xs">Sell threshold (€/MWh)</Label>
          <Input
            type="number" min={1} value={sellThreshold}
            onChange={(e) => setSellThreshold(Math.max(1, +e.target.value || 1))}
          />
          <p className="text-[10px] text-muted-foreground mt-1">Sells when current ≥ this price.</p>
        </div>
      </div>

      <div className={cn("text-xs font-medium mb-3", status.tone)}>{status.label} · current €{price}/MWh</div>

      <div className="grid grid-cols-2 gap-2">
        <Button size="sm" variant="outline" onClick={() => runBuy("manual")} disabled={busy}>
          <ArrowDownRight className="h-3 w-3 mr-1" /> Buy now
        </Button>
        <Button size="sm" variant="outline" onClick={() => runSell("manual")} disabled={busy}>
          <ArrowUpRight className="h-3 w-3 mr-1" /> Sell now
        </Button>
      </div>

      {log.length > 0 && (
        <div className="mt-3 space-y-1">
          {log.map((l, i) => (
            <div key={i} className="text-[11px] flex items-center justify-between">
              <span className={l.side === "buy" ? "text-emerald-500" : "text-amber-500"}>● {l.msg}</span>
              <span className="text-muted-foreground">{l.time}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

const STATUS_COLORS: Record<string, string> = {
  idle: "var(--color-primary)",
  charging: "var(--color-success)",
  driving: "var(--color-accent)",
  discharged: "var(--color-warning)",
  sold: "var(--color-muted-foreground)",
};

const STATUS_LABELS: Record<string, string> = {
  idle: "Idle",
  charging: "Charging",
  driving: "Driving",
  discharged: "Discharged",
  sold: "Sold",
};

function FleetStatusPie({ vehicles }: { vehicles: Vehicle[] }) {
  const { data, total } = useMemo(() => {
    const map = new Map<string, number>();
    for (const v of vehicles) {
      const k = (v.status || "idle").toLowerCase();
      map.set(k, (map.get(k) ?? 0) + 1);
    }
    const order = ["charging", "driving", "idle", "discharged", "sold"];
    const entries = Array.from(map.entries()).sort(
      (a, b) => order.indexOf(a[0]) - order.indexOf(b[0]),
    );
    return {
      data: entries.map(([name, value]) => ({ name, value })),
      total: vehicles.length,
    };
  }, [vehicles]);

  return (
    <Card className="p-6 h-full flex flex-col">
      <div className="flex items-start justify-between gap-2">
        <div>
          <h2 className="font-semibold">Fleet status</h2>
          <p className="text-xs text-muted-foreground">Live status distribution</p>
        </div>
        <Badge variant="outline" className="border-primary/40 text-primary">
          {total} {total === 1 ? "vehicle" : "vehicles"}
        </Badge>
      </div>

      {total === 0 ? (
        <div className="flex flex-1 items-center justify-center py-10 text-sm text-muted-foreground">
          No vehicles loaded yet.
        </div>
      ) : (
        <div className="mt-4 grid gap-4 sm:grid-cols-[160px_1fr] items-center">
          <div className="relative h-40 w-40 mx-auto">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data}
                  dataKey="value"
                  nameKey="name"
                  innerRadius={52}
                  outerRadius={76}
                  paddingAngle={3}
                  stroke="var(--color-card)"
                  strokeWidth={2}
                >
                  {data.map((d) => (
                    <Cell
                      key={d.name}
                      fill={STATUS_COLORS[d.name] ?? "var(--color-muted-foreground)"}
                    />
                  ))}
                </Pie>
                <Tooltip
                  cursor={{ fill: "var(--color-muted)" }}
                  contentStyle={{
                    background: "var(--color-card)",
                    border: "1px solid var(--color-border)",
                    borderRadius: 8,
                    color: "var(--color-foreground)",
                  }}
                  formatter={(v: any, n: any) => [
                    `${v} ${Number(v) === 1 ? "vehicle" : "vehicles"}`,
                    STATUS_LABELS[String(n)] ?? n,
                  ]}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <div className="text-2xl font-semibold leading-none">{total}</div>
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground mt-1">
                total
              </div>
            </div>
          </div>

          <ul className="space-y-2">
            {data.map((d) => {
              const pct = total ? Math.round((d.value / total) * 100) : 0;
              const color = STATUS_COLORS[d.name] ?? "var(--color-muted-foreground)";
              return (
                <li key={d.name} className="flex items-center gap-3">
                  <span
                    className="h-2.5 w-2.5 rounded-full shrink-0"
                    style={{ background: color }}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-baseline justify-between gap-2">
                      <span className="text-sm font-medium capitalize truncate">
                        {STATUS_LABELS[d.name] ?? d.name}
                      </span>
                      <span className="text-xs tabular-nums text-muted-foreground">
                        {d.value} · {pct}%
                      </span>
                    </div>
                    <div className="mt-1 h-1.5 rounded-full bg-muted overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all"
                        style={{ width: `${pct}%`, background: color }}
                      />
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      )}
    </Card>
  );
}

function ProfitStrategyCard({ trades }: { trades: Trade[] }) {
  const [batteryKwh, setBatteryKwh] = useState(0);

  useEffect(() => {
    (async () => {
      const { data } = await supabase.from("ev_vehicles").select("battery_kwh");
      if (data) setBatteryKwh(data.reduce((s, v: any) => s + Number(v.battery_kwh || 0), 0));
    })();
  }, [trades.length]);

  // SMARD-style daily peak / low prices from simulated curve
  const curve = useMemo(() => generateDayCurve(), []);
  const peakPrice = useMemo(() => Math.max(...curve.map((p) => p.price)), [curve]);
  const lowPrice = useMemo(() => Math.min(...curve.map((p) => p.price)), [curve]);

  const stats = useMemo(() => {
    let chargedMwh = 0, dischargedMwh = 0;
    for (const t of trades) {
      if (t.side === "buy") chargedMwh += Number(t.mw);
      else dischargedMwh += Number(t.mw);
    }
    const revenue = dischargedMwh * peakPrice;
    const cost = chargedMwh * lowPrice;
    const grossProfit = revenue - cost;

    // Battery replacement value: industry avg €150 / kWh
    const REPLACEMENT_EUR_PER_KWH = 150;
    const fleetReplacementValue = batteryKwh * REPLACEMENT_EUR_PER_KWH;
    const dailyDegradation = (fleetReplacementValue * 0.018) / 365;
    const netProfit = grossProfit - dailyDegradation;

    return {
      chargedMwh, dischargedMwh, revenue, cost, grossProfit,
      fleetReplacementValue, dailyDegradation, netProfit,
    };
  }, [trades, batteryKwh, peakPrice, lowPrice]);

  const fmt = (n: number) => `€${n.toLocaleString(undefined, { maximumFractionDigits: 2 })}`;

  return (
    <Card className="p-6 space-y-5">
      <div className="flex items-center justify-between">
        <h2 className="font-semibold">Revenue & Cost Breakdown</h2>
        <Badge variant="secondary" className="text-xs">SMARD</Badge>
      </div>

      <div className="rounded-lg border border-border p-3 space-y-1.5">
        <div className="flex items-center justify-between">
          <div className="text-xs font-medium flex items-center gap-1 text-emerald-500">
            <ArrowUpRight className="h-3 w-3" /> Revenue (Selling)
          </div>
          <span className="font-semibold text-emerald-500">{fmt(stats.revenue)}</span>
        </div>
        <div className="text-xs text-muted-foreground">
          {stats.dischargedMwh.toFixed(2)} MWh × €{peakPrice}/MWh
          <span className="opacity-70"> (SMARD Peak)</span>
        </div>
      </div>

      <div className="rounded-lg border border-border p-3 space-y-1.5">
        <div className="flex items-center justify-between">
          <div className="text-xs font-medium flex items-center gap-1 text-red-500">
            <ArrowDownRight className="h-3 w-3" /> Cost (Buying)
          </div>
          <span className="font-semibold text-red-500">−{fmt(stats.cost)}</span>
        </div>
        <div className="text-xs text-muted-foreground">
          {stats.chargedMwh.toFixed(2)} MWh × €{lowPrice}/MWh
          <span className="opacity-70"> (SMARD Low)</span>
        </div>
      </div>

      <div className="rounded-lg border border-border p-3 space-y-1.5">
        <div className="flex items-center justify-between">
          <div className="text-xs font-medium">Daily Degradation Cost</div>
          <span className="font-semibold text-amber-500">−{fmt(stats.dailyDegradation)}</span>
        </div>
        <div className="text-xs text-muted-foreground">
          ({fmt(stats.fleetReplacementValue)} fleet value × 0.018) ÷ 365 days
        </div>
        <div className="text-[10px] text-muted-foreground opacity-70">
          Battery replacement valued at €150/kWh × {batteryKwh.toFixed(0)} kWh total fleet capacity
        </div>
      </div>

      <div className="space-y-2 rounded-lg bg-secondary/50 p-3 text-sm">
        <div className="flex justify-between">
          <span className="text-muted-foreground">Gross Profit</span>
          <span className={cn("font-medium", stats.grossProfit >= 0 ? "text-emerald-500" : "text-red-500")}>
            {fmt(stats.grossProfit)}
          </span>
        </div>
        <div className="border-t border-border pt-2 flex justify-between items-center">
          <span className="font-semibold">Net Profit</span>
          <span className={cn("font-bold text-lg", stats.netProfit >= 0 ? "text-emerald-500" : "text-red-500")}>
            {fmt(stats.netProfit)}
          </span>
        </div>
      </div>
    </Card>
  );
}
