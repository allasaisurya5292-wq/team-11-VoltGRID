import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { AppSidebar } from "@/components/AppSidebar";
import { PageShell } from "@/components/PageShell";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Database, Battery, CheckCircle2, Layers } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/storage")({
  head: () => ({ meta: [{ title: "Storage aggregator — VOLT_GRID" }] }),
  component: StoragePage,
});

type Vehicle = {
  id: string;
  name: string;
  plate_number: string;
  battery_kwh: number;
  soc: number;
  status: string;
  category: string;
  company: string;
};

const MIN_SOC = 20;
const MAX_SOC = 80;
const STORAGE_BLOCK_KWH = 1000; // 1 MWh

function StoragePage() {
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [companyFilter, setCompanyFilter] = useState<string>("all");

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from("ev_vehicles")
        .select("id,name,plate_number,battery_kwh,soc,status,category,company")
        .order("company", { ascending: true });
      if (data) setVehicles(data as Vehicle[]);
      setLoading(false);
    })();
  }, []);

  const companies = useMemo(
    () => Array.from(new Set(vehicles.map((v) => v.company))).sort(),
    [vehicles],
  );

  const filtered = useMemo(
    () =>
      vehicles.filter(
        (v) =>
          (categoryFilter === "all" || v.category === categoryFilter) &&
          (companyFilter === "all" || v.company === companyFilter),
      ),
    [vehicles, categoryFilter, companyFilter],
  );

  const available = useMemo(
    () => filtered.filter((v) => v.soc >= MIN_SOC && v.soc <= MAX_SOC),
    [filtered],
  );

  // Available headroom per vehicle = the kWh we can pull down to MIN_SOC
  // (i.e. (soc - MIN_SOC)/100 × battery). That's the slice each vehicle
  // contributes to the aggregator right now.
  const availability = useMemo(() => {
    const rows = available
      .map((v) => ({
        ...v,
        availableKwh: Math.max(0, ((v.soc - MIN_SOC) / 100) * v.battery_kwh),
      }))
      .sort((a, b) => b.availableKwh - a.availableKwh);
    const totalAvailableKwh = rows.reduce((s, r) => s + r.availableKwh, 0);
    const fullBlocks = Math.floor(totalAvailableKwh / STORAGE_BLOCK_KWH);
    // Number of top vehicles needed to reach 1 MWh (greedy).
    let needed = 0;
    let cum = 0;
    for (const r of rows) {
      needed += 1;
      cum += r.availableKwh;
      if (cum >= STORAGE_BLOCK_KWH) break;
    }
    if (cum < STORAGE_BLOCK_KWH) needed = 0;
    return { rows, totalAvailableKwh, fullBlocks, neededForOneBlock: needed };
  }, [available]);

  return (
    <div className="min-h-screen flex bg-secondary/30">
      <AppSidebar />
      <PageShell
        title="Storage aggregator"
        description="Aggregate idle EV capacity (SoC 20–80%) into dispatchable storage blocks."
      >
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Metric
            icon={<Database className="h-4 w-4" />}
            label="Fleet under management"
            value={String(filtered.length)}
            hint={`${vehicles.length} total in DB`}
            accent="primary"
          />
          <Metric
            icon={<CheckCircle2 className="h-4 w-4" />}
            label="Available now"
            value={String(available.length)}
            hint={`SoC ${MIN_SOC}–${MAX_SOC}%`}
            accent="success"
          />
          <Metric
            icon={<Battery className="h-4 w-4" />}
            label="Aggregated capacity"
            value={`${(availability.totalAvailableKwh / 1000).toFixed(2)} MWh`}
            hint="Headroom down to 20% SoC"
            accent="warning"
          />
          <Metric
            icon={<Layers className="h-4 w-4" />}
            label="1 MWh storage blocks"
            value={String(availability.fullBlocks)}
            hint={
              availability.neededForOneBlock > 0
                ? `${availability.neededForOneBlock} vehicles per block`
                : "Insufficient capacity"
            }
            accent={availability.fullBlocks > 0 ? "success" : "destructive"}
          />
        </div>

        <Card className="mt-6 p-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="text-sm font-medium mr-2">Filters</div>
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-44">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All categories</SelectItem>
                <SelectItem value="Bus">Buses</SelectItem>
                <SelectItem value="Car">Cars</SelectItem>
              </SelectContent>
            </Select>
            <Select value={companyFilter} onValueChange={setCompanyFilter}>
              <SelectTrigger className="w-56">
                <SelectValue placeholder="Company" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All companies</SelectItem>
                {companies.map((c) => (
                  <SelectItem key={c} value={c}>
                    {c}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="text-xs text-muted-foreground ml-auto">
              Aggregator rule: pick vehicles with SoC between {MIN_SOC}% and {MAX_SOC}%; each
              contributes (SoC − {MIN_SOC}%) × battery kWh; blocks of {STORAGE_BLOCK_KWH} kWh form
              one MWh of dispatchable storage.
            </div>
          </div>
        </Card>

        <Card className="mt-6 overflow-hidden">
          <div className="px-4 py-3 border-b border-border">
            <h2 className="font-semibold text-sm">Vehicle pool</h2>
            <p className="text-xs text-muted-foreground">
              Available vehicles ranked by contributable kWh
            </p>
          </div>
          <div className="max-h-[520px] overflow-y-auto overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted text-foreground text-xs font-bold uppercase tracking-wider sticky top-0 z-10">
                <tr>
                  <th className="text-left px-4 py-2">Vehicle</th>
                  <th className="text-left px-4 py-2">Plate</th>
                  <th className="text-left px-4 py-2">Category</th>
                  <th className="text-left px-4 py-2">Company</th>
                  <th className="text-right px-4 py-2">Battery (kWh)</th>
                  <th className="text-right px-4 py-2">SoC (%)</th>
                  <th className="text-right px-4 py-2">Available (kWh)</th>
                  <th className="text-center px-4 py-2">Status</th>
                </tr>
              </thead>
              <tbody>
                {loading && (
                  <tr>
                    <td colSpan={8} className="px-4 py-6 text-center text-muted-foreground">
                      Loading fleet…
                    </td>
                  </tr>
                )}
                {!loading &&
                  filtered.map((v) => {
                    const isAvailable = v.soc >= MIN_SOC && v.soc <= MAX_SOC;
                    const availableKwh = isAvailable
                      ? ((v.soc - MIN_SOC) / 100) * v.battery_kwh
                      : 0;
                    return (
                      <tr key={v.id} className="border-t border-border">
                        <td className="px-4 py-2 font-medium">{v.name}</td>
                        <td className="px-4 py-2 text-muted-foreground">{v.plate_number}</td>
                        <td className="px-4 py-2">
                          <Badge variant="outline">{v.category}</Badge>
                        </td>
                        <td className="px-4 py-2">{v.company}</td>
                        <td className="px-4 py-2 text-right">{v.battery_kwh}</td>
                        <td className="px-4 py-2 text-right">{v.soc}%</td>
                        <td className="px-4 py-2 text-right font-medium">
                          {availableKwh > 0 ? `${availableKwh.toFixed(1)}` : "—"}
                        </td>
                        <td className="px-4 py-2 text-center">
                          {isAvailable ? (
                            <Badge className="bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border-emerald-500/40">
                              Available
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="text-muted-foreground">
                              Out of band
                            </Badge>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                {!loading && filtered.length === 0 && (
                  <tr>
                    <td colSpan={8} className="px-4 py-6 text-center text-muted-foreground">
                      No vehicles match the current filters.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>
      </PageShell>
    </div>
  );
}

function Metric({
  icon,
  label,
  value,
  hint,
  accent,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  hint: string;
  accent: "primary" | "success" | "warning" | "destructive" | "muted";
}) {
  const accentClass =
    accent === "primary"
      ? "bg-primary/10 text-primary"
      : accent === "success"
        ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
        : accent === "warning"
          ? "bg-amber-500/10 text-amber-600 dark:text-amber-400"
          : accent === "destructive"
            ? "bg-destructive/10 text-destructive"
            : "bg-muted text-muted-foreground";
  return (
    <Card className="p-4">
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <span className={`rounded-md p-1.5 ${accentClass}`}>{icon}</span>
        {label}
      </div>
      <div className="mt-2 text-2xl font-semibold">{value}</div>
      <div className="text-xs text-muted-foreground mt-0.5">{hint}</div>
    </Card>
  );
}
