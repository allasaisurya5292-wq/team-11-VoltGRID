import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { AppSidebar } from "@/components/AppSidebar";
import { PageShell } from "@/components/PageShell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Download, Printer, FileText, ShieldCheck, CalendarRange, CalendarDays, Sliders } from "lucide-react";
import sessionsCsv from "@/assets/battery-sessions.csv?raw";

export const Route = createFileRoute("/reports")({
  head: () => ({
    meta: [
      { title: "Reports — VOLT_GRID" },
      {
        name: "description",
        content:
          "Generate, customise, print and download monthly or yearly fleet and battery reports.",
      },
    ],
  }),
  component: ReportsPage,
});

type Row = {
  vehicle_name: string;
  plate_number: string;
  battery_capacity_kwh: number;
  soc_start_pct: number;
  soc_end_pct: number;
  peak_kw: number;
  status: string;
  in_service_since: string;
  current_soh_pct: number;
  distance_km: number;
  v2g_degradation_pct: number;
  operational_degradation_pct: number;
};

const ALL_COLUMNS: { key: keyof Row; label: string; numeric?: boolean; unit?: string }[] = [
  { key: "vehicle_name", label: "Vehicle" },
  { key: "plate_number", label: "Plate" },
  { key: "status", label: "Status" },
  { key: "in_service_since", label: "In service since" },
  { key: "battery_capacity_kwh", label: "Capacity", numeric: true, unit: "kWh" },
  { key: "current_soh_pct", label: "SoH", numeric: true, unit: "%" },
  { key: "soc_start_pct", label: "SoC start", numeric: true, unit: "%" },
  { key: "soc_end_pct", label: "SoC end", numeric: true, unit: "%" },
  { key: "peak_kw", label: "Peak", numeric: true, unit: "kW" },
  { key: "distance_km", label: "Distance", numeric: true, unit: "km" },
  { key: "v2g_degradation_pct", label: "V2G deg.", numeric: true, unit: "%" },
  { key: "operational_degradation_pct", label: "Op. deg.", numeric: true, unit: "%" },
];

function parseCsv(csv: string): Row[] {
  const lines = csv.trim().split(/\r?\n/);
  const headers = lines[0].split(",").map((h) => h.trim());
  return lines.slice(1).map((line) => {
    const cols = line.split(",").map((c) => c.trim());
    const r: Record<string, string> = {};
    headers.forEach((h, i) => (r[h] = cols[i] ?? ""));
    return {
      vehicle_name: r.vehicle_name,
      plate_number: r.plate_number,
      battery_capacity_kwh: Number(r.battery_capacity_kwh),
      soc_start_pct: Number(r.soc_start_pct),
      soc_end_pct: Number(r.soc_end_pct),
      peak_kw: Number(r.peak_kw),
      status: r.status,
      in_service_since: r.in_service_since,
      current_soh_pct: Number(r.current_soh_pct),
      distance_km: Number(r.distance_km),
      v2g_degradation_pct: Number(r.v2g_degradation_pct),
      operational_degradation_pct: Number(r.operational_degradation_pct),
    };
  });
}

type Period = "monthly" | "quarterly" | "yearly" | "custom";

function periodRange(period: Period, ref: Date, customFrom?: string, customTo?: string) {
  if (period === "custom") {
    return {
      from: customFrom ? new Date(customFrom) : new Date(0),
      to: customTo ? new Date(customTo) : new Date(),
    };
  }
  const to = new Date(ref);
  const from = new Date(ref);
  if (period === "monthly") from.setMonth(from.getMonth() - 1);
  if (period === "quarterly") from.setMonth(from.getMonth() - 3);
  if (period === "yearly") from.setFullYear(from.getFullYear() - 1);
  return { from, to };
}

// Standard EV battery warranty: 8 years / 160,000 km / SoH ≥ 70%
const WARRANTY_YEARS = 8;
const WARRANTY_KM = 160000;
const WARRANTY_SOH = 70;

function ageYears(d: string): number {
  const t = new Date(d).getTime();
  if (Number.isNaN(t)) return 0;
  return (Date.now() - t) / (1000 * 60 * 60 * 24 * 365.25);
}

type WarrantyTone = "ok" | "warn" | "bad";
type WarrantyLabel =
  | "Healthy"
  | "Monitor"
  | "Near Warranty Expiry"
  | "Potential Warranty Claim"
  | "Warranty Expired";

function warrantyStatus(r: Row) {
  const age = ageYears(r.in_service_since);
  const yearsLeft = Math.max(0, WARRANTY_YEARS - age);
  const kmLeft = Math.max(0, WARRANTY_KM - r.distance_km);
  const timeExpired = yearsLeft <= 0;
  const kmExpired = kmLeft <= 0;
  const warrantyActive = !timeExpired && !kmExpired;
  const sohBelow = r.current_soh_pct < WARRANTY_SOH;

  // Stressor proxy — dataset has no cycle count / IR / cell imbalance / DTCs,
  // so combined V2G + operational degradation is used as the stress signal.
  const stress = (r.v2g_degradation_pct ?? 0) + (r.operational_degradation_pct ?? 0);
  const highStress = stress > 12;

  const conditions: { ok: boolean; text: string }[] = [
    { ok: !timeExpired, text: `Age ${age.toFixed(1)}y / ${WARRANTY_YEARS}y limit` },
    { ok: !kmExpired, text: `Mileage ${r.distance_km.toLocaleString()} / ${WARRANTY_KM.toLocaleString()} km` },
    { ok: !sohBelow, text: `SoH ${r.current_soh_pct.toFixed(1)}% vs ≥ ${WARRANTY_SOH}% threshold` },
  ];

  let label: WarrantyLabel;
  let tone: WarrantyTone;
  let claimEligible = false;
  let reason = "";
  let confidence: "Low" | "Medium" | "High" = "High";

  if (warrantyActive && sohBelow) {
    label = "Potential Warranty Claim";
    tone = "warn";
    claimEligible = true;
    reason = `SoH ${r.current_soh_pct.toFixed(1)}% is below the ${WARRANTY_SOH}% threshold while still inside the ${WARRANTY_YEARS}y / ${WARRANTY_KM.toLocaleString()}km window — OEM replacement should apply.`;
  } else if (!warrantyActive) {
    label = "Warranty Expired";
    tone = "bad";
    reason = timeExpired && kmExpired
      ? `Both the ${WARRANTY_YEARS}-year and ${WARRANTY_KM.toLocaleString()}-km limits have been exceeded.`
      : timeExpired
        ? `In service for ${age.toFixed(1)} years — past the ${WARRANTY_YEARS}-year age limit.`
        : `Odometer at ${r.distance_km.toLocaleString()} km — past the ${WARRANTY_KM.toLocaleString()}-km limit.`;
  } else if (yearsLeft < 1 || kmLeft < 10000) {
    label = "Near Warranty Expiry";
    tone = "warn";
    reason = `${yearsLeft.toFixed(1)} years and ${kmLeft.toLocaleString()} km of coverage remaining — schedule a pre-expiry inspection.`;
  } else if (r.current_soh_pct < WARRANTY_SOH + 5 || highStress) {
    label = "Monitor";
    tone = "warn";
    reason = highStress
      ? `Cumulative degradation ${stress.toFixed(1)}% indicates elevated stress — monitor SoH monthly.`
      : `SoH ${r.current_soh_pct.toFixed(1)}% is within 5% of the ${WARRANTY_SOH}% claim threshold.`;
    confidence = "Medium";
  } else {
    label = "Healthy";
    tone = "ok";
    reason = `All conditions met: age ${age.toFixed(1)}y, ${r.distance_km.toLocaleString()} km, SoH ${r.current_soh_pct.toFixed(1)}%.`;
  }

  const covered = warrantyActive && !sohBelow;
  return { age, yearsLeft, kmLeft, warrantyActive, claimEligible, covered, label, tone, reason, confidence, conditions };
}

type TemplateId = "warranty" | "monthly" | "yearly" | "flexible";

function ReportsPage() {
  const all = useMemo(() => parseCsv(sessionsCsv), []);
  const [template, setTemplate] = useState<TemplateId>("monthly");
  const [period, setPeriod] = useState<Period>("monthly");
  const [refDate, setRefDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [customFrom, setCustomFrom] = useState<string>("");
  const [customTo, setCustomTo] = useState<string>("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [selected, setSelected] = useState<Set<keyof Row>>(
    new Set(ALL_COLUMNS.map((c) => c.key)),
  );
  const [title, setTitle] = useState<string>("Fleet & Battery Report");
  const [includeSummary, setIncludeSummary] = useState(true);
  const [includeTable, setIncludeTable] = useState(true);
  const [includeWarranty, setIncludeWarranty] = useState(false);

  // Fix SSR hydration mismatch — render timestamp only after mount
  const [generatedAt, setGeneratedAt] = useState<string>("");
  useEffect(() => {
    setGeneratedAt(new Date().toLocaleString());
  }, [period, refDate, customFrom, customTo, statusFilter, template]);

  function applyTemplate(id: TemplateId) {
    setTemplate(id);
    if (id === "warranty") {
      setTitle("Battery Warranty Report");
      setPeriod("yearly");
      setIncludeSummary(true);
      setIncludeTable(true);
      setIncludeWarranty(true);
      setSelected(
        new Set<keyof Row>([
          "vehicle_name",
          "plate_number",
          "in_service_since",
          "battery_capacity_kwh",
          "current_soh_pct",
          "distance_km",
        ]),
      );
    } else if (id === "monthly") {
      setTitle("Monthly Battery Performance Report");
      setPeriod("monthly");
      setIncludeSummary(true);
      setIncludeTable(true);
      setIncludeWarranty(false);
      setSelected(
        new Set<keyof Row>([
          "vehicle_name",
          "plate_number",
          "status",
          "current_soh_pct",
          "soc_start_pct",
          "soc_end_pct",
          "peak_kw",
          "distance_km",
        ]),
      );
    } else if (id === "yearly") {
      setTitle("Yearly Battery Health Report");
      setPeriod("yearly");
      setIncludeSummary(true);
      setIncludeTable(true);
      setIncludeWarranty(true);
      setSelected(
        new Set<keyof Row>([
          "vehicle_name",
          "plate_number",
          "in_service_since",
          "battery_capacity_kwh",
          "current_soh_pct",
          "v2g_degradation_pct",
          "operational_degradation_pct",
          "distance_km",
        ]),
      );
    } else {
      setTitle("Custom Battery Report");
      setPeriod("custom");
      setIncludeSummary(true);
      setIncludeTable(true);
      setIncludeWarranty(false);
      setSelected(new Set(ALL_COLUMNS.map((c) => c.key)));
    }
  }

  const { from, to } = periodRange(period, new Date(refDate), customFrom, customTo);

  const rows = useMemo(() => {
    return all.filter((r) => {
      if (statusFilter !== "all" && r.status !== statusFilter) return false;
      // Include vehicles in service before "to" date
      const svc = new Date(r.in_service_since).getTime();
      if (!Number.isNaN(svc) && svc > to.getTime()) return false;
      return true;
    });
  }, [all, statusFilter, to]);

  const summary = useMemo(() => {
    const n = rows.length || 1;
    return {
      vehicles: rows.length,
      avgSoh: rows.reduce((s, r) => s + r.current_soh_pct, 0) / n,
      totalCapacity: rows.reduce((s, r) => s + r.battery_capacity_kwh, 0),
      totalKm: rows.reduce((s, r) => s + r.distance_km, 0),
      avgV2g: rows.reduce((s, r) => s + r.v2g_degradation_pct, 0) / n,
      avgOp: rows.reduce((s, r) => s + r.operational_degradation_pct, 0) / n,
      active: rows.filter((r) => r.status === "active").length,
    };
  }, [rows]);

  const visibleCols = ALL_COLUMNS.filter((c) => selected.has(c.key));

  function toggleCol(k: keyof Row) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(k)) next.delete(k);
      else next.add(k);
      return next;
    });
  }

  function downloadCsv() {
    const header = visibleCols.map((c) => c.label).join(",");
    const body = rows
      .map((r) =>
        visibleCols
          .map((c) => {
            const v = r[c.key];
            return typeof v === "string" && v.includes(",") ? `"${v}"` : String(v);
          })
          .join(","),
      )
      .join("\n");
    const blob = new Blob([`${header}\n${body}\n`], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${title.replace(/\s+/g, "_")}_${from.toISOString().slice(0, 10)}_${to.toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function downloadJson() {
    const payload = {
      title,
      period,
      from: from.toISOString(),
      to: to.toISOString(),
      summary,
      vehicles: rows.map((r) =>
        Object.fromEntries(visibleCols.map((c) => [c.key, r[c.key]])),
      ),
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${title.replace(/\s+/g, "_")}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  const fmtDate = (d: Date) => d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });

  return (
    <div className="min-h-screen flex bg-secondary/30">
      <AppSidebar />
      <PageShell
        title="Reports"
        description="Build, customise, print and export monthly or yearly fleet & battery reports."
      >
        {/* Controls — hidden in print */}
        <div className="print:hidden grid gap-4 lg:grid-cols-[320px_1fr]">
          <Card className="p-4 space-y-4">
            <div>
              <Label className="text-xs mb-2 block">Templates</Label>
              <div className="grid grid-cols-2 gap-2">
                <TemplateButton
                  active={template === "warranty"}
                  onClick={() => applyTemplate("warranty")}
                  icon={<ShieldCheck className="h-4 w-4" />}
                  label="Warranty"
                  sub="8y / 160k / 70% SoH"
                />
                <TemplateButton
                  active={template === "monthly"}
                  onClick={() => applyTemplate("monthly")}
                  icon={<CalendarDays className="h-4 w-4" />}
                  label="Monthly"
                  sub="Last 30 days"
                />
                <TemplateButton
                  active={template === "yearly"}
                  onClick={() => applyTemplate("yearly")}
                  icon={<CalendarRange className="h-4 w-4" />}
                  label="Yearly"
                  sub="Last 12 months"
                />
                <TemplateButton
                  active={template === "flexible"}
                  onClick={() => applyTemplate("flexible")}
                  icon={<Sliders className="h-4 w-4" />}
                  label="Flexible"
                  sub="Custom dates"
                />
              </div>
            </div>

            <div>
              <Label className="text-xs">Report title</Label>
              <Input value={title} onChange={(e) => setTitle(e.target.value)} className="mt-1" />
            </div>

            <div>
              <Label className="text-xs">Period</Label>
              <Select value={period} onValueChange={(v) => setPeriod(v as Period)}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="monthly">Monthly (last 30 days)</SelectItem>
                  <SelectItem value="quarterly">Quarterly (last 3 months)</SelectItem>
                  <SelectItem value="yearly">Yearly (last 12 months)</SelectItem>
                  <SelectItem value="custom">Custom range</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {period !== "custom" ? (
              <div>
                <Label className="text-xs">Reference date</Label>
                <Input type="date" value={refDate} onChange={(e) => setRefDate(e.target.value)} className="mt-1" />
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-xs">From</Label>
                  <Input type="date" value={customFrom} onChange={(e) => setCustomFrom(e.target.value)} className="mt-1" />
                </div>
                <div>
                  <Label className="text-xs">To</Label>
                  <Input type="date" value={customTo} onChange={(e) => setCustomTo(e.target.value)} className="mt-1" />
                </div>
              </div>
            )}

            <div>
              <Label className="text-xs">Status filter</Label>
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All vehicles</SelectItem>
                  <SelectItem value="active">Active only</SelectItem>
                  <SelectItem value="maintenance">In maintenance</SelectItem>
                  <SelectItem value="idle">Idle</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-xs">Sections</Label>
              <label className="flex items-center gap-2 text-sm">
                <Checkbox checked={includeSummary} onCheckedChange={(v) => setIncludeSummary(!!v)} />
                Executive summary
              </label>
              <label className="flex items-center gap-2 text-sm">
                <Checkbox checked={includeWarranty} onCheckedChange={(v) => setIncludeWarranty(!!v)} />
                Warranty analysis
              </label>
              <label className="flex items-center gap-2 text-sm">
                <Checkbox checked={includeTable} onCheckedChange={(v) => setIncludeTable(!!v)} />
                Vehicle table
              </label>
            </div>

            <div>
              <Label className="text-xs">Columns</Label>
              <div className="mt-1 grid grid-cols-2 gap-1.5 max-h-56 overflow-y-auto pr-1">
                {ALL_COLUMNS.map((c) => (
                  <label key={c.key} className="flex items-center gap-2 text-xs">
                    <Checkbox
                      checked={selected.has(c.key)}
                      onCheckedChange={() => toggleCol(c.key)}
                    />
                    {c.label}
                  </label>
                ))}
              </div>
            </div>

            <div className="flex flex-col gap-2 pt-2 border-t border-border">
              <Button onClick={() => window.print()} className="gap-2">
                <Printer className="h-4 w-4" /> Print / Save as PDF
              </Button>
              <Button variant="outline" onClick={downloadCsv} className="gap-2">
                <Download className="h-4 w-4" /> Download CSV
              </Button>
              <Button variant="outline" onClick={downloadJson} className="gap-2">
                <FileText className="h-4 w-4" /> Download JSON
              </Button>
            </div>
          </Card>

          {/* Preview */}
          <ReportPreview
            title={title}
            from={from}
            to={to}
            period={period}
            rows={rows}
            visibleCols={visibleCols}
            summary={summary}
            includeSummary={includeSummary}
            includeWarranty={includeWarranty}
            includeTable={includeTable}
            generatedAt={generatedAt}
            fmtDate={fmtDate}
          />
        </div>

        {/* Print-only version */}
        <div className="hidden print:block">
          <ReportPreview
            title={title}
            from={from}
            to={to}
            period={period}
            rows={rows}
            visibleCols={visibleCols}
            summary={summary}
            includeSummary={includeSummary}
            includeWarranty={includeWarranty}
            includeTable={includeTable}
            generatedAt={generatedAt}
            fmtDate={fmtDate}
            printMode
          />
        </div>
      </PageShell>
    </div>
  );
}

function TemplateButton({
  active,
  onClick,
  icon,
  label,
  sub,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
  sub: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`text-left rounded-md border p-2.5 transition-colors ${
        active
          ? "border-primary bg-primary/10 text-foreground"
          : "border-border hover:bg-muted"
      }`}
    >
      <div className="flex items-center gap-1.5 text-xs font-medium">
        {icon}
        {label}
      </div>
      <div className="text-[10px] text-muted-foreground mt-0.5">{sub}</div>
    </button>
  );
}

function ReportPreview({
  title,
  from,
  to,
  period,
  rows,
  visibleCols,
  summary,
  includeSummary,
  includeTable,
  includeWarranty,
  generatedAt,
  fmtDate,
  printMode,
}: {
  title: string;
  from: Date;
  to: Date;
  period: Period;
  rows: Row[];
  visibleCols: typeof ALL_COLUMNS;
  summary: {
    vehicles: number;
    avgSoh: number;
    totalCapacity: number;
    totalKm: number;
    avgV2g: number;
    avgOp: number;
    active: number;
  };
  includeSummary: boolean;
  includeTable: boolean;
  includeWarranty: boolean;
  generatedAt: string;
  fmtDate: (d: Date) => string;
  printMode?: boolean;
}) {
  return (
    <Card className={printMode ? "shadow-none border-0 p-0" : "p-6"}>
      <header className="flex items-start justify-between gap-4 pb-4 border-b border-border">
        <div>
          <div className="text-xs uppercase tracking-wider text-muted-foreground">VOLT_GRID · Report</div>
          <h1 className="text-2xl font-semibold mt-1">{title}</h1>
          <p className="text-sm text-muted-foreground mt-1">
            {period.charAt(0).toUpperCase() + period.slice(1)} · {fmtDate(from)} – {fmtDate(to)}
          </p>
        </div>
        <div className="text-right text-xs text-muted-foreground">
          <div>Generated {generatedAt || "…"}</div>
          <Badge variant="outline" className="mt-2">{rows.length} vehicles</Badge>
        </div>
      </header>

      {includeSummary && (
        <section className="mt-6">
          <h2 className="text-sm font-semibold mb-3">Executive summary</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <Stat label="Vehicles" value={String(summary.vehicles)} />
            <Stat label="Active" value={String(summary.active)} />
            <Stat label="Avg SoH" value={`${summary.avgSoh.toFixed(1)}%`} />
            <Stat label="Total capacity" value={`${summary.totalCapacity.toLocaleString()} kWh`} />
            <Stat label="Total distance" value={`${summary.totalKm.toLocaleString()} km`} />
            <Stat label="Avg V2G deg." value={`${summary.avgV2g.toFixed(2)}%`} />
            <Stat label="Avg op. deg." value={`${summary.avgOp.toFixed(2)}%`} />
            <Stat label="Period" value={`${Math.round((to.getTime() - from.getTime()) / 86400000)} days`} />
          </div>
        </section>
      )}

      {includeWarranty && (() => {
        const items = rows.map((r) => ({ r, w: warrantyStatus(r) }));
        const counts = {
          healthy: items.filter((i) => i.w.label === "Healthy").length,
          monitor: items.filter((i) => i.w.label === "Monitor").length,
          near: items.filter((i) => i.w.label === "Near Warranty Expiry").length,
          claim: items.filter((i) => i.w.label === "Potential Warranty Claim").length,
          expired: items.filter((i) => i.w.label === "Warranty Expired").length,
        };
        return (
          <section className="mt-6">
            <h2 className="text-sm font-semibold mb-1">Battery warranty analysis</h2>
            <p className="text-[11px] text-muted-foreground mb-3">
              Coverage criteria: {WARRANTY_YEARS} years · {WARRANTY_KM.toLocaleString()} km · SoH ≥ {WARRANTY_SOH}% (whichever ends first). Each battery is classified into one of five statuses with a reasoned explanation.
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-4">
              <Stat label="Healthy" value={String(counts.healthy)} />
              <Stat label="Monitor" value={String(counts.monitor)} />
              <Stat label="Near Expiry" value={String(counts.near)} />
              <Stat label="Claim Candidates" value={String(counts.claim)} />
              <Stat label="Expired" value={String(counts.expired)} />
            </div>
            <div className="max-h-[420px] overflow-y-auto overflow-x-auto rounded-md border border-border print:max-h-none print:overflow-visible">
              <table className="w-full text-xs">
                <thead className="bg-muted uppercase tracking-wider sticky top-0 z-10">
                  <tr>
                    <th className="text-left px-3 py-2">Vehicle</th>
                    <th className="text-right px-3 py-2">Age</th>
                    <th className="text-right px-3 py-2">Yrs left</th>
                    <th className="text-right px-3 py-2">Km left</th>
                    <th className="text-right px-3 py-2">SoH</th>
                    <th className="text-left px-3 py-2">Status</th>
                    <th className="text-left px-3 py-2">Explanation</th>
                    <th className="text-center px-3 py-2">Confidence</th>
                  </tr>
                </thead>
                <tbody>
                  {items.map(({ r, w }) => (
                    <tr key={r.plate_number} className="border-t border-border align-top">
                      <td className="px-3 py-1.5">
                        <div className="font-medium">{r.vehicle_name}</div>
                        <div className="text-[10px] text-muted-foreground">{r.plate_number}</div>
                      </td>
                      <td className="px-3 py-1.5 text-right">{w.age.toFixed(1)}y</td>
                      <td className="px-3 py-1.5 text-right">{w.yearsLeft.toFixed(1)}</td>
                      <td className="px-3 py-1.5 text-right">{w.kmLeft.toLocaleString()}</td>
                      <td className="px-3 py-1.5 text-right">{r.current_soh_pct.toFixed(1)}%</td>
                      <td className="px-3 py-1.5">
                        <Badge
                          variant="outline"
                          className={
                            w.tone === "bad"
                              ? "border-destructive/40 text-destructive bg-destructive/10"
                              : w.tone === "warn"
                                ? "border-amber-500/40 text-amber-600 dark:text-amber-400 bg-amber-500/10"
                                : "border-emerald-500/40 text-emerald-600 dark:text-emerald-400 bg-emerald-500/10"
                          }
                        >
                          {w.label}
                        </Badge>
                      </td>
                      <td className="px-3 py-1.5 max-w-[320px] text-[11px] text-muted-foreground">
                        <div className="mb-1">{w.reason}</div>
                        <div className="flex flex-wrap gap-1">
                          {w.conditions.map((c, i) => (
                            <span
                              key={i}
                              className={`rounded px-1.5 py-0.5 text-[10px] border ${
                                c.ok
                                  ? "border-emerald-500/30 text-emerald-600 dark:text-emerald-400 bg-emerald-500/5"
                                  : "border-destructive/30 text-destructive bg-destructive/5"
                              }`}
                            >
                              {c.ok ? "✓" : "✗"} {c.text}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td className="px-3 py-1.5 text-center">
                        <Badge variant="outline" className="text-[10px]">{w.confidence}</Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        );
      })()}

      {includeTable && (
        <section className="mt-6">
          <h2 className="text-sm font-semibold mb-3">Vehicle detail</h2>
          <div className="max-h-[420px] overflow-y-auto overflow-x-auto rounded-md border border-border print:max-h-none print:overflow-visible">
            <table className="w-full text-xs">
              <thead className="bg-muted text-foreground uppercase tracking-wider sticky top-0 z-10">
                <tr>
                  {visibleCols.map((c) => (
                    <th key={c.key} className={`px-3 py-2 ${c.numeric ? "text-right" : "text-left"}`}>
                      {c.label}{c.unit ? ` (${c.unit})` : ""}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.plate_number} className="border-t border-border">
                    {visibleCols.map((c) => {
                      const v = r[c.key];
                      const display = c.numeric && typeof v === "number" ? v.toLocaleString(undefined, { maximumFractionDigits: 1 }) : String(v);
                      return (
                        <td key={c.key} className={`px-3 py-1.5 ${c.numeric ? "text-right" : "text-left"}`}>
                          {display}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      )}

      <footer className="mt-6 pt-4 border-t border-border text-[10px] text-muted-foreground">
        Source: Battery sessions dataset · VOLT_GRID fleet platform · This report is generated on demand and reflects data available at generation time.
      </footer>
    </Card>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-border p-3 bg-card">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="text-base font-semibold mt-1">{value}</div>
    </div>
  );
}
