import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { AppSidebar } from "@/components/AppSidebar";
import { PageShell } from "@/components/PageShell";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Battery, Activity, Car, Cloud, FileText } from "lucide-react";

import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
} from "recharts";
import sessionsCsv from "@/assets/battery-sessions.csv?raw";
import { supabase } from "@/integrations/supabase/client";





// (Economics block removed — analytics page focuses on fleet health.)


export const Route = createFileRoute("/battery-analytics")({
  head: () => ({ meta: [{ title: "Battery analytics — VOLT_GRID" }] }),
  component: BatteryAnalyticsPage,
});

type Session = {
  vehicle_name: string;
  plate_number: string;
  battery_capacity_kwh: number;
  soc_start_pct: number;
  soc_end_pct: number;
  peak_kw: number;
  status: string;
  in_service_since: string;
  current_soh_pct: number;
  distance_km: number;
  v2g_degradation_pct: number;
  operational_degradation_pct: number;
  temperature_c: number;
  source: "CSV" | "API";
};

// Deterministic pseudo-temperature derived from load, age and health.
// Hotter packs degrade faster, so this also acts as a health indicator.
function estimateTemperature(peakKw: number, soh: number, plate: string): number {
  let h = 0;
  for (let i = 0; i < plate.length; i++) h = (h * 31 + plate.charCodeAt(i)) >>> 0;
  const jitter = ((h % 100) / 100) * 6 - 3; // ±3°C
  const base = 24 + (100 - soh) * 0.55 + peakKw * 0.025 + jitter;
  return Math.round(base * 10) / 10;
}

const TURNOVER_CAP_PCT = 43; // daily cap to stay under 1.8% annual degradation

function parseCsv(csv: string): Session[] {
  const lines = csv.trim().split(/\r?\n/);
  const headers = lines[0].split(",").map((h) => h.trim());
  return lines.slice(1).map((line) => {
    const cols = line.split(",").map((c) => c.trim());
    const row: Record<string, string> = {};
    headers.forEach((h, i) => (row[h] = cols[i] ?? ""));
    return {
      vehicle_name: row.vehicle_name,
      plate_number: row.plate_number,
      battery_capacity_kwh: Number(row.battery_capacity_kwh),
      soc_start_pct: Number(row.soc_start_pct),
      soc_end_pct: Number(row.soc_end_pct),
      peak_kw: Number(row.peak_kw),
      status: row.status || "active",
      in_service_since: row.in_service_since,
      current_soh_pct: Number(row.current_soh_pct),
      distance_km: Number(row.distance_km),
      v2g_degradation_pct: Number(row.v2g_degradation_pct),
      operational_degradation_pct: Number(row.operational_degradation_pct),
      temperature_c: estimateTemperature(Number(row.peak_kw), Number(row.current_soh_pct), row.plate_number),
      source: "CSV",
    };
  });
}

// Estimate SoH from vehicle age (years since in-service) using ~1.5%/yr degradation
function estimateSoh(inServiceSince: string): number {
  if (!inServiceSince) return 100;
  const t = new Date(inServiceSince).getTime();
  if (Number.isNaN(t)) return 100;
  const years = (Date.now() - t) / (1000 * 60 * 60 * 24 * 365.25);
  return Math.max(70, Math.round((100 - years * 1.5) * 10) / 10);
}

function dbVehicleToSession(v: any): Session {
  const inService = v.created_at ?? new Date().toISOString();
  const soh = estimateSoh(inService);
  const opDeg = Math.max(0, Math.round((100 - soh) * 10) / 10);
  return {
    vehicle_name: v.name ?? `Vehicle ${String(v.id).slice(0, 6)}`,
    plate_number: v.plate_number || `API-${String(v.id).slice(0, 6).toUpperCase()}`,
    battery_capacity_kwh: Number(v.battery_kwh) || 0,
    soc_start_pct: Number(v.soc) || 0,
    soc_end_pct: Number(v.soc) || 0,
    peak_kw: 0,
    status: v.status || "idle",
    in_service_since: inService.slice(0, 10),
    current_soh_pct: soh,
    distance_km: Number(v.odometer_km) || 0,
    v2g_degradation_pct: 0,
    operational_degradation_pct: opDeg,
    temperature_c: estimateTemperature(0, soh, v.plate_number || String(v.id)),
    source: "API",
  };
}

function ageYears(dateStr: string): number {
  if (!dateStr) return 0;
  const start = new Date(dateStr).getTime();
  if (Number.isNaN(start)) return 0;
  const years = (Date.now() - start) / (1000 * 60 * 60 * 24 * 365.25);
  return Math.round(years * 10) / 10;
}

function BatteryAnalyticsPage() {
  const sessions = useMemo(() => parseCsv(sessionsCsv), []);


  const metrics = useMemo(() => {
    const active = sessions.filter((s) => s.status === "active");
    const perVehicle = active.map((s) => ({ ...s }));

    const now = Date.now();
    let sohSum = 0;
    let ageSum = 0;
    let v2gTotal = 0;
    let opTotal = 0;
    sessions.forEach((r) => {
      sohSum += r.current_soh_pct || 0;
      const t = new Date(r.in_service_since).getTime();
      if (!Number.isNaN(t)) ageSum += (now - t) / (1000 * 60 * 60 * 24 * 365.25);
      v2gTotal += r.v2g_degradation_pct || 0;
      opTotal += r.operational_degradation_pct || 0;
    });
    const n = sessions.length || 1;

    // Health buckets by current SoH
    const buckets = { Healthy: 0, Monitor: 0, "Need replacement": 0, Critical: 0 };
    sessions.forEach((r) => {
      const s = r.current_soh_pct;
      if (s < 70) buckets.Critical += 1;
      else if (s < 80) buckets["Need replacement"] += 1;
      else if (s < 90) buckets.Monitor += 1;
      else buckets.Healthy += 1;
    });
    const healthData = [
      { name: "Healthy", value: buckets.Healthy, color: "hsl(142 71% 45%)" },
      { name: "Monitor", value: buckets.Monitor, color: "hsl(38 92% 50%)" },
      { name: "Need replacement", value: buckets["Need replacement"], color: "hsl(25 95% 53%)" },
      { name: "Critical", value: buckets.Critical, color: "hsl(0 72% 51%)" },
    ];

    // Per-vehicle aging trend: interpolate from 100% at in-service date down to
    // current SoH today, sampled monthly on a shared fleet timeline.
    const palette = [
      "hsl(217 91% 60%)", "hsl(142 71% 45%)", "hsl(38 92% 50%)", "hsl(0 72% 51%)",
      "hsl(280 75% 60%)", "hsl(190 80% 45%)", "hsl(25 95% 53%)", "hsl(160 70% 40%)",
      "hsl(330 75% 55%)", "hsl(50 95% 50%)", "hsl(260 70% 60%)", "hsl(120 50% 45%)",
    ];
    const dated = sessions
      .map((s) => ({ s, t: new Date(s.in_service_since).getTime() }))
      .filter((x) => !Number.isNaN(x.t));
    const earliest = dated.length ? Math.min(...dated.map((x) => x.t)) : now;
    const startMonth = new Date(new Date(earliest).getFullYear(), new Date(earliest).getMonth(), 1);
    const endMonth = new Date(new Date(now).getFullYear(), new Date(now).getMonth(), 1);
    const months: { label: string; ts: number }[] = [];
    for (let d = new Date(startMonth); d <= endMonth; d.setMonth(d.getMonth() + 1)) {
      months.push({
        label: `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`,
        ts: d.getTime(),
      });
    }
    const vehicleSeries = dated.map((x, i) => ({
      plate: x.s.plate_number,
      name: x.s.vehicle_name,
      color: palette[i % palette.length],
      start: x.t,
      currentSoh: x.s.current_soh_pct,
    }));
    const agingPerVehicle = months.map((m) => {
      const row: Record<string, number | string> = { label: m.label };
      vehicleSeries.forEach((v) => {
        if (m.ts < v.start) return;
        const total = Math.max(1, now - v.start);
        const ratio = Math.min(1, (m.ts - v.start) / total);
        row[v.plate] = Math.round((100 - (100 - v.currentSoh) * ratio) * 10) / 10;
      });
      return row;
    });

    return {
      active,
      perVehicle,
      fleetCount: sessions.length,
      avgSoh: sohSum / n,
      avgAge: ageSum / n,
      v2gTotal,
      opTotal,
      healthData,
      agingPerVehicle,
      vehicleSeries,
    };
  }, [sessions]);

  const [selectedPlates, setSelectedPlates] = useState<Set<string>>(new Set());
  useEffect(() => {
    setSelectedPlates(new Set(metrics.vehicleSeries.map((v) => v.plate)));
  }, [metrics.vehicleSeries]);
  const toggleVehicle = (plate: string) => {
    setSelectedPlates((prev) => {
      const next = new Set(prev);
      if (next.has(plate)) next.delete(plate);
      else next.add(plate);
      return next;
    });
  };


  // Sort by peak_kw desc for dispatch prioritisation
  const dispatchSorted = useMemo(
    () => [...metrics.perVehicle].sort((a, b) => b.peak_kw - a.peak_kw),
    [metrics.perVehicle],
  );


  return (
    <div className="min-h-screen flex bg-secondary/30">
      <AppSidebar />
      <PageShell title="Battery analytics" description="State of charge, health and degradation insights.">
        <Card className="p-6">
          <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
            <div>
              <h2 className="font-semibold">Fleet battery analytics</h2>
              <p className="text-xs text-muted-foreground">Health and degradation breakdown across the fleet</p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="outline" className="gap-1">
                <FileText className="h-3 w-3" /> CSV · {sessions.length}
              </Badge>
            </div>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="grid gap-3 sm:grid-cols-3 md:grid-cols-1 content-start">
              <Metric
                icon={<Car className="h-4 w-4" />}
                label="Fleet size"
                value={String(metrics.fleetCount)}
                hint="buses"
                accent="primary"
              />
              <Metric
                icon={<Battery className="h-4 w-4" />}
                label="Average SoH"
                value={`${metrics.avgSoh.toFixed(1)}%`}
                hint="health"
                accent="success"
              />
              <Metric
                icon={<Activity className="h-4 w-4" />}
                label="Average fleet age"
                value={metrics.avgAge.toFixed(1)}
                hint="years"
                accent="warning"
              />
            </div>
            <div>
              <h3 className="font-semibold text-sm mb-2">Fleet battery health status</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={metrics.healthData}
                      dataKey="value"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      outerRadius={85}
                      innerRadius={45}
                      label={(e: any) => (e.value > 0 ? `${e.value}` : "")}
                    >
                      {metrics.healthData.map((d) => (
                        <Cell key={d.name} fill={d.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        background: "var(--color-card)",
                        border: "1px solid var(--color-border)",
                        borderRadius: 8,
                      }}
                      formatter={(v: any, n: any) => [`${v} bus${Number(v) === 1 ? "" : "es"}`, n]}
                    />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

        </Card>



        <Card className="mt-6 overflow-hidden">
          <div className="px-4 py-3 border-b border-border">
            <h2 className="font-semibold text-sm">Live session analytics</h2>
            <p className="text-xs text-muted-foreground">
              Fleet health: SoH, estimated remaining capacity and cumulative degradation
            </p>
          </div>
          <div className="max-h-[460px] overflow-y-auto overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted text-foreground text-xs font-bold uppercase tracking-wider sticky top-0 z-10">
                <tr>
                  <th className="text-left px-4 py-2">Vehicle</th>
                  <th className="text-center px-4 py-2">Source</th>
                  <th className="text-left px-4 py-2">In service since</th>
                  <th className="text-right px-4 py-2">Age (yrs)</th>
                  <th className="text-right px-4 py-2">Battery capacity new (kWh)</th>
                  <th className="text-right px-4 py-2">Current SoH (%)</th>
                  <th className="text-right px-4 py-2">Est. current capacity (kWh)</th>
                  <th className="text-right px-4 py-2">Distance travelled (km)</th>
                  <th className="text-right px-4 py-2">Est. V2G degradation (%)</th>
                  <th className="text-right px-4 py-2">Est. operational degradation (%)</th>
                  <th className="text-right px-4 py-2">Total degradation (%)</th>
                  <th className="text-center px-4 py-2">Pack temp (°C)</th>
                  <th className="text-center px-4 py-2">Health</th>

                </tr>
              </thead>
              <tbody>
                {dispatchSorted.map((v) => {
                  const age = ageYears(v.in_service_since);
                  const estCurrentCapacity = (v.current_soh_pct / 100) * v.battery_capacity_kwh;
                  const totalDegradation = v.v2g_degradation_pct + v.operational_degradation_pct;
                  const soh = v.current_soh_pct;
                  const temp = v.temperature_c;
                  // Combine SoH and temperature for health label — sustained high temp
                  // accelerates degradation, so a hot pack downgrades the rating.
                  const tempPenalty = temp >= 45 ? 8 : temp >= 38 ? 4 : 0;
                  const effSoh = soh - tempPenalty;
                  const health =
                    effSoh < 70
                      ? { label: "Critical", cls: "border-destructive/40 text-destructive bg-destructive/10" }
                      : effSoh < 80
                        ? { label: "Need replacement", cls: "border-orange-500/40 text-orange-600 dark:text-orange-400 bg-orange-500/10" }
                        : effSoh < 90
                          ? { label: "Monitor", cls: "border-amber-500/40 text-amber-600 dark:text-amber-400 bg-amber-500/10" }
                          : { label: "Healthy", cls: "border-emerald-500/40 text-emerald-600 dark:text-emerald-400 bg-emerald-500/10" };
                  const tempCls =
                    temp >= 45
                      ? "border-destructive/40 text-destructive bg-destructive/10"
                      : temp >= 38
                        ? "border-orange-500/40 text-orange-600 dark:text-orange-400 bg-orange-500/10"
                        : temp >= 32
                          ? "border-amber-500/40 text-amber-600 dark:text-amber-400 bg-amber-500/10"
                          : "border-emerald-500/40 text-emerald-600 dark:text-emerald-400 bg-emerald-500/10";
                  return (
                    <tr key={v.plate_number} className="border-t border-border">

                      <td className="px-4 py-2">
                        <div className="font-medium">{v.vehicle_name}</div>
                        <div className="text-xs text-muted-foreground">{v.plate_number}</div>
                      </td>
                      <td className="px-4 py-2 text-center">
                        <Badge
                          variant="outline"
                          className={
                            v.source === "API"
                              ? "gap-1 border-primary/40 text-primary"
                              : "gap-1"
                          }
                        >
                          {v.source === "API" ? (
                            <Cloud className="h-3 w-3" />
                          ) : (
                            <FileText className="h-3 w-3" />
                          )}
                          {v.source}
                        </Badge>
                      </td>
                      <td className="px-4 py-2">{v.in_service_since}</td>
                      <td className="px-4 py-2 text-right">{age.toFixed(1)}</td>
                      <td className="px-4 py-2 text-right">{v.battery_capacity_kwh.toLocaleString()}</td>
                      <td className="px-4 py-2 text-right">
                        <Badge
                          variant="outline"
                          className={
                            v.current_soh_pct >= 90
                              ? "border-emerald-500/40 text-emerald-600 dark:text-emerald-400"
                              : v.current_soh_pct >= 85
                                ? "border-amber-500/40 text-amber-600 dark:text-amber-400"
                                : "border-destructive/40 text-destructive"
                          }
                        >
                          {v.current_soh_pct.toFixed(1)}%
                        </Badge>
                      </td>
                      <td className="px-4 py-2 text-right font-medium">
                        {estCurrentCapacity.toFixed(0)} kWh
                      </td>
                      <td className="px-4 py-2 text-right">{v.distance_km.toLocaleString()}</td>
                      <td className="px-4 py-2 text-right">{v.v2g_degradation_pct.toFixed(1)}%</td>
                      <td className="px-4 py-2 text-right">{v.operational_degradation_pct.toFixed(1)}%</td>
                      <td className="px-4 py-2 text-right font-semibold text-destructive">
                        {totalDegradation.toFixed(1)}%
                      </td>
                      <td className="px-4 py-2 text-center">
                        <Badge variant="outline" className={tempCls}>{temp.toFixed(1)}°C</Badge>
                      </td>
                      <td className="px-4 py-2 text-center">
                        <Badge variant="outline" className={health.cls}>{health.label}</Badge>
                      </td>

                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>

      </PageShell>
    </div>
  );
}

function Metric({
  icon,
  label,
  value,
  hint,
  accent,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  hint: string;
  accent: "primary" | "success" | "warning" | "destructive" | "muted";
}) {
  const accentClass =
    accent === "primary"
      ? "bg-primary/10 text-primary"
      : accent === "success"
        ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
        : accent === "warning"
          ? "bg-amber-500/10 text-amber-600 dark:text-amber-400"
          : accent === "destructive"
            ? "bg-destructive/10 text-destructive"
            : "bg-muted text-muted-foreground";
  return (
    <Card className="p-4">
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <span className={`rounded-md p-1.5 ${accentClass}`}>{icon}</span>
        {label}
      </div>
      <div className="mt-2 text-2xl font-semibold">{value}</div>
      <div className="text-xs text-muted-foreground mt-0.5">{hint}</div>
    </Card>
  );
}

function PnlLine({
  label,
  value,
  hint,
  tone,
}: {
  label: string;
  value: string;
  hint: string;
  tone: "positive" | "negative" | "neutral";
}) {
  const toneClass =
    tone === "positive"
      ? "text-emerald-600 dark:text-emerald-400"
      : tone === "negative"
        ? "text-destructive"
        : "text-foreground";
  return (
    <div className="rounded-md border border-border p-3">
      <div className="text-[11px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className={`mt-1 text-lg font-semibold ${toneClass}`}>{value}</div>
      <div className="text-[11px] text-muted-foreground mt-0.5">{hint}</div>
    </div>
  );
}
