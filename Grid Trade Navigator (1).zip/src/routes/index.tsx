import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Zap, TrendingUp, Battery, Bell, ShieldCheck, LineChart } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "VOLT_GRID — Flexibility Operator for Energy & EV Batteries" },
      {
        name: "description",
        content:
          "Buy energy when it's cheap, sell when it's expensive. VOLT_GRID is the B2B platform connecting grid operators and EV battery owners to wholesale electricity markets.",
      },
    ],
  }),
  component: Landing,
});

function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-background/80 backdrop-blur sticky top-0 z-10">
        <div className="container mx-auto flex h-16 items-center justify-between px-6">
          <Link to="/" className="flex items-center gap-2 font-semibold text-lg">
            <span className="inline-flex h-8 w-8 items-center justify-center rounded-md bg-primary text-primary-foreground">
              <Zap className="h-4 w-4" />
            </span>
            VOLT_GRID
          </Link>
          <nav className="hidden md:flex items-center gap-8 text-sm text-muted-foreground">
            <a href="#how">How it works</a>
            <a href="#customers">Who it's for</a>
            <a href="#metrics">Analytics</a>
          </nav>
          <div className="flex items-center gap-2">
            <Link to="/auth">
              <Button variant="ghost" size="sm">
                Sign in
              </Button>
            </Link>
            <Link to="/auth">
              <Button size="sm">Get started</Button>
            </Link>
          </div>
        </div>
      </header>

      <section className="container mx-auto px-6 pt-20 pb-24 text-center">
        <div className="mx-auto max-w-3xl">
          <span className="inline-flex items-center gap-2 rounded-full border border-border bg-secondary px-3 py-1 text-xs font-medium text-secondary-foreground">
            <span className="h-1.5 w-1.5 rounded-full bg-success" /> Live wholesale market
          </span>
          <h1 className="mt-6 text-5xl md:text-6xl font-semibold tracking-tight">
            Buy energy low.
            <br />
            <span className="text-accent">Sell it back high.</span>
          </h1>
          <p className="mt-6 text-lg text-muted-foreground">
            VOLT_GRID is the flexibility operator helping grid operators and EV battery owners arbitrage wholesale
            electricity prices automatically — with analytics, alerts and built-in trading rules.
          </p>
          <div className="mt-8 flex justify-center gap-3">
            <Link to="/auth">
              <Button size="lg">Open the dashboard</Button>
            </Link>
            <a href="#how">
              <Button size="lg" variant="outline">
                How it works
              </Button>
            </a>
          </div>
        </div>
      </section>

      <section id="customers" className="container mx-auto px-6 pb-24">
        <div className="grid gap-6 md:grid-cols-2">
          <Card className="p-8">
            <Zap className="h-8 w-8 text-accent" />
            <h3 className="mt-4 text-2xl font-semibold">Grid Operators</h3>
            <p className="mt-2 text-muted-foreground">
              Buy bulk capacity off-peak from the main grid and sell it back at peak prices. Trades require a minimum of{" "}
              <strong>1 MW</strong> and <strong>43% reserve capacity</strong> — enforced automatically.
            </p>
          </Card>
          <Card className="p-8">
            <Battery className="h-8 w-8 text-success" />
            <h3 className="mt-4 text-2xl font-semibold">EV Battery Owners</h3>
            <p className="mt-2 text-muted-foreground">
              Get notified the moment prices spike, then sell stored battery energy back to the grid in a single tap.
              Monetise your battery while you sleep.
            </p>
          </Card>
        </div>
      </section>

      <section id="how" className="bg-secondary py-24">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-semibold text-center">How VOLT_GRID works</h2>
          <div className="mt-12 grid gap-6 md:grid-cols-3">
            {[
              { icon: LineChart, title: "Track prices", body: "Live €/MWh feed with 24h forecast and demand curves." },
              {
                icon: Bell,
                title: "Get alerts",
                body: "Notifications when prices cross your thresholds — high or low.",
              },
              {
                icon: TrendingUp,
                title: "Auto-trade",
                body: "One-tap buy / sell with built-in profit estimation and rule checks.",
              },
            ].map((s) => (
              <Card key={s.title} className="p-6 bg-card">
                <s.icon className="h-6 w-6 text-accent" />
                <h3 className="mt-3 font-semibold">{s.title}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{s.body}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section id="metrics" className="container mx-auto px-6 py-24">
        <div className="grid gap-6 md:grid-cols-4 text-center">
          {[
            { k: "€/MWh", v: "Live", sub: "Wholesale price" },
            { k: "P&L", v: "Tracked", sub: "Per trade" },
            { k: "MW", v: "1+", sub: "Grid op minimum" },
            { k: "Reserve", v: "43%", sub: "Required to sell" },
          ].map((m) => (
            <Card key={m.sub} className="p-6">
              <div className="text-3xl font-semibold text-primary">{m.v}</div>
              <div className="mt-1 text-xs uppercase tracking-wide text-muted-foreground">{m.k}</div>
              <div className="mt-2 text-sm">{m.sub}</div>
            </Card>
          ))}
        </div>
        <div className="mt-12 text-center">
          <Link to="/auth">
            <Button size="lg">
              <ShieldCheck className="mr-2 h-4 w-4" />
              Start trading
            </Button>
          </Link>
        </div>
      </section>

      <footer className="border-t border-border py-8 text-center text-sm text-muted-foreground">
        © {new Date().getFullYear()} VOLT_GRID — Flexibility Operator
      </footer>
    </div>
  );
}
