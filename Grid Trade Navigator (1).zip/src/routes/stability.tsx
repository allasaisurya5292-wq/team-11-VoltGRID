import { createFileRoute } from "@tanstack/react-router";
import { useMemo } from "react";
import { AppSidebar } from "@/components/AppSidebar";
import { PageShell } from "@/components/PageShell";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Activity, Zap, Gauge, ShieldCheck } from "lucide-react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
} from "recharts";

export const Route = createFileRoute("/stability")({
  head: () => ({ meta: [{ title: "Grid stability — VOLT_GRID" }] }),
  component: StabilityPage,
});

const NOMINAL_HZ = 50;
const NOMINAL_KV = 400;

function StabilityPage() {
  const series = useMemo(() => {
    // Deterministic synthetic 24h grid telemetry (SSR-safe)
    const rows: { t: string; freq: number; voltage: number; load: number }[] = [];
    for (let h = 0; h < 24; h++) {
      const drift = Math.sin((h / 24) * Math.PI * 2) * 0.06;
      const noise = Math.sin(h * 1.7) * 0.02;
      rows.push({
        t: `${String(h).padStart(2, "0")}:00`,
        freq: +(NOMINAL_HZ + drift + noise).toFixed(3),
        voltage: +(NOMINAL_KV + drift * 80 + noise * 40).toFixed(1),
        load: Math.round(1800 + Math.sin((h / 24) * Math.PI * 2) * 600 + Math.cos(h * 0.9) * 80),
      });
    }
    return rows;
  }, []);

  const current = series[series.length - 1];
  const reserveMw = 420;

  return (
    <div className="min-h-screen flex bg-secondary/30">
      <AppSidebar />
      <PageShell
        title="Grid stability"
        description="Frequency, voltage and reserve telemetry across the operating region."
      >
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Metric
            icon={<Activity className="h-4 w-4" />}
            label="Frequency"
            value={`${current.freq.toFixed(3)} Hz`}
            hint={`Nominal ${NOMINAL_HZ} Hz`}
            accent="primary"
          />
          <Metric
            icon={<Zap className="h-4 w-4" />}
            label="Voltage"
            value={`${current.voltage.toFixed(1)} kV`}
            hint={`Nominal ${NOMINAL_KV} kV`}
            accent="success"
          />
          <Metric
            icon={<Gauge className="h-4 w-4" />}
            label="System load"
            value={`${current.load.toLocaleString()} MW`}
            hint="Last reading"
            accent="warning"
          />
          <Metric
            icon={<ShieldCheck className="h-4 w-4" />}
            label="Reserve"
            value={`${reserveMw} MW`}
            hint="Spinning + V2G"
            accent="muted"
          />
        </div>

        <Card className="mt-6 p-5">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="font-semibold">Frequency (24h)</h2>
              <p className="text-xs text-muted-foreground">
                Acceptable band: {NOMINAL_HZ - 0.2} – {NOMINAL_HZ + 0.2} Hz
              </p>
            </div>
            <Badge variant="outline" className="border-emerald-500/40 text-emerald-600 dark:text-emerald-400">
              Stable
            </Badge>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={series} margin={{ top: 10, right: 16, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis dataKey="t" tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }} />
                <YAxis
                  domain={[49.7, 50.3]}
                  tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }}
                />
                <Tooltip
                  contentStyle={{
                    background: "var(--color-card)",
                    border: "1px solid var(--color-border)",
                    borderRadius: 8,
                  }}
                  formatter={(v: any) => [`${Number(v).toFixed(3)} Hz`, "Frequency"]}
                />
                <ReferenceLine y={NOMINAL_HZ} stroke="var(--color-muted-foreground)" strokeDasharray="4 4" />
                <Line type="monotone" dataKey="freq" stroke="var(--color-primary)" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="mt-6 p-5">
          <div className="mb-3">
            <h2 className="font-semibold">System load (24h)</h2>
            <p className="text-xs text-muted-foreground">Aggregate demand in MW</p>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={series} margin={{ top: 10, right: 16, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis dataKey="t" tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }} />
                <YAxis tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }} />
                <Tooltip
                  contentStyle={{
                    background: "var(--color-card)",
                    border: "1px solid var(--color-border)",
                    borderRadius: 8,
                  }}
                  formatter={(v: any) => [`${Number(v).toLocaleString()} MW`, "Load"]}
                />
                <Line type="monotone" dataKey="load" stroke="var(--color-destructive)" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </PageShell>
    </div>
  );
}

function Metric({
  icon,
  label,
  value,
  hint,
  accent,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  hint: string;
  accent: "primary" | "success" | "warning" | "destructive" | "muted";
}) {
  const accentClass =
    accent === "primary"
      ? "bg-primary/10 text-primary"
      : accent === "success"
        ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
        : accent === "warning"
          ? "bg-amber-500/10 text-amber-600 dark:text-amber-400"
          : accent === "destructive"
            ? "bg-destructive/10 text-destructive"
            : "bg-muted text-muted-foreground";
  return (
    <Card className="p-4">
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <span className={`rounded-md p-1.5 ${accentClass}`}>{icon}</span>
        {label}
      </div>
      <div className="mt-2 text-2xl font-semibold">{value}</div>
      <div className="text-xs text-muted-foreground mt-0.5">{hint}</div>
    </Card>
  );
}
