import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { AppSidebar } from "@/components/AppSidebar";
import { PageShell } from "@/components/PageShell";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceDot,
  ReferenceLine,
  Legend,
  Area,
  ComposedChart,
} from "recharts";
import { ArrowLeft, TrendingDown, TrendingUp, Activity, Sparkles, Cpu, Target } from "lucide-react";
import { trainGBRT, predictGBRT, metrics, type GBRTModel } from "@/lib/ml/gbrt";

export const Route = createFileRoute("/prediction")({
  head: () => ({ meta: [{ title: "Prediction algorithm — VOLT_GRID" }] }),
  component: PredictionPage,
});

// =============================================================
// Algorithm: Gradient Boosted Regression Trees (GBRT)
// Inputs (engineered per hour):
//   - hour-of-day (0..23) + sin/cos hour cycle
//   - day-of-week (0..6) + sin/cos weekly cycle
//   - sin/cos monthly cycle
//   - lag-1h, lag-24h, lag-168h
//   - rolling mean 24h, rolling std 24h
// Training: 60 days of historical hourly prices (simulated via an
// AR(1) process driven by diurnal + weekly seasonality + noise).
// Backtest: walk-forward on the last 7 days (no leakage).
// Forecast: recursive 30-day rollout, using model's own predictions
// as future lags. Uncertainty band from backtest residual stdev,
// scaled with forecast horizon (sqrt rule, like ARIMA prediction intervals).
// =============================================================

const HOURS_PER_DAY = 24;
const HISTORY_DAYS = 60;
const FORECAST_DAYS = 30;
const BACKTEST_DAYS = 7;
const N_FEATURES = 11;
const FEATURE_NAMES = [
  "hour",
  "sin(hour)",
  "cos(hour)",
  "day-of-week",
  "sin(week)",
  "cos(week)",
  "sin(month)",
  "cos(month)",
  "lag-1h",
  "lag-24h",
  "roll-mean-24h",
];

// ------------------ Synthetic but realistic history -----------------
function diurnal(hour: number): number {
  const morning = 70 * Math.exp(-((hour - 8) ** 2) / 5);
  const evening = 130 * Math.exp(-((hour - 19) ** 2) / 6);
  const baseline = 45 + 12 * Math.sin((hour / 24) * Math.PI * 2);
  return Math.max(15, baseline + morning + evening);
}

function buildHistory(seed: number): { ts: number; price: number }[] {
  let s = seed * 7919 + 1;
  const rand = () => {
    s = (s * 9301 + 49297) % 233280;
    return s / 233280;
  };
  const noise = () => (rand() - 0.5) * 2;

  const start = new Date();
  start.setMinutes(0, 0, 0);
  start.setHours(start.getHours() - HISTORY_DAYS * HOURS_PER_DAY);

  const out: { ts: number; price: number }[] = [];
  let prev = diurnal(start.getHours());
  for (let i = 0; i < HISTORY_DAYS * HOURS_PER_DAY; i++) {
    const t = new Date(start.getTime() + i * 3600 * 1000);
    const hour = t.getHours();
    const dow = t.getDay();
    const weekend = dow === 0 || dow === 6 ? -8 : 0;
    const monthly = 18 * Math.sin((i / (24 * 30)) * Math.PI * 2);
    const target = diurnal(hour) + weekend + monthly;
    // AR(1) — current depends 35% on previous
    const v = 0.35 * prev + 0.65 * target + noise() * 9;
    prev = v;
    out.push({ ts: t.getTime(), price: Math.max(8, +v.toFixed(2)) });
  }
  return out;
}

function makeFeatures(ts: number, lag1: number, lag24: number, roll24: number): number[] {
  const d = new Date(ts);
  const hour = d.getHours();
  const dow = d.getDay();
  const dayIdx = Math.floor(ts / (24 * 3600 * 1000));
  return [
    hour,
    Math.sin((hour / 24) * Math.PI * 2),
    Math.cos((hour / 24) * Math.PI * 2),
    dow,
    Math.sin((dow / 7) * Math.PI * 2),
    Math.cos((dow / 7) * Math.PI * 2),
    Math.sin((dayIdx / 30) * Math.PI * 2),
    Math.cos((dayIdx / 30) * Math.PI * 2),
    lag1,
    lag24,
    roll24,
  ];
}

function buildTrainingMatrix(history: { ts: number; price: number }[]) {
  const X: number[][] = [];
  const y: number[] = [];
  const tsOut: number[] = [];
  for (let i = 168; i < history.length; i++) {
    const lag1 = history[i - 1].price;
    const lag24 = history[i - 24].price;
    let roll = 0;
    for (let k = i - 24; k < i; k++) roll += history[k].price;
    roll /= 24;
    X.push(makeFeatures(history[i].ts, lag1, lag24, roll));
    y.push(history[i].price);
    tsOut.push(history[i].ts);
  }
  return { X, y, ts: tsOut };
}

type Pt = {
  ts: number;
  iso: string;
  label: string;
  day: number;
  hour: number;
  price: number;
  upper: number;
  lower: number;
};

function forecastForward(
  model: GBRTModel,
  history: { ts: number; price: number }[],
  hours: number,
  residualStd: number,
): Pt[] {
  // Maintain rolling buffer of last 24h of prices for lag features
  const buf = history.slice(-168).map((h) => h.price);
  const out: Pt[] = [];
  let cursor = history[history.length - 1].ts + 3600 * 1000;
  const firstTs = cursor;

  for (let i = 0; i < hours; i++) {
    const lag1 = buf[buf.length - 1];
    const lag24 = buf[buf.length - 24];
    let roll = 0;
    for (let k = buf.length - 24; k < buf.length; k++) roll += buf[k];
    roll /= 24;

    const x = makeFeatures(cursor, lag1, lag24, roll);
    const price = Math.max(8, +predictGBRT(model, x).toFixed(2));
    buf.push(price);
    if (buf.length > 200) buf.shift();

    // Interval grows ~ sqrt(horizon) — standard for autoregressive forecasts
    const horizonH = (cursor - firstTs) / (3600 * 1000) + 1;
    const band = residualStd * (1.96 * Math.sqrt(Math.min(horizonH / 24, 14)));
    const d = new Date(cursor);
    const dayIdx = Math.floor((cursor - firstTs) / (24 * 3600 * 1000));
    out.push({
      ts: cursor,
      iso: d.toISOString(),
      label: `${d.toLocaleDateString(undefined, { month: "short", day: "numeric" })} ${String(d.getHours()).padStart(2, "0")}:00`,
      day: dayIdx,
      hour: d.getHours(),
      price,
      upper: +(price + band).toFixed(2),
      lower: +Math.max(8, price - band).toFixed(2),
    });
    cursor += 3600 * 1000;
  }
  return out;
}

type View = "24h" | "7d" | "30d";
const REFRESH_MS = 30_000;

function PredictionPage() {
  const [view, setView] = useState<View>("7d");
  const [runId, setRunId] = useState(0);
  const [runAt, setRunAt] = useState<number | null>(null);
  const [autoRefresh, setAutoRefresh] = useState(true);

  useEffect(() => {
    setRunAt(Date.now());
  }, []);

  useEffect(() => {
    if (!autoRefresh) return;
    const id = setInterval(() => {
      setRunId((r) => r + 1);
      setRunAt(Date.now());
    }, REFRESH_MS);
    return () => clearInterval(id);
  }, [autoRefresh]);

  // -------- TRAIN GBRT, BACKTEST, FORECAST --------
  const model = useMemo(() => {
    const history = buildHistory(runId);
    const { X, y, ts } = buildTrainingMatrix(history);

    // Walk-forward backtest: train on all-but-last-7d, test on last 7d
    const splitAt = X.length - BACKTEST_DAYS * HOURS_PER_DAY;
    const Xtrain = X.slice(0, splitAt);
    const ytrain = y.slice(0, splitAt);
    const Xtest = X.slice(splitAt);
    const ytest = y.slice(splitAt);
    const tsTest = ts.slice(splitAt);

    const backtestModel = trainGBRT(Xtrain, ytrain, { nTrees: 80, maxDepth: 3, lr: 0.08 });
    const yhat = Xtest.map((x) => predictGBRT(backtestModel, x));
    const m = metrics(ytest, yhat);
    const residuals = ytest.map((v, i) => v - yhat[i]);
    const residStd = Math.sqrt(residuals.reduce((s, r) => s + r * r, 0) / residuals.length);

    // Final model: refit on full data, then forecast
    const finalModel = trainGBRT(X, y, { nTrees: 80, maxDepth: 3, lr: 0.08 });
    const forecast = forecastForward(
      finalModel,
      history,
      FORECAST_DAYS * HOURS_PER_DAY,
      residStd,
    );

    const backtest = tsTest.map((tsi, i) => ({
      ts: tsi,
      label: new Date(tsi).toLocaleString(undefined, {
        month: "short",
        day: "numeric",
        hour: "2-digit",
      }),
      actual: +ytest[i].toFixed(2),
      predicted: +yhat[i].toFixed(2),
    }));

    return { history, forecast, backtest, accuracy: m, residStd, finalModel };
  }, [runId]);

  const slice = useMemo(() => {
    const hours = view === "24h" ? 24 : view === "7d" ? 24 * 7 : model.forecast.length;
    return model.forecast.slice(0, hours);
  }, [model, view]);

  const bestBuyPerDay = useMemo(() => {
    const byDay = new Map<number, Pt>();
    for (const p of slice) {
      const cur = byDay.get(p.day);
      if (!cur || p.price < cur.price) byDay.set(p.day, p);
    }
    return [...byDay.values()].sort((a, b) => a.ts - b.ts);
  }, [slice]);

  const peakPerDay = useMemo(() => {
    const byDay = new Map<number, Pt>();
    for (const p of slice) {
      const cur = byDay.get(p.day);
      if (!cur || p.price > cur.price) byDay.set(p.day, p);
    }
    return [...byDay.values()].sort((a, b) => a.ts - b.ts);
  }, [slice]);

  const globalBest = useMemo(
    () => slice.reduce<Pt | null>((m, p) => (!m || p.price < m.price ? p : m), null),
    [slice],
  );
  const globalPeak = useMemo(
    () => slice.reduce<Pt | null>((m, p) => (!m || p.price > m.price ? p : m), null),
    [slice],
  );
  const avg = useMemo(
    () => (slice.length ? Math.round(slice.reduce((s, p) => s + p.price, 0) / slice.length) : 0),
    [slice],
  );

  const currentForecast = slice[0];

  // Feature importance ranked
  const importances = useMemo(() => {
    return model.finalModel.importance
      .map((v, i) => ({ name: FEATURE_NAMES[i], value: v }))
      .sort((a, b) => b.value - a.value);
  }, [model]);

  return (
    <div className="min-h-screen flex bg-secondary/30">
      <AppSidebar />
      <PageShell
        title="Prediction algorithm"
        description="Gradient Boosted Regression Trees trained on 60 days of hourly history, backtested walk-forward, then rolled forward 30 days."
      >
        <div className="flex justify-end mb-3">
          <Button variant="outline" size="sm" asChild>
            <Link to="/dashboard">
              <ArrowLeft className="h-4 w-4 mr-1" /> Back to overview
            </Link>
          </Button>
        </div>

        <div className="grid gap-4 md:grid-cols-4">
          <Metric
            icon={<Activity className="h-4 w-4" />}
            label="Forecast now"
            value={currentForecast ? `€${currentForecast.price.toFixed(0)}` : "—"}
            hint="/MWh"
            accent="primary"
          />
          <Metric
            icon={<Sparkles className="h-4 w-4" />}
            label="Window average"
            value={`€${avg}`}
            hint="/MWh"
            accent="muted"
          />
          <Metric
            icon={<TrendingDown className="h-4 w-4" />}
            label="Best time to BUY"
            value={globalBest ? `€${globalBest.price.toFixed(0)}` : "—"}
            hint={globalBest ? globalBest.label : "—"}
            accent="success"
          />
          <Metric
            icon={<TrendingUp className="h-4 w-4" />}
            label="Best time to SELL"
            value={globalPeak ? `€${globalPeak.price.toFixed(0)}` : "—"}
            hint={globalPeak ? globalPeak.label : "—"}
            accent="destructive"
          />
        </div>

        {/* Model card */}
        <Card className="mt-6 p-5">
          <div className="flex items-start justify-between gap-3 flex-wrap">
            <div>
              <div className="flex items-center gap-2 text-xs text-muted-foreground uppercase tracking-wider">
                <Cpu className="h-3.5 w-3.5" /> Model
              </div>
              <h2 className="font-semibold mt-1">Gradient Boosted Regression Trees</h2>
              <p className="text-xs text-muted-foreground mt-0.5">
                {model.finalModel.hp.nTrees} trees · depth {model.finalModel.hp.maxDepth} · lr{" "}
                {model.finalModel.hp.lr} · subsample {model.finalModel.hp.subsample} ·{" "}
                {N_FEATURES} engineered features
              </p>
            </div>
            <Badge variant="outline" className="border-emerald-500/40 text-emerald-600 dark:text-emerald-400">
              <Target className="h-3 w-3 mr-1" /> R² {(model.accuracy.r2 * 100).toFixed(1)}%
            </Badge>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4">
            <MiniStat label="MAE" value={`€${model.accuracy.mae.toFixed(2)}`} hint="/MWh" />
            <MiniStat label="RMSE" value={`€${model.accuracy.rmse.toFixed(2)}`} hint="/MWh" />
            <MiniStat label="MAPE" value={`${model.accuracy.mape.toFixed(2)}%`} hint="avg error" />
            <MiniStat label="R²" value={model.accuracy.r2.toFixed(3)} hint="fit quality" />
          </div>

          <div className="mt-5 grid lg:grid-cols-2 gap-5">
            {/* Backtest chart */}
            <div>
              <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">
                Walk-forward backtest · last {BACKTEST_DAYS} days
              </h3>
              <div className="h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={model.backtest} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                    <XAxis dataKey="label" tick={{ fontSize: 9, fill: "var(--color-muted-foreground)" }} minTickGap={32} />
                    <YAxis tick={{ fontSize: 10, fill: "var(--color-muted-foreground)" }} domain={["dataMin - 5", "dataMax + 5"]} />
                    <Tooltip
                      contentStyle={{ background: "var(--color-card)", border: "1px solid var(--color-border)", borderRadius: 8 }}
                      formatter={(v: any, name: string) => [`€${(+v).toFixed(1)}`, name]}
                    />
                    <Legend wrapperStyle={{ fontSize: 11 }} />
                    <Line type="monotone" dataKey="actual" name="Actual" stroke="hsl(217 91% 60%)" strokeWidth={2} dot={false} isAnimationActive={false} />
                    <Line type="monotone" dataKey="predicted" name="GBRT prediction" stroke="hsl(142 71% 45%)" strokeWidth={2} strokeDasharray="4 3" dot={false} isAnimationActive={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Feature importance */}
            <div>
              <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">
                Feature importance (gain)
              </h3>
              <ul className="space-y-1.5">
                {importances.map((f) => (
                  <li key={f.name} className="flex items-center gap-2 text-xs">
                    <span className="w-28 truncate text-muted-foreground">{f.name}</span>
                    <span className="flex-1 h-2 bg-muted rounded overflow-hidden">
                      <span
                        className="block h-full bg-primary"
                        style={{ width: `${Math.max(2, f.value * 100)}%` }}
                      />
                    </span>
                    <span className="tabular-nums w-12 text-right">{(f.value * 100).toFixed(1)}%</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </Card>

        {/* Forecast chart */}
        <Card className="mt-6 p-5">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
            <div>
              <h2 className="font-semibold">Price forecast (€/MWh)</h2>
              <p className="text-xs text-muted-foreground">
                Forecast run #{runId} · {slice.length} hourly points · model{" "}
                {model.finalModel.trees.length} trees ·{" "}
                {runAt
                  ? `published ${new Date(runAt).toLocaleTimeString([], { hour12: false })}`
                  : "loading…"}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant={autoRefresh ? "default" : "outline"}
                size="sm"
                onClick={() => setAutoRefresh((v) => !v)}
              >
                {autoRefresh ? "Auto-refresh on" : "Auto-refresh off"}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  setRunId((r) => r + 1);
                  setRunAt(Date.now());
                }}
              >
                Retrain & forecast
              </Button>
              <Tabs value={view} onValueChange={(v) => setView(v as View)}>
                <TabsList>
                  <TabsTrigger value="24h">24h</TabsTrigger>
                  <TabsTrigger value="7d">7 days</TabsTrigger>
                  <TabsTrigger value="30d">30 days</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
          </div>
          <div className="h-96">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={slice} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="bandFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="hsl(217 91% 60%)" stopOpacity={0.25} />
                    <stop offset="100%" stopColor="hsl(217 91% 60%)" stopOpacity={0.02} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis dataKey="label" tick={{ fontSize: 10, fill: "var(--color-muted-foreground)" }} minTickGap={48} />
                <YAxis tick={{ fontSize: 11, fill: "var(--color-muted-foreground)" }} domain={["dataMin - 10", "dataMax + 10"]} />
                <Tooltip
                  contentStyle={{ background: "var(--color-card)", border: "1px solid var(--color-border)", borderRadius: 8 }}
                  formatter={(v: any, name: string) => [`€${(+v).toFixed(1)}`, name]}
                />
                <Legend />
                <Area type="monotone" dataKey="upper" stroke="transparent" fill="url(#bandFill)" name="95% interval" isAnimationActive={false} />
                <Area type="monotone" dataKey="lower" stroke="transparent" fill="var(--color-card)" isAnimationActive={false} legendType="none" />
                <ReferenceLine y={avg} stroke="var(--color-muted-foreground)" strokeDasharray="3 3" />
                <Line type="monotone" dataKey="price" name="GBRT forecast" stroke="hsl(217 91% 60%)" strokeWidth={2} dot={false} isAnimationActive={false} />
                {bestBuyPerDay.map((p) => (
                  <ReferenceDot key={`buy-${p.ts}`} x={p.label} y={p.price} r={5} fill="hsl(142 71% 45%)" stroke="white" strokeWidth={1.5} ifOverflow="extendDomain" />
                ))}
                {peakPerDay.map((p) => (
                  <ReferenceDot key={`sell-${p.ts}`} x={p.label} y={p.price} r={4} fill="hsl(0 84% 60%)" stroke="white" strokeWidth={1.5} ifOverflow="extendDomain" />
                ))}
              </ComposedChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-wrap items-center gap-4 mt-3 text-xs text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-full bg-emerald-500" /> Daily best-buy
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-full bg-red-500" /> Daily peak (sell)
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-full bg-blue-500/30 border border-blue-500/50" />
              95% prediction interval (grows with horizon)
            </span>
          </div>
        </Card>

        <Card className="mt-6 overflow-hidden">
          <div className="px-4 py-3 border-b border-border">
            <h2 className="font-semibold text-sm">
              Daily best buy windows — next {bestBuyPerDay.length} days
            </h2>
            <p className="text-xs text-muted-foreground">
              Cheapest forecasted hour per day, derived from the GBRT rollout.
            </p>
          </div>
          <div className="max-h-[420px] overflow-y-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted text-xs font-bold uppercase tracking-wider sticky top-0 z-10">
                <tr>
                  <th className="text-left px-4 py-2">Day</th>
                  <th className="text-left px-4 py-2">Best buy time</th>
                  <th className="text-right px-4 py-2">Price</th>
                  <th className="text-left px-4 py-2">Peak time</th>
                  <th className="text-right px-4 py-2">Peak price</th>
                  <th className="text-right px-4 py-2">Spread</th>
                  <th className="text-center px-4 py-2">Signal</th>
                </tr>
              </thead>
              <tbody>
                {bestBuyPerDay.map((b, i) => {
                  const p = peakPerDay[i];
                  const spread = p ? p.price - b.price : 0;
                  const date = new Date(b.ts);
                  const sig = spread > 80 ? "Strong" : spread > 40 ? "Good" : "Weak";
                  return (
                    <tr key={b.ts} className="border-t border-border hover:bg-muted/30">
                      <td className="px-4 py-2 font-medium">
                        {date.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" })}
                      </td>
                      <td className="px-4 py-2">{String(b.hour).padStart(2, "0")}:00</td>
                      <td className="px-4 py-2 text-right text-emerald-600 dark:text-emerald-400 font-semibold">
                        €{b.price.toFixed(0)}
                      </td>
                      <td className="px-4 py-2">{p ? `${String(p.hour).padStart(2, "0")}:00` : "—"}</td>
                      <td className="px-4 py-2 text-right text-red-600 dark:text-red-400 font-semibold">
                        {p ? `€${p.price.toFixed(0)}` : "—"}
                      </td>
                      <td className="px-4 py-2 text-right">€{spread.toFixed(0)}</td>
                      <td className="px-4 py-2 text-center">
                        <Badge
                          variant="outline"
                          className={
                            sig === "Strong"
                              ? "border-emerald-500/40 text-emerald-600 dark:text-emerald-400"
                              : sig === "Good"
                                ? "border-blue-500/40 text-blue-600 dark:text-blue-400"
                                : "border-muted-foreground/40 text-muted-foreground"
                          }
                        >
                          {sig}
                        </Badge>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </Card>
      </PageShell>
    </div>
  );
}

function Metric({
  icon,
  label,
  value,
  hint,
  accent,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  hint: string;
  accent: "primary" | "success" | "warning" | "destructive" | "muted";
}) {
  const accentClass =
    accent === "primary"
      ? "bg-primary/10 text-primary"
      : accent === "success"
        ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400"
        : accent === "warning"
          ? "bg-amber-500/10 text-amber-600 dark:text-amber-400"
          : accent === "destructive"
            ? "bg-destructive/10 text-destructive"
            : "bg-muted text-muted-foreground";
  return (
    <Card className="p-4">
      <div className="flex items-center gap-2 text-xs text-muted-foreground">
        <span className={`rounded-md p-1.5 ${accentClass}`}>{icon}</span>
        {label}
      </div>
      <div className="mt-2 text-2xl font-semibold">{value}</div>
      <div className="text-xs text-muted-foreground mt-0.5">{hint}</div>
    </Card>
  );
}

function MiniStat({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <div className="rounded-md border border-border bg-card p-3">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="text-lg font-semibold mt-0.5">{value}</div>
      <div className="text-[10px] text-muted-foreground">{hint}</div>
    </div>
  );
}
