// Simulated wholesale electricity market (€/MWh) — replace with CSV data when available.
// Generates a realistic 24h price curve with morning/evening peaks.

export interface PricePoint {
  time: string; // HH:mm
  hour: number;
  price: number; // €/MWh
  demand: number; // GW
}

function basePrice(hour: number): number {
  // Two peaks: morning 7-9 (~180), evening 18-21 (~220), trough overnight (~25)
  const morning = 90 * Math.exp(-((hour - 8) ** 2) / 4);
  const evening = 150 * Math.exp(-((hour - 19) ** 2) / 5);
  const baseline = 45 + 15 * Math.sin((hour / 24) * Math.PI * 2);
  return Math.max(15, baseline + morning + evening);
}

// Deterministic seed derived from calendar date so each day differs
// but the same day always reproduces the same curve.
export function todaySeed(d: Date = new Date()): number {
  return d.getFullYear() * 10000 + (d.getMonth() + 1) * 100 + d.getDate();
}

export function generateDayCurve(extraSeed = 0, date: Date = new Date()): PricePoint[] {
  const seed = todaySeed(date) + extraSeed;
  const pts: PricePoint[] = [];
  for (let h = 0; h < 24; h++) {
    const noise = ((Math.sin(h * 1.3 + seed) + Math.cos(h * 0.7 + seed * 2)) * 8);
    const price = Math.round(basePrice(h) + noise);
    const demand = +(35 + (price / 250) * 25 + Math.sin(h) * 2).toFixed(1);
    pts.push({
      time: `${String(h).padStart(2, "0")}:00`,
      hour: h,
      price,
      demand,
    });
  }
  return pts;
}

// Live, sub-hour-precision price for "right now". Interpolates between the
// current hour and the next hour using the minute/second of the wall clock,
// adds a small micro-jitter so the value visibly ticks each second, and
// returns a timestamped point.
export interface LivePricePoint extends PricePoint {
  timestamp: Date;
  iso: string;
}

export function livePrice(pts: PricePoint[], now: Date = new Date()): LivePricePoint {
  const h = now.getHours();
  const m = now.getMinutes();
  const s = now.getSeconds();
  const frac = (m * 60 + s) / 3600;
  const cur = pts[h]?.price ?? 0;
  const nxt = pts[(h + 1) % 24]?.price ?? cur;
  const interpolated = cur + (nxt - cur) * frac;
  // ±0.6 €/MWh micro-jitter, deterministic per second
  const jitter = Math.sin(todaySeed(now) + h * 60 + m + s * 0.137) * 0.6;
  const price = Math.max(1, +(interpolated + jitter).toFixed(2));
  const demand = +(35 + (price / 250) * 25 + Math.sin(h + frac) * 2).toFixed(1);
  return {
    time: `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`,
    hour: h,
    price,
    demand,
    timestamp: now,
    iso: now.toISOString(),
  };
}

// Backwards-compatible: returns the live, time-precise current price.
export function currentPrice(pts: PricePoint[]): PricePoint {
  return livePrice(pts);
}

export interface Recommendation {
  action: "BUY" | "SELL" | "HOLD";
  reason: string;
  confidence: number; // 0-100
  expectedProfitPerMWh: number;
}

export function getRecommendation(pts: PricePoint[]): Recommendation {
  const now = currentPrice(pts);
  const min = Math.min(...pts.map((p) => p.price));
  const max = Math.max(...pts.map((p) => p.price));
  const range = max - min;
  const position = (now.price - min) / range; // 0=cheap, 1=expensive

  if (position < 0.25) {
    return {
      action: "BUY",
      reason: `Price ${now.price} €/MWh is in the bottom quartile. Charge batteries / buy from grid now.`,
      confidence: Math.round((1 - position) * 100),
      expectedProfitPerMWh: Math.round(max - now.price),
    };
  }
  if (position > 0.75) {
    return {
      action: "SELL",
      reason: `Price ${now.price} €/MWh is in the top quartile. Discharge & sell back to the grid.`,
      confidence: Math.round(position * 100),
      expectedProfitPerMWh: Math.round(now.price - min),
    };
  }
  return {
    action: "HOLD",
    reason: `Price ${now.price} €/MWh is mid-range. Wait for a better entry.`,
    confidence: 55,
    expectedProfitPerMWh: Math.round(range * 0.4),
  };
}

// Trading rule for grid operators: must be strictly greater than 1 MW and 43% capacity to sell back.
export const GRID_MIN_MW = 1;
export const GRID_MIN_CAPACITY_PCT = 43;

export function canGridOperatorSell(mw: number, capacityPct: number) {
  if (mw <= GRID_MIN_MW) return { ok: false, reason: `More than ${GRID_MIN_MW} MW required.` };
  if (capacityPct < GRID_MIN_CAPACITY_PCT)
    return { ok: false, reason: `Reserve capacity must be ≥ ${GRID_MIN_CAPACITY_PCT}%.` };
  return { ok: true, reason: "Trade meets VOLT_GRID grid-operator thresholds." };
}

function dayPrice(dayIndex: number, hour: number): number {
  const seasonal = 30 * Math.sin((dayIndex / 365) * Math.PI * 2);
  const weekly = 10 * Math.sin((dayIndex / 7) * Math.PI * 2);
  const noise = (Math.sin(dayIndex * 2.13 + hour) + Math.cos(dayIndex * 0.91)) * 12;
  return Math.max(15, basePrice(hour) + seasonal + weekly + noise);
}

export interface RangePoint {
  label: string;
  date: string;
  price: number;
}

export type Granularity = "weekly" | "monthly" | "yearly";

function dayDiff(a: Date, b: Date) {
  const ms = 24 * 60 * 60 * 1000;
  return Math.floor(
    (Date.UTC(b.getFullYear(), b.getMonth(), b.getDate()) -
      Date.UTC(a.getFullYear(), a.getMonth(), a.getDate())) / ms,
  );
}

function dailyAverage(dayIndex: number): number {
  let s = 0;
  for (let h = 0; h < 24; h++) s += dayPrice(dayIndex, h);
  return s / 24;
}

export function generateRange(from: Date, to: Date, granularity: Granularity): RangePoint[] {
  const epoch = new Date(2020, 0, 1);
  const totalDays = Math.max(1, dayDiff(from, to) + 1);
  const out: RangePoint[] = [];

  if (granularity === "weekly" && totalDays <= 14) {
    for (let d = 0; d < totalDays; d++) {
      for (let h = 0; h < 24; h++) {
        const date = new Date(from);
        date.setDate(date.getDate() + d);
        date.setHours(h, 0, 0, 0);
        const idx = dayDiff(epoch, date);
        out.push({
          label: `${date.toLocaleDateString(undefined, { weekday: "short" })} ${String(h).padStart(2, "0")}h`,
          date: date.toISOString(),
          price: Math.round(dayPrice(idx, h)),
        });
      }
    }
  } else if (granularity === "yearly") {
    const months = new Map<string, { sum: number; n: number; date: Date }>();
    for (let d = 0; d < totalDays; d++) {
      const date = new Date(from);
      date.setDate(date.getDate() + d);
      const key = `${date.getFullYear()}-${date.getMonth()}`;
      const idx = dayDiff(epoch, date);
      const entry = months.get(key) ?? { sum: 0, n: 0, date: new Date(date.getFullYear(), date.getMonth(), 1) };
      entry.sum += dailyAverage(idx);
      entry.n += 1;
      months.set(key, entry);
    }
    for (const [, v] of months) {
      out.push({
        label: v.date.toLocaleDateString(undefined, { month: "short", year: "2-digit" }),
        date: v.date.toISOString(),
        price: Math.round(v.sum / v.n),
      });
    }
  } else {
    for (let d = 0; d < totalDays; d++) {
      const date = new Date(from);
      date.setDate(date.getDate() + d);
      const idx = dayDiff(epoch, date);
      out.push({
        label: date.toLocaleDateString(undefined, { month: "short", day: "numeric" }),
        date: date.toISOString(),
        price: Math.round(dailyAverage(idx)),
      });
    }
  }
  return out;
}

