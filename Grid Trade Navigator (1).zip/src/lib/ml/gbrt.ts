// Gradient Boosted Regression Trees (CART stumps with MSE loss).
// Pure-TS implementation — runs in the browser in <2s on ~1500 samples.
// This is the same family of algorithm used by XGBoost / LightGBM / CatBoost
// and is the de-facto best choice for tabular time-series regression.

export type TreeNode =
  | { leaf: number }
  | { featIdx: number; threshold: number; left: TreeNode; right: TreeNode; gain: number };

function mean(arr: number[]): number {
  if (arr.length === 0) return 0;
  let s = 0;
  for (const v of arr) s += v;
  return s / arr.length;
}

function variance(arr: number[]): number {
  if (arr.length === 0) return 0;
  const m = mean(arr);
  let s = 0;
  for (const v of arr) s += (v - m) * (v - m);
  return s / arr.length;
}

function buildTree(
  X: number[][],
  y: number[],
  depth: number,
  maxDepth: number,
  minSamples: number,
  importance: number[],
): TreeNode {
  const leafValue = mean(y);
  if (depth >= maxDepth || y.length <= minSamples) return { leaf: leafValue };

  const baseVar = variance(y);
  const nFeats = X[0].length;
  let bestGain = 1e-8;
  let bestFeat = -1;
  let bestThr = 0;
  let bestLeftIdx: number[] = [];
  let bestRightIdx: number[] = [];

  for (let f = 0; f < nFeats; f++) {
    // Use quantile thresholds for speed (9 candidates per feature)
    const col = X.map((r) => r[f]).sort((a, b) => a - b);
    const seen = new Set<number>();
    for (let q = 1; q < 10; q++) {
      const thr = col[Math.floor((col.length * q) / 10)];
      if (seen.has(thr)) continue;
      seen.add(thr);
      const li: number[] = [];
      const ri: number[] = [];
      for (let i = 0; i < X.length; i++) (X[i][f] <= thr ? li : ri).push(i);
      if (li.length < minSamples || ri.length < minSamples) continue;
      const ly = li.map((i) => y[i]);
      const ry = ri.map((i) => y[i]);
      const gain = baseVar - (variance(ly) * li.length + variance(ry) * ri.length) / y.length;
      if (gain > bestGain) {
        bestGain = gain;
        bestFeat = f;
        bestThr = thr;
        bestLeftIdx = li;
        bestRightIdx = ri;
      }
    }
  }

  if (bestFeat < 0) return { leaf: leafValue };

  importance[bestFeat] += bestGain * y.length;

  return {
    featIdx: bestFeat,
    threshold: bestThr,
    gain: bestGain,
    left: buildTree(
      bestLeftIdx.map((i) => X[i]),
      bestLeftIdx.map((i) => y[i]),
      depth + 1,
      maxDepth,
      minSamples,
      importance,
    ),
    right: buildTree(
      bestRightIdx.map((i) => X[i]),
      bestRightIdx.map((i) => y[i]),
      depth + 1,
      maxDepth,
      minSamples,
      importance,
    ),
  };
}

function predictTree(tree: TreeNode, x: number[]): number {
  let node = tree;
  while (!("leaf" in node)) {
    node = x[node.featIdx] <= node.threshold ? node.left : node.right;
  }
  return node.leaf;
}

export type GBRTModel = {
  trees: TreeNode[];
  init: number;
  lr: number;
  importance: number[];
  hp: { nTrees: number; maxDepth: number; lr: number; subsample: number; minSamples: number };
};

export function trainGBRT(
  X: number[][],
  y: number[],
  opts: { nTrees?: number; maxDepth?: number; lr?: number; subsample?: number; minSamples?: number } = {},
): GBRTModel {
  const nTrees = opts.nTrees ?? 80;
  const maxDepth = opts.maxDepth ?? 3;
  const lr = opts.lr ?? 0.08;
  const subsample = opts.subsample ?? 0.85;
  const minSamples = opts.minSamples ?? 5;

  const init = mean(y);
  const preds = new Array(y.length).fill(init);
  const trees: TreeNode[] = [];
  const importance = new Array(X[0].length).fill(0);

  // Deterministic PRNG for stochastic subsampling
  let seed = 1337;
  const rand = () => {
    seed = (seed * 9301 + 49297) % 233280;
    return seed / 233280;
  };

  for (let t = 0; t < nTrees; t++) {
    const residuals = y.map((yi, i) => yi - preds[i]);
    let Xs = X;
    let rs = residuals;
    let idxs: number[] | null = null;
    if (subsample < 1) {
      idxs = [];
      for (let i = 0; i < X.length; i++) if (rand() < subsample) idxs.push(i);
      if (idxs.length < minSamples * 4) idxs = X.map((_, i) => i);
      Xs = idxs.map((i) => X[i]);
      rs = idxs.map((i) => residuals[i]);
    }
    const tree = buildTree(Xs, rs, 0, maxDepth, minSamples, importance);
    trees.push(tree);
    for (let i = 0; i < X.length; i++) preds[i] += lr * predictTree(tree, X[i]);
  }

  // Normalise feature importance
  const totalImp = importance.reduce((a, b) => a + b, 0) || 1;
  const normImp = importance.map((v) => v / totalImp);

  return {
    trees,
    init,
    lr,
    importance: normImp,
    hp: { nTrees, maxDepth, lr, subsample, minSamples },
  };
}

export function predictGBRT(model: GBRTModel, x: number[]): number {
  let p = model.init;
  for (const t of model.trees) p += model.lr * predictTree(t, x);
  return p;
}

export function metrics(yTrue: number[], yPred: number[]) {
  const n = yTrue.length;
  let mae = 0;
  let mse = 0;
  let mape = 0;
  const meanY = mean(yTrue);
  let ssTot = 0;
  let ssRes = 0;
  for (let i = 0; i < n; i++) {
    const err = yTrue[i] - yPred[i];
    mae += Math.abs(err);
    mse += err * err;
    if (yTrue[i] !== 0) mape += Math.abs(err / yTrue[i]);
    ssRes += err * err;
    ssTot += (yTrue[i] - meanY) * (yTrue[i] - meanY);
  }
  return {
    mae: mae / n,
    rmse: Math.sqrt(mse / n),
    mape: (mape / n) * 100,
    r2: ssTot > 0 ? 1 - ssRes / ssTot : 0,
  };
}
