import { createServerFn } from "@tanstack/react-start";

// GridStatus.io live grid feed for CAISO. Cached in-memory for 30s to stay
// well under the 1 req/sec free-tier limit. Values normalized to MW & €/MWh
// (LMP is USD/MWh; we expose it as-is and let the UI label it).

type Cached = {
  ts: number;
  load_mw: number;
  forecast_mw: number;
  lmp_usd_mwh: number;
  interval_utc: string;
};

let cache: Cached | null = null;
const TTL_MS = 30_000;

async function gs<T = any>(path: string): Promise<T> {
  const key = process.env.GRIDSTATUS_API_KEY;
  if (!key) throw new Error("GRIDSTATUS_API_KEY missing");
  const sep = path.includes("?") ? "&" : "?";
  const res = await fetch(`https://api.gridstatus.io/v1${path}${sep}api_key=${key}`, {
    headers: { accept: "application/json" },
  });
  if (!res.ok) throw new Error(`GridStatus ${res.status}: ${await res.text()}`);
  return res.json();
}

async function fetchFresh(): Promise<Cached> {
  // Sequential to respect 1 req/sec limit.
  const load = await gs(`/datasets/caiso_load/query?time=latest`);
  await new Promise((r) => setTimeout(r, 1100));
  const forecast = await gs(`/datasets/caiso_load_forecast_5_min/query?time=latest`);
  await new Promise((r) => setTimeout(r, 1100));
  const lmp = await gs(
    `/datasets/caiso_lmp_real_time_5_min/query?time=latest&filter_column=location&filter_value=TH_SP15_GEN-APND`,
  );
  const loadRow = load?.data?.[0] ?? {};
  const fcRow = forecast?.data?.[0] ?? {};
  const lmpRow = lmp?.data?.[0] ?? {};
  return {
    ts: Date.now(),
    load_mw: Number(loadRow.load ?? 0),
    forecast_mw: Number(fcRow.load_forecast ?? fcRow.forecast ?? fcRow.load ?? 0),
    lmp_usd_mwh: Number(lmpRow.lmp ?? 0),
    interval_utc: loadRow.interval_start_utc ?? new Date().toISOString(),
  };
}

export const getLiveGrid = createServerFn({ method: "GET" }).handler(async () => {
  if (cache && Date.now() - cache.ts < TTL_MS) return cache;
  try {
    cache = await fetchFresh();
    return cache;
  } catch (e: any) {
    // Fall back to last cache if available, otherwise surface error shape
    if (cache) return cache;
    return {
      ts: Date.now(),
      load_mw: 0,
      forecast_mw: 0,
      lmp_usd_mwh: 0,
      interval_utc: new Date().toISOString(),
      error: String(e?.message ?? e),
    } as Cached & { error: string };
  }
});
