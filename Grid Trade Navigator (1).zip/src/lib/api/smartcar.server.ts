import { createHmac } from "crypto";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

const SMARTCAR_TOKEN = "https://auth.smartcar.com/oauth/token";
const SMARTCAR_API = "https://api.smartcar.com/v2.0";
const SMARTCAR_APPLICATION_ID = "87973fc6-55d9-4f3d-9cf9-2cfcb7cf8f0c";

export function signState(userId: string): string {
  const secret = process.env.SMARTCAR_CLIENT_SECRET!;
  const payload = `${userId}.${Date.now()}`;
  const sig = createHmac("sha256", secret).update(payload).digest("hex");
  return Buffer.from(`${payload}.${sig}`).toString("base64url");
}

export function verifyState(state: string): string | null {
  try {
    const secret = process.env.SMARTCAR_CLIENT_SECRET!;
    const decoded = Buffer.from(state, "base64url").toString("utf8");
    const [userId, ts, sig] = decoded.split(".");
    if (!userId || !ts || !sig) return null;
    const expected = createHmac("sha256", secret).update(`${userId}.${ts}`).digest("hex");
    if (expected !== sig) return null;
    if (Date.now() - Number(ts) > 10 * 60 * 1000) return null;
    return userId;
  } catch {
    return null;
  }
}

export async function exchangeCode(code: string, redirectUri: string) {
  const secret = process.env.SMARTCAR_CLIENT_SECRET!;
  const basic = Buffer.from(`${SMARTCAR_APPLICATION_ID}:${secret}`).toString("base64");
  const body = new URLSearchParams({
    grant_type: "authorization_code",
    code,
    redirect_uri: redirectUri,
  });
  const res = await fetch(SMARTCAR_TOKEN, {
    method: "POST",
    headers: {
      Authorization: `Basic ${basic}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body,
  });
  if (!res.ok) throw new Error(`Smartcar token exchange failed: ${res.status} ${await res.text()}`);
  return res.json() as Promise<{
    access_token: string;
    refresh_token: string;
    expires_in: number;
    token_type: string;
  }>;
}

export async function refreshIfNeeded(userId: string): Promise<string> {
  const { data: tok, error } = await supabaseAdmin
    .from("smartcar_tokens")
    .select("*")
    .eq("user_id", userId)
    .maybeSingle();
  if (error || !tok) throw new Error("No Smartcar connection");
  const expiresAt = new Date(tok.expires_at).getTime();
  if (expiresAt - Date.now() > 60_000) return tok.access_token;

  const secret = process.env.SMARTCAR_CLIENT_SECRET!;
  const basic = Buffer.from(`${SMARTCAR_APPLICATION_ID}:${secret}`).toString("base64");
  const res = await fetch(SMARTCAR_TOKEN, {
    method: "POST",
    headers: {
      Authorization: `Basic ${basic}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: new URLSearchParams({
      grant_type: "refresh_token",
      refresh_token: tok.refresh_token,
    }),
  });
  if (!res.ok) throw new Error(`Refresh failed: ${res.status}`);
  const j = (await res.json()) as { access_token: string; refresh_token: string; expires_in: number };
  const newExpiresAt = new Date(Date.now() + j.expires_in * 1000).toISOString();
  await supabaseAdmin
    .from("smartcar_tokens")
    .update({
      access_token: j.access_token,
      refresh_token: j.refresh_token,
      expires_at: newExpiresAt,
      updated_at: new Date().toISOString(),
    })
    .eq("user_id", userId);
  return j.access_token;
}

async function scFetch(path: string, token: string) {
  const res = await fetch(`${SMARTCAR_API}${path}`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error(`Smartcar ${path}: ${res.status} ${await res.text()}`);
  return res.json();
}

export async function syncVehiclesForUser(userId: string) {
  const token = await refreshIfNeeded(userId);
  const list = (await scFetch("/vehicles", token)) as { vehicles: string[] };
  const out: Array<{ id: string; soc: number | null }> = [];
  for (const vid of list.vehicles) {
    let info: any = {};
    let battery: any = {};
    let odometer: any = {};
    try {
      info = await scFetch(`/vehicles/${vid}`, token);
    } catch {}
    try {
      battery = await scFetch(`/vehicles/${vid}/battery`, token);
    } catch {}
    try {
      odometer = await scFetch(`/vehicles/${vid}/odometer`, token);
    } catch {}
    const soc =
      typeof battery?.percentRemaining === "number"
        ? Math.round(battery.percentRemaining * 100)
        : null;
    const odometerKm =
      typeof odometer?.distance === "number" ? Math.round(odometer.distance) : null;
    const name = info?.make && info?.model ? `${info.make} ${info.model}` : `Smartcar ${vid.slice(0, 6)}`;

    const { data: existing } = await supabaseAdmin
      .from("ev_vehicles")
      .select("id")
      .eq("user_id", userId)
      .eq("smartcar_vehicle_id", vid)
      .maybeSingle();

    if (existing) {
      await supabaseAdmin
        .from("ev_vehicles")
        .update({
          soc: soc ?? undefined,
          make: info?.make ?? null,
          model: info?.model ?? null,
          year: info?.year ?? null,
          odometer_km: odometerKm ?? undefined,
          last_synced_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        })
        .eq("id", existing.id);
      out.push({ id: existing.id, soc });
    } else {
      const { data: inserted } = await supabaseAdmin
        .from("ev_vehicles")
        .insert({
          user_id: userId,
          name,
          plate_number: `SC-${vid.slice(0, 6).toUpperCase()}`,
          battery_kwh: 75,
          soc: soc ?? 50,
          status: "idle",
          smartcar_vehicle_id: vid,
          make: info?.make ?? null,
          model: info?.model ?? null,
          year: info?.year ?? null,
          odometer_km: odometerKm,
          last_synced_at: new Date().toISOString(),
        })
        .select("id")
        .maybeSingle();
      if (inserted) out.push({ id: inserted.id, soc });
    }
  }
  return { count: list.vehicles.length, vehicles: out };
}
