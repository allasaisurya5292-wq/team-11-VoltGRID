import { createServerFn } from "@tanstack/react-start";
import { getRequest } from "@tanstack/react-start/server";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { signState, syncVehiclesForUser } from "./smartcar.server";

const SMARTCAR_AUTH = "https://connect.smartcar.com/oauth/authorize";
const SMARTCAR_APPLICATION_ID = "87973fc6-55d9-4f3d-9cf9-2cfcb7cf8f0c";
const SCOPES = ["read_vehicle_info", "read_battery", "read_charge", "read_location", "read_odometer"];

function origin(): string {
  const req = getRequest();
  const url = new URL(req.url);
  return `${url.protocol}//${url.host}`;
}

export const startSmartcarAuth = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const redirectUri = `${origin()}/api/smartcar/callback`;
    const state = signState(context.userId);
    const url = new URL(SMARTCAR_AUTH);
    url.searchParams.set("response_type", "code");
    url.searchParams.set("client_id", SMARTCAR_APPLICATION_ID);
    url.searchParams.set("redirect_uri", redirectUri);
    url.searchParams.set("scope", SCOPES.join(" "));
    url.searchParams.set("state", state);
    url.searchParams.set("mode", "test");
    url.searchParams.set("approval_prompt", "auto");
    return { authUrl: url.toString(), redirectUri };
  });

export const syncSmartcar = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    return syncVehiclesForUser(context.userId);
  });

export const smartcarStatus = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await supabaseAdmin
      .from("smartcar_tokens")
      .select("user_id, expires_at, updated_at")
      .eq("user_id", context.userId)
      .maybeSingle();
    return { connected: !!data, expiresAt: data?.expires_at ?? null };
  });
