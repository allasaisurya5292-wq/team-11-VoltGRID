import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

// Persist SoC changes from the dispatch simulation back into ev_vehicles.
// RLS scopes writes to the caller via user_id.

export const persistDispatch = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(
    z.object({
      updates: z
        .array(
          z.object({
            id: z.string().uuid(),
            soc: z.number().min(0).max(100),
          }),
        )
        .min(1)
        .max(200),
    }),
  )
  .handler(async ({ data, context }) => {
    const { supabase } = context;
    // Batch update via individual calls (RLS-safe). Small fleet sizes expected.
    const results = await Promise.all(
      data.updates.map((u) =>
        supabase
          .from("ev_vehicles")
          .update({ soc: u.soc, updated_at: new Date().toISOString() })
          .eq("id", u.id),
      ),
    );
    const errors = results
      .map((r, i) => (r.error ? `${data.updates[i].id}: ${r.error.message}` : null))
      .filter(Boolean);
    return { updated: data.updates.length - errors.length, errors };
  });
