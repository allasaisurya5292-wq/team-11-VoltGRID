-- Companies owned by a csv_admin user
CREATE TABLE public.companies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  name TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.companies TO authenticated;
GRANT ALL ON public.companies TO service_role;

ALTER TABLE public.companies ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own companies all" ON public.companies
  FOR ALL TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Vehicles per company, with free-form category (Car, Bus, Van, ...)
CREATE TABLE public.company_vehicles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  category TEXT NOT NULL DEFAULT 'Car',
  name TEXT NOT NULL,
  plate_number TEXT NOT NULL DEFAULT '',
  battery_kwh NUMERIC NOT NULL DEFAULT 75,
  soc NUMERIC NOT NULL DEFAULT 80,
  status TEXT NOT NULL DEFAULT 'idle',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_company_vehicles_company ON public.company_vehicles(company_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.company_vehicles TO authenticated;
GRANT ALL ON public.company_vehicles TO service_role;

ALTER TABLE public.company_vehicles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own company vehicles all" ON public.company_vehicles
  FOR ALL TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);