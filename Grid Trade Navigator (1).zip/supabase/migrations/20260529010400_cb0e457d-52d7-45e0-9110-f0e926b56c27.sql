DELETE FROM auth.users
WHERE id IN (SELECT user_id FROM public.user_roles WHERE role = 'csv_admin');

DELETE FROM public.user_roles WHERE role = 'csv_admin';

CREATE OR REPLACE FUNCTION public.handle_new_user()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_company text;
BEGIN
  INSERT INTO public.profiles (id, display_name, company)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email, '@', 1)),
    NEW.raw_user_meta_data->>'company'
  );
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, COALESCE((NEW.raw_user_meta_data->>'role')::app_role, 'ev_owner'));
  INSERT INTO public.price_alerts (user_id) VALUES (NEW.id);

  v_company := NULLIF(trim(NEW.raw_user_meta_data->>'company'), '');
  IF v_company IS NOT NULL THEN
    INSERT INTO public.companies (user_id, name)
    SELECT NEW.id, v_company
    WHERE NOT EXISTS (
      SELECT 1 FROM public.companies WHERE user_id = NEW.id AND lower(name) = lower(v_company)
    );
  END IF;

  RETURN NEW;
END;
$function$;

ALTER TABLE public.profiles DROP COLUMN IF EXISTS phone;