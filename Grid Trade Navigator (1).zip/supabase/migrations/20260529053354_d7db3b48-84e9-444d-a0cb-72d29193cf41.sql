
ALTER TABLE public.ev_vehicles
  ADD COLUMN IF NOT EXISTS category text NOT NULL DEFAULT 'Bus',
  ADD COLUMN IF NOT EXISTS company text NOT NULL DEFAULT 'Maenova Bus Co';
