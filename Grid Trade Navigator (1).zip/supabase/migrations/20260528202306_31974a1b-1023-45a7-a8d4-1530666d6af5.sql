
-- Smartcar integration: per-user tokens + link ev_vehicles to Smartcar vehicle IDs
CREATE TABLE public.smartcar_tokens (
  user_id UUID PRIMARY KEY,
  access_token TEXT NOT NULL,
  refresh_token TEXT NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT ON public.smartcar_tokens TO authenticated;
GRANT ALL ON public.smartcar_tokens TO service_role;

ALTER TABLE public.smartcar_tokens ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own tokens read" ON public.smartcar_tokens
  FOR SELECT TO authenticated
  USING (auth.uid() = user_id);

ALTER TABLE public.ev_vehicles
  ADD COLUMN smartcar_vehicle_id TEXT,
  ADD COLUMN make TEXT,
  ADD COLUMN model TEXT,
  ADD COLUMN year INT,
  ADD COLUMN last_synced_at TIMESTAMPTZ;

CREATE UNIQUE INDEX ev_vehicles_smartcar_unique
  ON public.ev_vehicles (user_id, smartcar_vehicle_id)
  WHERE smartcar_vehicle_id IS NOT NULL;
