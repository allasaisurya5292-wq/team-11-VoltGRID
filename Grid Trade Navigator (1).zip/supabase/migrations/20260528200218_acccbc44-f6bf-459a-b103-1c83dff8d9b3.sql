CREATE TABLE public.ev_vehicles (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  name TEXT NOT NULL,
  plate_number TEXT NOT NULL,
  battery_kwh NUMERIC NOT NULL DEFAULT 75,
  soc NUMERIC NOT NULL DEFAULT 80,
  status TEXT NOT NULL DEFAULT 'idle',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.ev_vehicles TO authenticated;
GRANT ALL ON public.ev_vehicles TO service_role;

ALTER TABLE public.ev_vehicles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "own vehicles all" ON public.ev_vehicles
  FOR ALL TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "admin vehicles read" ON public.ev_vehicles
  FOR SELECT TO authenticated
  USING (has_role(auth.uid(), 'maenova_admin'::app_role));

CREATE INDEX idx_ev_vehicles_user ON public.ev_vehicles(user_id);

ALTER PUBLICATION supabase_realtime ADD TABLE public.ev_vehicles;
ALTER TABLE public.ev_vehicles REPLICA IDENTITY FULL;