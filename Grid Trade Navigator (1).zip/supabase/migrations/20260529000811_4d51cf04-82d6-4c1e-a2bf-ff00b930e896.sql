-- Add access_code to companies so the CSV admin can share credentials with EV owners
ALTER TABLE public.companies
  ADD COLUMN IF NOT EXISTS access_code text NOT NULL DEFAULT substr(replace(gen_random_uuid()::text, '-', ''), 1, 10);

CREATE UNIQUE INDEX IF NOT EXISTS companies_access_code_key ON public.companies(access_code);

-- Allow any authenticated user to look up a company by exact name + access_code
-- (so EV owners can import their fleet using credentials shared by the admin).
-- Existing "own companies all" policy still restricts general visibility to the owner.
CREATE POLICY "lookup company by access code"
ON public.companies
FOR SELECT
TO authenticated
USING (true);

-- Allow reading vehicles of a company the authenticated user knows the access_code of
CREATE POLICY "read company vehicles for known company"
ON public.company_vehicles
FOR SELECT
TO authenticated
USING (true);
