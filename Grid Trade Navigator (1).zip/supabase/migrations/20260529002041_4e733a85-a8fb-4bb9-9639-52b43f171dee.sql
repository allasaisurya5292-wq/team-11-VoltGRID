CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_company text;
  v_admin uuid;
BEGIN
  INSERT INTO public.profiles (id, display_name, company)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email, '@', 1)), NEW.raw_user_meta_data->>'company');
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, COALESCE((NEW.raw_user_meta_data->>'role')::app_role, 'ev_owner'));
  INSERT INTO public.price_alerts (user_id) VALUES (NEW.id);

  v_company := NULLIF(trim(NEW.raw_user_meta_data->>'company'), '');
  IF v_company IS NOT NULL THEN
    SELECT u.id INTO v_admin
    FROM auth.users u
    JOIN public.user_roles r ON r.user_id = u.id
    WHERE r.role = 'csv_admin'
    ORDER BY u.created_at
    LIMIT 1;

    IF v_admin IS NOT NULL THEN
      INSERT INTO public.companies (user_id, name)
      SELECT v_admin, v_company
      WHERE NOT EXISTS (
        SELECT 1 FROM public.companies WHERE user_id = v_admin AND lower(name) = lower(v_company)
      );
    END IF;
  END IF;

  RETURN NEW;
END;
$function$;

-- Backfill any existing EV owners' companies into the csv_admin's list
DO $$
DECLARE
  v_admin uuid;
BEGIN
  SELECT u.id INTO v_admin
  FROM auth.users u
  JOIN public.user_roles r ON r.user_id = u.id
  WHERE r.role = 'csv_admin'
  ORDER BY u.created_at LIMIT 1;

  IF v_admin IS NOT NULL THEN
    INSERT INTO public.companies (user_id, name)
    SELECT v_admin, trim(p.company)
    FROM public.profiles p
    WHERE p.company IS NOT NULL AND trim(p.company) <> ''
      AND NOT EXISTS (
        SELECT 1 FROM public.companies c
        WHERE c.user_id = v_admin AND lower(c.name) = lower(trim(p.company))
      )
    GROUP BY trim(p.company);
  END IF;
END $$;